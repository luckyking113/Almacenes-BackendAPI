//
//  AppData.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import MBProgressHUD
class AppData {
    static let shared: AppData = {
        return AppData()
    }()
    var loadingNotification: MBProgressHUD!
    public var  selectship_image : String = ""
    public var  ship_image : UIImage!
    public var  verification_id : String = ""
    public var  profile_phoneNumber : String = ""
    public var  profile_verficationvalue: String = ""
    public var  profile_accountType : Int = -1
    public var  profile_useremail : String = ""
    public var  profile_fcmtoken : String = ""
    public var  profile_firstname: String = ""
    public var  profile_lastname : String = ""
    public var  profile_discountArray  = NSMutableArray()
    public var  profile_shippingAddress = NSMutableArray()
    public var  profile_loginstatus : Bool = false
    public var  profile_imageurl: String = ""
    public var  profile_birthdate : String = ""
    public var  profile_customerid : String = ""
   
    public var  profile_customerDetailData = NSDictionary()
    public var  profile_carddetailData = NSDictionary()
    public var  ware_houseData = NSDictionary()
    public var  order_Data = NSMutableArray()
    public var  orderHistory_Data = NSMutableArray()
    public var  product_Data = NSMutableArray()
    public var  categroy_Data = NSMutableArray()
    public var  cartBadge_number : Int = 0
    public var  default_cardsource : String = ""
    public var  cartProductData = NSMutableArray()
    public var  cardDetailData = NSMutableArray()
   
    public var  warehouseworkingstatus : Int = -1
    public var  customer_totalPrice : Float = 0
    public var  customer_zipcode : String = ""
    public var  default_maindeliveraddress : String = ""
    public var  default_maindelivertitle : String = ""
    public var  default_mainaddressimage : String = ""
    public var  default_maindeliverid : String = ""
    public var  select_shipping_address : String = ""
    public var  select_shipping_address_lat : Double = 0.0
    public var  select_shippin_address_lon : Double = 0.0
    public var  select_indexship : Int = 0
    public var  select_shipname : String = ""
    public var  select_shipzipcode :String = ""
    public var  select_discountcode : String = ""
    public var  warehouse_zipcode : String = ""
    public var  zipdialog_flag : Int = 0
    public var  wrong_warehouse: Int = -1
    public var  delete_data = NSDictionary()
    public var  delete_index: Int = -1
    public var  gotopage : String = ""
    public var  set_flag : Int = 0
    public var show_address: String = ""
    
//    #0078ff #e82e2e #e271ac    #e82e2e #bd00ff #ff9a00 #01ff1f #fff233 #0eb9fe #c22d7e #ff9a00    #207f1b
    public var color1 : UIColor = UIColor.init(red: 0/255, green: 120/255, blue: 255/255, alpha: 1.0)
    public var color2 : UIColor = UIColor.init(red: 232/255, green: 46/255, blue: 46/255, alpha: 1.0)
    public var color3 : UIColor = UIColor.init(red: 226/255, green: 113/255, blue: 172/255, alpha: 1.0)
    public var color4 : UIColor = UIColor.init(red: 189/255, green: 0/255, blue: 255/255, alpha: 1.0)
    public var color9 : UIColor = UIColor.init(red: 255/255, green: 154/255, blue: 0/255, alpha: 1.0)
    public var color6 : UIColor = UIColor.init(red: 1/255, green: 255/255, blue: 31/255, alpha: 1.0)
    public var color7 : UIColor = UIColor.init(red: 225/255, green: 173/255,blue: 1/255, alpha: 1.0)
    public var color8 : UIColor = UIColor.init(red: 14/255, green: 185/255, blue: 254/255, alpha: 1.0)
    public var color5 : UIColor = UIColor.init(red: 194/255, green: 45/255, blue: 126/255, alpha: 1.0)
    public var uiColorArray = [UIColor]()
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    func downloadImage(from url: URL, imageView: UIImageView!) {
        print("Download Started")
        getData(from: url) { data, response, error in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() {
                //                self.imageView.image = UIImage(data: data)
                imageView?.image = UIImage(data: data) 
            }
        }
    }
    func convertStringToDictionary(text: String) -> [String:AnyObject]? {
        if let data = text.data(using: String.Encoding.utf8) {
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:AnyObject]
                return json
            } catch {
                print("Something went wrong")
            }
        }
        return nil
    }
    func displayToastMessage(_ message : String) {
        
        let toastView = UILabel()
        toastView.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toastView.textColor = UIColor.white
        toastView.textAlignment = .center
        toastView.font = UIFont.preferredFont(forTextStyle: .caption1)
        toastView.layer.cornerRadius = 25
        toastView.layer.masksToBounds = true
        toastView.text = message
        toastView.numberOfLines = 0
        toastView.alpha = 0
        toastView.translatesAutoresizingMaskIntoConstraints = false
        
        let window = UIApplication.shared.delegate?.window!
        window?.addSubview(toastView)
        
        let horizontalCenterContraint: NSLayoutConstraint = NSLayoutConstraint(item: toastView, attribute: .centerX, relatedBy: .equal, toItem: window, attribute: .centerX, multiplier: 1, constant: 0)
        
        let widthContraint: NSLayoutConstraint = NSLayoutConstraint(item: toastView, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .width, multiplier: 1, constant: 275)
        
        let verticalContraint: [NSLayoutConstraint] = NSLayoutConstraint.constraints(withVisualFormat: "V:|-(>=200)-[loginView(==50)]-68-|", options: [.alignAllCenterX, .alignAllCenterY], metrics: nil, views: ["loginView": toastView])
        
        NSLayoutConstraint.activate([horizontalCenterContraint, widthContraint])
        NSLayoutConstraint.activate(verticalContraint)
        
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
            toastView.alpha = 1
        }, completion: nil)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double((Int64)(2 * NSEC_PER_SEC)) / Double(NSEC_PER_SEC), execute: {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: {
                toastView.alpha = 0
            }, completion: { finished in
                toastView.removeFromSuperview()
            })
        })
    }
    func showLoadingIndicator(view: UIView){
        loadingNotification = MBProgressHUD.showAdded(to: view, animated: true)
        loadingNotification.mode = MBProgressHUDMode.indeterminate
        loadingNotification.bezelView.color = UIColor(red: 35, green: 0, blue: 0, alpha: 0.1)
        loadingNotification.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.1)
    }
    func hideLoadingIndicator(){
        loadingNotification.hide(animated: true)
    }
    func addgif(sender : UIButton!){
        UIButton.animate(withDuration: 0.2,
                         animations: {
                            //sender.transform = CGAffineTransform(scaleX: 0.975, y: 0.96)
                            sender.alpha = 0.8
        },
                         completion: { finish in
                            UIButton.animate(withDuration: 0.2, animations: {
                                //sender.transform = CGAffineTransform.identity
                                sender.alpha = 1
                            })
        })
    }
    func initAppData(){
        selectship_image  = ""
        ship_image = UIImage()
        verification_id = ""
        profile_phoneNumber  = ""
        profile_verficationvalue = ""
        profile_accountType  = -1
        profile_useremail  = ""
        profile_fcmtoken  = ""
        profile_firstname = ""
        profile_lastname  = ""
        profile_discountArray  = NSMutableArray()
        profile_shippingAddress = NSMutableArray()
        profile_loginstatus  = false
        profile_imageurl = ""
        profile_customerid  = ""
        
        profile_customerDetailData = NSDictionary()
        profile_carddetailData = NSDictionary()
        ware_houseData = NSDictionary()
        order_Data = NSMutableArray()
        orderHistory_Data = NSMutableArray()
        product_Data = NSMutableArray()
        categroy_Data = NSMutableArray()
        cartBadge_number  = 0
        default_cardsource  = ""
        cartProductData = NSMutableArray()
        cardDetailData = NSMutableArray()
        
        warehouseworkingstatus  = -1
        customer_totalPrice  = 0
        customer_zipcode = ""
        select_shipping_address  = ""
        select_shipping_address_lat  = 0.0
        select_shippin_address_lon  = 0.0
        select_indexship  = 0
        select_shipname = ""
        select_shipzipcode  = ""
        select_discountcode  = ""
        warehouse_zipcode  = ""
        zipdialog_flag  = 0
        wrong_warehouse = -1
    }
    func initCartData(){
      
        ware_houseData = NSDictionary()
        order_Data = NSMutableArray()
        orderHistory_Data = NSMutableArray()
        product_Data = NSMutableArray()
        categroy_Data = NSMutableArray()
        cartBadge_number  = 0
        cartProductData = NSMutableArray()
       
        customer_totalPrice  = 0
        select_shipping_address  = ""
        select_shipping_address_lat  = 0.0
        select_shippin_address_lon  = 0.0
        select_indexship  = 0
        select_shipname = ""
        select_shipzipcode  = ""
        select_discountcode  = ""
        zipdialog_flag  = 0
       
    }

//    "discountcodes":[{"id":"6","name":"SANVALE","type":"General","start_time":"2017-01-31 00:00:00","end_time":"2019-12-31 00:00:00","value":"30.00","used":"0","created_at":"2019-01-15 01:33:27","updated_at":"2019-02-28 04:43:18"},{"id":"11","name":"CARO","type":"General","start_time":"2019-03-18 00:00:00","end_time":"2020-12-31 00:00:00","value":"40.00","used":"0","created_at":"2019-03-03 20:35:07","updated_at":"2019-03-18 18:46:56"}]
//}
//    customerdetail =     (
//    {
//    "account_type" = "<null>";
//    "allow_discountemail" = 0;
//    "allow_stageemail" = 0;
//    "created_at" = "<null>";
//    "customer_cardname" = "<null>";
//    "customer_cardnumber" = "<null>";
//    email = "test@test.com";
//    facebook = "<null>";
//    "first_name" = Xiao;
//    "group_id" = "<null>";
//    id = 43;
//    image = "http://mcflydelivery.com/mcflybackend/uploadfiles/images/image_1559313981.png";
//    instagram = "<null>";
//    job = "<null>";
//    "last_name" = Chun;
//    latitude = "<null>";
//    longitude = "<null>";
//    password = "";
//    phone = 15621342545;
//    status = 1;
//    token = "cQ6D27ZxVD0:APA91bG3V4bvz7iXtt9Hbk9aSf5xVBaH9u5QLLnQVT63yRI_I1gOUYb_HmVLHZojNCB2gvXaLx6WliHG7Uin0blbYUqv4l6R_WTS2ZmZJ_OXpImjbHoWhjMb1Agyb6XTe9NT_HYmJEox";
//    "total_order" = 0;
//    type = "<null>";
//    "updated_at" = "<null>";
//    "verfified_value" = 9254440551;
//    verifiedtype = 3;
//    }
//    );
//    shippingaddresses =     (
//    {
//    "address_id" = 97;
//    "address_imageurl" = "https://mcflydelivery.com/mcflybackend/uploadfiles/images/friend.png";
//    "address_lat" = "";
//    "address_lng" = "";
//    "address_location" = test;
//    "address_name" = test;
//    "address_zipcode" = test;
//    "customer_id" = 43;
//    }
//    );
//    {
//    message = success;
//    orders =     (
//    );
//    warehouse =     (
//    {
//    address = "Zona de la Universidad de las Am\U00e9ricas, 72819 San Andres Cholula, Puebla";
//    "created_at" = "2018-12-06 17:03:31";
//    "delivery_fee" = 10;
//    "fri_working_endtime" = 11pm;
//    "fri_working_starttime" = 8am;
//    id = 2;
//    image = "15536239002033492023.png";
//    "inventory_scale" = 50;
//    lat = "19.053442";
//    lon = "-98.282715";
//    "mon_working_endtime" = 11pm;
//    "mon_working_starttime" = 8am;
//    name = "UDLAP Campus Cholula";
//    "performance_scale" = 30;
//    "report_scale" = 100;
//    "sat_working_endtime" = Non;
//    "sat_working_starttime" = Non;
//    "sun_working_endtime" = Non;
//    "sun_working_starttime" = Non;
//    "thu_working_endtime" = 11pm;
//    "thu_working_starttime" = 12am;
//    "tue_working_endtime" = 11pm;
//    "tue_working_starttime" = 8am;
//    "updated_at" = "2019-04-04 06:38:32";
//    "website_scale" = 50;
//    "wed_working_endtime" = 11pm;
//    "wed_working_starttime" = 8am;
//    "zip_code" = "72810,72800,12345";
//    }
//    );
//    warehouseworkingtimestatus = 1;
//    }
}
