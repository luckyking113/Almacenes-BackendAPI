//
//  AppConstant.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
public class AppConstants {
    static var baseUrl: String = "https://mcflydelivery.com/mcflybackend/index.php/api/"
    static let clientID : String = "1464a5cef63d4287bd4cb21e0498b1c7"
    static let redirectUri = "http://mcflydelivery.com"
    static let getInstagramIDurl = "https://api.instagram.com/v1/users/self/?access_token="
    static let image_url = "https://mcflydelivery.com/public/uploads/category/thumbnail/"
    static let imageproduct_url = "https://mcflydelivery.com/public/uploads/product/thumbnail/"
    static let direction_url = "http://litigationlogistics.mobi/trialdriveadmin/index.php/api/getdirection"
    static let warehouse_zipcode = "12345,72170,72800,72803,72805,72810,72813,72814,72815,72816,72817,72818, 72819,72824,72825,72828,72730,72735,72837,72760,72761"
}
