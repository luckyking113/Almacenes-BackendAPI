//
//  AddressCell.swift
//  McFly
//
//  Created by LiuYan on 6/2/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class AddressCell: UITableViewCell {

    
    @IBOutlet weak var main_address: UILabel!
    @IBOutlet weak var description_lbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
