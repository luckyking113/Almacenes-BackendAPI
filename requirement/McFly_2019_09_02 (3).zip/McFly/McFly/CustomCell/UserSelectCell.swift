//
//  UserSelectCell.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class UserSelectCell: UICollectionViewCell {
    
    
    @IBOutlet weak var userSelectView: UIView!
    @IBOutlet weak var user_selectImage: UIImageView!
    @IBOutlet weak var user_selectname: UILabel!
    override func awakeFromNib() {
        userSelectView.layer.cornerRadius = 3
        userSelectView.layer.masksToBounds = true
    }
}
