//
//  OrderCell.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class OrderCell: UITableViewCell {

   
    
    @IBOutlet weak var order_idlbl: UILabel!
    
    @IBOutlet weak var order_addresslbl: UILabel!
    
    @IBOutlet weak var order_amountlbl: UILabel!
    
    @IBOutlet weak var order_status: UILabel!
    
    @IBOutlet weak var orderconfirm_view: UIView!
    @IBOutlet weak var ordercofirm_image: UIImageView!
    @IBOutlet weak var orderconfirm_button: UILabel!
    
    @IBOutlet weak var order_datelbl: UILabel!
    
    @IBOutlet weak var order_timelbl: UILabel!
    var controller : UIViewController!
    var orderNumber : Int = 0
    var orderid: String = ""
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        let gesture = UITapGestureRecognizer(target: self, action: #selector(confirm_action(_:)))
        self.ordercofirm_image.addGestureRecognizer(gesture)
        self.ordercofirm_image.isUserInteractionEnabled = true
        let gesture1 = UITapGestureRecognizer(target: self, action: #selector(confirm_action(_:)))
        self.orderconfirm_button.addGestureRecognizer(gesture1)
        self.orderconfirm_button.isUserInteractionEnabled = true
        // Configure the view for the selected state
    }
    
    @objc func confirm_action(_ sender: Any) {
       // AppData.shared.addgif(sender: self.orderconfirm_button)
        let vc = self.controller.storyboard?.instantiateViewController(withIdentifier: "trackmapVC") as! TrackMapViewController
        vc.orderid = self.orderid
        vc.orderunique_id = self.orderNumber
        self.controller.navigationController?.pushViewController(vc, animated: true)
    }
}
