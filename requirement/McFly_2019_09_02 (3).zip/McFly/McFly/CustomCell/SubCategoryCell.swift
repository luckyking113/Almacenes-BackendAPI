//
//  SubCategoryCell.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class SubCategoryCell: UICollectionViewCell {
    
    @IBOutlet weak var subimageView: UIImageView!
    @IBOutlet weak var subview: UIView!
    
    @IBOutlet weak var cart_btn: UIButton!
    @IBOutlet weak var fash_name: UILabel!
    @IBOutlet weak var fash_cost: UILabel!
    var viewcontroller: UIViewController!
    var cellProductData = NSDictionary()
    var categoryname : String = ""
    override func awakeFromNib() {
        
        self.subimageView.layer.masksToBounds = false
        self.subimageView.layer.cornerRadius = 4
        self.subimageView.clipsToBounds = true
        
        self.cart_btn.layer.cornerRadius = 3
        self.cart_btn.clipsToBounds = true
        
        self.subview.layer.cornerRadius = 2
        self.subview.layer.borderColor = UIColor.gray.cgColor
        self.subview.layer.borderWidth = 1
    }
    
    @IBAction func add_CartBtn(_ sender: Any) {
        AppData.shared.addgif(sender: self.cart_btn)
        if (AppData.shared.profile_loginstatus){
            if (AppData.shared.wrong_warehouse == 1){
                if (AppData.shared.set_flag == 1 ){
                    if (categoryname == "5 Mayores de 18") {
                        let birthday = AppData.shared.profile_customerDetailData["birthday"] as! String
                        let birthdaystr = birthday.components(separatedBy: "-")
                        let birthdate: [String] = birthday.components(separatedBy: "-")
                        let birthyear : String = birthdate[0] as! String
                        let year : Int = Calendar.current.component(.year, from: Date())
                        let cal_year : Int = Int(birthdaystr[0]) as! Int
                        let age : Int = year - cal_year
                        if (age <= 18) {
                            let cartDialog = CartDialog(title: "", viewcontroller: self.viewcontroller)
                            cartDialog.show(animated: true)
                        }else {
                            if let tabItems = self.viewcontroller.tabBarController?.tabBar.items {
                                // In this case we want to modify the badge number of the third tab:
                                let tabItem = tabItems[1]
                                AppData.shared.cartBadge_number = AppData.shared.cartBadge_number + 1
                                UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
                                let badge_str = String(AppData.shared.cartBadge_number) as! String
                                
                                let product_name = cellProductData["productname"] as! String
                                var productcount = UserDefaults.standard.integer(forKey: product_name) ?? 0
                                if (productcount == 0){
                                    UserDefaults.standard.set(1, forKey: product_name)
                                    AppData.shared.cartProductData.add(self.cellProductData)
                                    let saveData :[String : Any] = ["cartproduct_array" : AppData.shared.cartProductData]
                                    UserDefaults.standard.set(saveData, forKey: "cart_dataarray")
                                }else {
                                    productcount = productcount + 1
                                    UserDefaults.standard.set(productcount, forKey: product_name)
                                }
                                tabItem.badgeValue = badge_str
                            }
                        }
                    }else {
                        if let tabItems = self.viewcontroller.tabBarController?.tabBar.items {
                            // In this case we want to modify the badge number of the third tab:
                            let tabItem = tabItems[1]
                            AppData.shared.cartBadge_number = AppData.shared.cartBadge_number + 1
                            UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
                            let badge_str = String(AppData.shared.cartBadge_number) as! String
                            
                            let product_name = cellProductData["productname"] as! String
                            var productcount = UserDefaults.standard.integer(forKey: product_name) as! Int ?? 0
                            print(productcount)
                            if (productcount == 0){
                                UserDefaults.standard.set(1, forKey: product_name)
                                print("first")
                                let index = AppData.shared.cartProductData.count
                                print("second")
                                print(index)
                                
                                
                                AppData.shared.cartProductData.add(self.cellProductData)
                                print("third")
                                
                                
                                let saveData :[String : Any] = ["cartproduct_array" : AppData.shared.cartProductData]
                                UserDefaults.standard.set(saveData, forKey: "cart_dataarray")
                            }else {
                                productcount = productcount + 1
                                UserDefaults.standard.set(productcount, forKey: product_name)
                            }
                            tabItem.badgeValue = badge_str
                        }
                    }
                }else {
                    let deliverzip = DeliverZip(title: "", viewcontroller: self.viewcontroller)
                    deliverzip.show(animated: true)
                }
            }else if (AppData.shared.wrong_warehouse == 0){
                let deliverzip = DeliverZip(title: "", viewcontroller: self.viewcontroller)
                deliverzip.show(animated: true)
                
                
            }
        }else {
           // AppData.shared.displayToastMessage("Please try Signin or Signup.")
            let alert = SignUpDialog(title: "",viewcontroller: self.viewcontroller)
            alert.show(animated: true)
            //return
        }
      
    }
   
}
