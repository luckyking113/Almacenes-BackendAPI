//
//  ProfileShippingAddressCell.swift
//  McFly
//
//  Created by LiuYan on 5/29/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class ProfileShippingAddressCell: UITableViewCell {

    @IBOutlet weak var ship_image: UIImageView!
    
    @IBOutlet weak var ship_name: UILabel!
    
    @IBOutlet weak var ship_address: UILabel!
    var selectshipindex : Int = 0
    var tableview: UITableView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func remove_shipdata(_ sender: Any) {
        AppData.shared.profile_shippingAddress.removeObject(at: self.selectshipindex)
        self.tableview.reloadData()
    }
    
}
