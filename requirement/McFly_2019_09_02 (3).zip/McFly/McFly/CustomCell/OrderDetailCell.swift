//
//  OrderDetailCell.swift
//  McFly
//
//  Created by LiuYan on 6/5/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class OrderDetailCell: UICollectionViewCell {
    
    @IBOutlet weak var order_imageview: UIImageView!
    
    @IBOutlet weak var product_name: UILabel!
    
    @IBOutlet weak var product_amount: UILabel!
    
    @IBOutlet weak var product_count: UILabel!
}
