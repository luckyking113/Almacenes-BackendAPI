//
//  OrderActiveCell.swift
//  McFly
//
//  Created by LiuYan on 6/7/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
class OrderActiveCell: UITableViewCell {

    @IBOutlet weak var order_idlbl: UILabel!
    
    @IBOutlet weak var order_statuslbl: UILabel!
    
    @IBOutlet weak var order_datelbl: UILabel!
    
    @IBOutlet weak var order_confirmbtn: UIButton!
    var cell_orderData = NSDictionary()
    var controller: UIViewController!
    var orderid: String = ""
    var orderNumber : Int = 0
    
    @IBOutlet weak var confrim_buttonheight: NSLayoutConstraint!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func Confirm_Order(_ sender: Any) {
        let orderstatus = self.cell_orderData["status"] as! String
        self.UpdateOrder()
    }
    func UpdateOrder(){
        let orderData = AppData.shared.order_Data[orderNumber] as! NSDictionary
       
        let jsondata: [String:Any] = ["orderid" : orderid, "driverid" : AppData.shared.profile_customerid,"drivername": "","status": "7"]
        let url = URL(string: AppConstants.baseUrl + "getOrder_detail/" + orderid)!
        print(url)
        Alamofire.request(url, method: .post,parameters: jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                if (message == "success"){
                    print("success")
                    let vc = self.controller.storyboard?.instantiateViewController(withIdentifier: "feedbackVC") as! FeedbackViewController
                    let orderid = orderData["id"] as! String
                    vc.orderid = orderid
                    vc.orderindex = self.orderNumber
                    self.controller.navigationController?.pushViewController(vc, animated: true)
                }else {
                    AppData.shared.displayToastMessage(message)
                }
                break
            case .failure(let error):
                print(error)
                
            }
        }
    }
}
