//
//  DetailCell.swift
//  McFly
//
//  Created by LiuYan on 6/16/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class DetailCell: UITableViewCell {

    
    
   
    
    @IBOutlet weak var cart_price: UILabel!
    @IBOutlet weak var cart_name: UILabel!
    var cellindex : Int = 0
    var viewcontroller : UIViewController!
    var tableView : UITableView!
    var cellcount: Int = 0
    var original: Int = 0
    @IBOutlet weak var product_count: UILabel!
    @IBOutlet weak var total_value: UILabel!
    var price : Double = 0
    var framevalue : CGRect!
    var indexPath : IndexPath!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        framevalue = self.frame
        // Configure the view for the selected state
    }
   
    
    @IBAction func minus_quantity(_ sender: Any) {
        if (self.cellcount <= 9){
            self.cellcount = self.cellcount + 1
            let str = String(self.cellcount) as! String
            self.product_count.text = str
            let value = price * Double(self.cellcount)
            let valuestr = String(value)
            self.total_value.text =  "$" + valuestr
            let pd_name = self.cart_name.text as! String
            AppData.shared.cartBadge_number = AppData.shared.cartBadge_number + 1
            UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
            UserDefaults.standard.set(cellcount, forKey: pd_name)
            self.viewcontroller.viewWillAppear(true)
        }
    }
    
    @IBAction func plus_puantity(_ sender: Any) {
        if (self.cellcount > 1 ){
            self.cellcount = self.cellcount - 1
            let str = String(self.cellcount) as! String
            self.product_count.text = str
            
            let value = price * Double(self.cellcount)
            if (value != 0) {
                let valuestr = String(value)
                self.total_value.text =  "$" + valuestr
            }else {
                self.total_value.text =  "$0"
            }
            if (self.cellcount == 0) {
                
            }
            let pd_name = self.cart_name.text as! String
            UserDefaults.standard.set(cellcount, forKey: pd_name)
            AppData.shared.cartBadge_number = AppData.shared.cartBadge_number - 1
            UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
            self.viewcontroller.viewWillAppear(true)
            
        }else {
            let cellData = AppData.shared.cartProductData[cellindex] as! NSDictionary
            let cartname = cellData["productname"] as! String
            AppData.shared.delete_data = cellData
            AppData.shared.delete_index = cellindex
            AppData.shared.cartProductData.removeObject(at: cellindex)
            self.viewcontroller.viewWillAppear(true)
            self.tableView.reloadData()
            
            let alert = CartDeleteDialog(title: cartname,vc:self.viewcontroller, tableview: self.tableView,index :self.cellindex)
            alert.show(animated: true)
        }
       
    }
    
    
}
