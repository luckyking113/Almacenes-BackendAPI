//
//  HomeCell2.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class HomeCell2: UICollectionViewCell {
    @IBOutlet weak var image2: UIImageView!
    override func awakeFromNib() {
        self.image2.layer.masksToBounds = false
        self.image2.layer.cornerRadius = 4
        self.image2.clipsToBounds = true
    }
}
