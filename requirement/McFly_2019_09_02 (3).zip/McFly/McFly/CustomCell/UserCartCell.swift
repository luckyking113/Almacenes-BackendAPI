//
//  UserCartCell.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class UserCartCell: UICollectionViewCell {
    
    @IBOutlet weak var user_cartImage: UIImageView!
    
    @IBOutlet weak var user_cartName: UILabel!
    
    @IBOutlet weak var user_cartCount: UILabel!
    
    @IBOutlet weak var userCartView: UIView!
    override func awakeFromNib() {
        userCartView.layer.cornerRadius = 3
        userCartView.layer.masksToBounds = true
    }
    @IBAction func Del_userCart(_ sender: Any) {
    
    }
}
