//
//  CardListCell.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import DLRadioButton
import Alamofire
class CardListCell: UITableViewCell {

    @IBOutlet weak var card_image: UIImageView!
    
    @IBOutlet weak var card_no: UILabel!
    
    @IBOutlet weak var card_number: UILabel!
    
    @IBOutlet weak var default_btn: RadioButton!
    var flag: Int = 0
    var cellCardData = NSDictionary()
    var controller = UIViewController()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func Set_defaultCard(_ sender: Any) {
        print("kkkk")
        if (flag == 0){
            default_btn.isSelected = true
            flag = 1
            self.checkDefault_Card()
        }
       
    }
    func set_card(flag_btn : Int){
        if (flag_btn == 1){
            default_btn.isSelected = true
            
        }else {
            default_btn.isSelected = false
             
        }
    }
    func checkDefault_Card(){
        let url = URL(string: AppConstants.baseUrl + "setDefaultCard")!
        
        let userEmail = AppData.shared.profile_customerDetailData["customer_cardnumber"] as! String
        let id = cellCardData["id"] as! String
        let jsondata:[String : Any] = ["user_stripe_customer": userEmail, "id" : id]
        Alamofire.request(url, method: .post,parameters : jsondata, encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                
                if (message == "success"){
                    print("success")
                    AppData.shared.cardDetailData = NSMutableArray()
                    if (jsonString.contains("data")){
                        let cardjsondata = responseData["data"] as! NSDictionary
                        let customer = cardjsondata["customer"] as! NSDictionary
                        AppData.shared.default_cardsource = customer["default_source"] as! String
                        let sourcedata = customer["sources"] as! NSDictionary
                        AppData.shared.cardDetailData = sourcedata["data"] as! NSMutableArray
                        self.controller.viewWillAppear(true)
//                        self.controller.navigationController?.pushViewController(vc, animated: true)
                        
                    }
                }
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    
    
    
}
