 //
//  HomeCell.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class HomeCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    override func awakeFromNib() {
        self.image.layer.masksToBounds = false
        self.image.layer.cornerRadius = 4
        self.image.clipsToBounds = true
    }
}
