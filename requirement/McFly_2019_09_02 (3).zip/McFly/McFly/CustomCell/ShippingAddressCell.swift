//
//  ShippingAddressCell.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class ShippingAddressCell: UITableViewCell {

    @IBOutlet weak var shipping_image: UIImageView!
    
    @IBOutlet weak var ship_name: UILabel!
    
    @IBOutlet weak var shipping_address: UILabel!
    var viewController : UIViewController!
    var secondController : UIViewController!
    var cellShipData = NSDictionary()
    var cellnumber : Int = 0
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func Edit_ShippingAddress(_ sender: Any) {
        let vc = viewController.storyboard?.instantiateViewController(withIdentifier: "newshipVC") as! AddNewShippingAddressViewController
        vc.flag_str = "edit"
        vc.address_Data = cellShipData
        AppData.shared.select_indexship = self.cellnumber
        secondController.dismiss(animated: true, completion: nil)
        viewController.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
