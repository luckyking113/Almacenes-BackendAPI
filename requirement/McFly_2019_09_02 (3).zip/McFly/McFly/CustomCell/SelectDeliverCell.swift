//
//  SelectDeliverCell.swift
//  McFly
//
//  Created by LiuYan on 6/15/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class SelectDeliverCell: UITableViewCell {

    
    @IBOutlet weak var address_lbl: UILabel!
    
    @IBOutlet weak var address_name: UILabel!
    @IBOutlet weak var address_image: UIImageView!
    @IBOutlet weak var setmain_btn: RadioButton!
    var main_flag : Int = 0
    
    var address : String = ""
    var viewcontroller = UIViewController()
    var cellData = NSDictionary()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        if (self.main_flag == 0){
            self.setmain_btn.isSelected = false
        }else {
            self.setmain_btn.isSelected = true
        }
        let delivergesture4 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        self.address_name.isUserInteractionEnabled = true
        self.address_name.addGestureRecognizer(delivergesture4)
        let delivergesture5 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        self.address_lbl.isUserInteractionEnabled = true
        self.address_lbl.addGestureRecognizer(delivergesture5)
        let delivergesture6 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        self.address_image.isUserInteractionEnabled = true
        self.address_image.addGestureRecognizer(delivergesture6)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @objc func SelectMainAddress(){
        if (self.main_flag == 0){
            self.setmain_btn.isSelected = true
            self.main_flag = 1
            let zipcode1 = self.cellData["address_zipcode"] as! String
            var flag : Int = 0
            let zipcodearray = AppConstants.warehouse_zipcode.components(separatedBy: ",")
            for index in 0..<zipcodearray.count {
                let zipcode = zipcodearray[index] as! String
                if (zipcode1.elementsEqual(zipcode)){
                    flag = 1
                   // AppData.shared.displayToastMessage("We can deliver in your area")
                    AppData.shared.wrong_warehouse = 1
                    let default_title = cellData["address_name"] as! String
                    let default_image = cellData["address_imageurl"] as! String
                    let default_zipcode = cellData["address_zipcode"] as! String
                    let default_id = cellData["address_id"] as! String
//                    if (AppData.shared.typed_flag == 0){
                        AppData.shared.default_maindeliveraddress = address
                        AppData.shared.default_maindelivertitle = default_title
                        AppData.shared.default_mainaddressimage = default_image
                        AppData.shared.customer_zipcode = default_zipcode
                        AppData.shared.default_maindeliverid = default_id
                        AppData.shared.show_address = ""
                        self.viewcontroller.viewWillAppear(true)
                        AppData.shared.set_flag = 1
//                    }else {
//                        if (default_zipcode == AppData.shared.customer_zipcode) {
//                            AppData.shared.default_maindeliveraddress = address
//                            AppData.shared.default_maindelivertitle = default_title
//                            AppData.shared.default_mainaddressimage = default_image
//                            AppData.shared.customer_zipcode = default_zipcode
//                            AppData.shared.default_maindeliverid = default_id
//                            self.viewcontroller.viewWillAppear(true)
//                        }else {
//                            AppData.shared.displayToastMessage("You have to select correct address with your zipcode")
//                        }
//                    }
                   
//                        UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
//                        UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
//                        UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
//                        UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
//                        UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
                    
                    
                    
                }
            }
            if (flag == 0){
                AppData.shared.set_flag = 0
                let default_title = cellData["address_name"] as! String
                let default_image = cellData["address_imageurl"] as! String
                let default_zipcode = cellData["address_zipcode"] as! String
                let default_id = cellData["address_id"] as! String
                AppData.shared.default_maindeliveraddress = address
                AppData.shared.default_maindelivertitle = default_title
                AppData.shared.default_mainaddressimage = default_image
                AppData.shared.customer_zipcode = default_zipcode
                AppData.shared.default_maindeliverid = default_id
                  AppData.shared.show_address = address
                self.viewcontroller.viewWillAppear(true)
//                if (AppData.shared.typed_flag == 0){
//                    AppData.shared.wrong_warehouse = 0
//                    self.setmain_btn.isSelected = true
//                    AppData.shared.default_maindeliveraddress = address
//                    AppData.shared.default_maindelivertitle = default_title
//                    AppData.shared.default_mainaddressimage = default_image
//                    AppData.shared.customer_zipcode = default_zipcode
//                    AppData.shared.default_maindeliverid = default_id
//                    self.viewcontroller.viewWillAppear(true)
//                }else {
//                    if (AppData.shared.customer_zipcode == default_zipcode){
//                        AppData.shared.displayToastMessage("Your zipcode does not match with our warehouse")
//                        return
//                    }else {
//                        AppData.shared.displayToastMessage("You have to select correct address with your typed zipcode")
//                        return
//                    }
//                }
//                UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
//                UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
//                UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
//                UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
//                UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
//                let count = AppData.shared.cartProductData.count as! Int
//                for i in 0..<count {
//                    let cartdata = AppData.shared.cartProductData[i] as! NSDictionary
//                    let cartname = cartdata["productname"] as! String
//                    UserDefaults.standard.set(0, forKey: cartname)
//                    AppData.shared.cartProductData.removeObject(at: i)
//
//                }
//                AppData.shared.initCartData()
//                UserDefaults.standard.set(0,forKey: "cartCount")
//                UserDefaults.standard.set(nil, forKey: "cart_dataarray")
                
                let alert = CheckZipCode(title: "",viewcontroller: self.viewcontroller)
                alert.show(animated: true)
            }
            
        }else {
            AppData.shared.set_flag = 0
            AppData.shared.wrong_warehouse = 1
            self.setmain_btn.isSelected = true
            AppData.shared.default_maindeliveraddress = ""
            AppData.shared.default_maindelivertitle = ""
            AppData.shared.default_mainaddressimage = ""
            AppData.shared.customer_zipcode = ""
            AppData.shared.default_maindeliverid = ""
              AppData.shared.show_address = ""
//            UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
//            UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
//            UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
//            UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
//            UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
            self.viewcontroller.viewWillAppear(true)
            self.main_flag = 0
        }
    }
    func set_card(flag_btn : Int){
        if (flag_btn == 1){
            setmain_btn.isSelected = true
            
        }else {
            setmain_btn.isSelected = false
            
        }
    }
    @IBAction func setMainAddres(_ sender: Any) {
        if (self.main_flag == 0){
            
            
            
            self.main_flag = 1
            let zipcode1 = self.cellData["address_zipcode"] as! String
            var flag : Int = 0
            let zipcodearray = AppConstants.warehouse_zipcode.components(separatedBy: ",")
            for index in 0..<zipcodearray.count {
                let zipcode = zipcodearray[index] as! String
                if (zipcode1.elementsEqual(zipcode)){
                   
                    AppData.shared.displayToastMessage("¡Felicidades! Estas dentro")
                   
                    let default_title = cellData["address_name"] as! String
                    let default_image = cellData["address_imageurl"] as! String
                    let default_zipcode = cellData["address_zipcode"] as! String
                    let default_id = cellData["address_id"] as! String
                    
//                    if (default_zipcode == AppData.shared.customer_zipcode) {
                        AppData.shared.wrong_warehouse = 1
                        self.setmain_btn.isSelected = true
                        AppData.shared.default_maindeliveraddress = address
                        AppData.shared.default_maindelivertitle = default_title
                        AppData.shared.default_mainaddressimage = default_image
                        AppData.shared.customer_zipcode = default_zipcode
                        AppData.shared.default_maindeliverid = default_id
                       AppData.shared.show_address = ""
                        flag = 1
                        self.viewcontroller.viewWillAppear(true)
                        AppData.shared.set_flag = 1
//                    }else {
//                            AppData.shared.displayToastMessage("You have to select correct address with your zipcode")
//                            return
//                        }
                    
//                        UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
//                        UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
//                        UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
//                        UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
//                        UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
                }
            }
            if (flag == 0){
               
                let default_title = cellData["address_name"] as! String
                let default_image = cellData["address_imageurl"] as! String
                let default_zipcode = cellData["address_zipcode"] as! String
                let default_id = cellData["address_id"] as! String
                AppData.shared.default_maindeliveraddress = address
                AppData.shared.show_address = address
                AppData.shared.default_maindelivertitle = default_title
                AppData.shared.default_mainaddressimage = default_image
                AppData.shared.customer_zipcode = default_zipcode
                AppData.shared.default_maindeliverid = default_id
                 AppData.shared.set_flag = 0
                self.viewcontroller.viewWillAppear(true)
//
//                    if (AppData.shared.customer_zipcode == default_zipcode){
//                        AppData.shared.displayToastMessage("Your zipcode does not match with our warehouse")
//                        return
//                    }else {
//                        AppData.shared.displayToastMessage("You have to select correct address with your typed zipcode")
//                        return
//                    }
                
                
//                UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
//                UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
//                UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
//                UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
//                UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
               
              
                let alert = CheckZipCode(title: "",viewcontroller: self.viewcontroller)
                alert.show(animated: true)
            }
            
        }else {
            AppData.shared.set_flag = 0
            AppData.shared.wrong_warehouse = 1
            self.setmain_btn.isSelected = true
            AppData.shared.default_maindeliveraddress = ""
            AppData.shared.default_maindelivertitle = ""
            AppData.shared.default_mainaddressimage = ""
            AppData.shared.customer_zipcode = ""
            AppData.shared.default_maindeliverid = ""
            AppData.shared.show_address = ""
//            UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
//            UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
//            UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
//            UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
//            UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
            self.viewcontroller.viewWillAppear(true)
            self.main_flag = 0
        }
    }
    
}
