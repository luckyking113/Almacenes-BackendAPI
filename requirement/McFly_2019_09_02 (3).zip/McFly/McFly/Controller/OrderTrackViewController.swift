//
//  OrderTrackViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class OrderTrackViewController: UIViewController {

   
    @IBOutlet weak var orderDetail_btn: UIButton!
    @IBOutlet weak var shareFriend_btn: UIButton!
   
    @IBOutlet weak var order_statusimage: UIImageView!
    @IBOutlet weak var orderid_lbl: UILabel!
    
    @IBOutlet weak var orderstatus_lbl: UILabel!
    
    var orderindex : Int = 0
    var order: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        let orderData = AppData.shared.order_Data[orderindex] as! NSDictionary
        let orderid = orderData["order_id"] as! String
        self.orderid_lbl.text = "¡El Doctor recibió tu orden! \n En breve, McFly te la entregará 😃"
        self.order = orderid
        let orderstatus = orderData["status"] as! String
        switch orderstatus {
            case "1":
                order_statusimage.image = UIImage(named: "stage_1.png")
                self.orderstatus_lbl.text = "Estatus: Pendiente"
                break
            case "2":
                order_statusimage.image = UIImage(named: "stage_2.png")
                 self.orderstatus_lbl.text = " Estatus:Procesando"
                break
            case "3":
                order_statusimage.image = UIImage(named: "stage_3.png")
                self.orderstatus_lbl.text = "Estatus: En Recolección"
                break
            case "4":
                order_statusimage.image = UIImage(named: "stage_4.png")
                self.orderstatus_lbl.text = "Estatus: Recolectada"
                break
            case "5":
                order_statusimage.image = UIImage(named: "stage_5.png")
                self.orderstatus_lbl.text = "Estatus: En Camino"
                break
            case "6":
                order_statusimage.image = UIImage(named: "stage_6.png")
                self.orderstatus_lbl.text = "Estatus: Entregado"
                break
            default:
                order_statusimage.image = UIImage(named: "stage_6.png")
                self.orderstatus_lbl.text = "Estatus: Entregado"
                break
        }
    }
    func initUI(){
        orderDetail_btn.layer.cornerRadius = 15
        orderDetail_btn.layer.masksToBounds = true
        shareFriend_btn.layer.cornerRadius = 15
        shareFriend_btn.layer.masksToBounds = true
        // Do any additional setup after loading the view.
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func OrderDetail_Page(_ sender: Any) {
//        orderDetail_btn.pulstate()
        AppData.shared.addgif(sender: orderDetail_btn)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "orderdetailVC") as! OrderDetailViewController
        vc.orderindex = self.orderindex
        self.navigationController?.pushViewController(vc, animated: true)
    }

    @IBAction func share_Friend(_ sender: Any) {
//        self.shareFriend_btn.pulstate()
        AppData.shared.addgif(sender: shareFriend_btn)
        let text = " ¡Hey, McFly! Checa esta app. Vende de todo y lo entrega en breve. Disponible en la AppStore. (appstore link)"
        let textShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textShare , applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        self.present(activityViewController, animated: true, completion: nil)
    }
    
}
