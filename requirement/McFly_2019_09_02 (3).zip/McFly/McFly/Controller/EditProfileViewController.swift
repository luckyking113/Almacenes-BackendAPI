//
//  EditProfileViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
 import Alamofire
class EditProfileViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
   
    

    @IBOutlet weak var user_image: UIImageView!
    @IBOutlet weak var user_firstName: UITextField!
    @IBOutlet weak var user_lastName: UITextField!
    @IBOutlet weak var user_phoneNumber: UITextField!
    @IBOutlet weak var user_Email: UITextField!
  
    @IBOutlet weak var user_shippingAddress: UITextField!
//    @IBOutlet weak var iClould_statusLabel: UILabel!
    
    @IBOutlet weak var user_birthDate: UITextField!
    
    @IBOutlet weak var save_profilebtn: UIButton!
    @IBOutlet weak var ship_tableView: UITableView!
    var uploadImage : UIImage!
    
    @IBOutlet weak var add_shipbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        
        showProfile()
    }
    func  initUI() {
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        self.user_image.layer.cornerRadius = self.user_image.frame.width / 2
        self.user_image.layer.masksToBounds = true
        let date_picker = UIDatePicker()
        date_picker.datePickerMode = .date
        user_birthDate.inputView = date_picker
        date_picker.addTarget(self, action: #selector(handleEndDatePicker(sender: )), for: .valueChanged)
//        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
//        ship_tableView.addGestureRecognizer(longPress)
    }
//    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
//        if sender.state == UIGestureRecognizer.State.began {
//            let touchPoint = sender.location(in: ship_tableView)
//            if let indexPath = ship_tableView.indexPathForRow(at: touchPoint) {
//                // your code here, get the row for the indexPath or do whatever you want
//                AppData.shared.select_indexship = indexPath.row
//                let vc = self.storyboard?.instantiateViewController(withIdentifier: "newshipVC") as! AddNewShippingAddressViewController
//                vc.flag_str = "edit"
//                vc.gotoFlag = "editprofile"
//                // vc.address_Data = cellShipData
//
//                self.navigationController?.pushViewController(vc, animated: true)
//                print("testtesttest")
//            }
//        }
//    }
    @objc func handleEndDatePicker(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        user_birthDate.text = dateFormatter.string(from: sender.date)
        user_birthDate.endEditing(true)
    }
    @objc func onClcikBack()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "profileVC") as! ProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func select_Photo(_ sender: Any) {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openPhotoLibrary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    func openCamera() {
        if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)) {
            // self.flag = 0
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You can't use the camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openPhotoLibrary() {
        //self.flag = 1
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[.editedImage] as? UIImage {
            uploadImage = image
            self.user_image.image = image
            self.UploadImage()
        }
        picker.dismiss(animated: true, completion: nil)
        
    }
    @IBAction func save_profile(_ sender: Any) {
//        self.save_profilebtn.pulstate()
        AppData.shared.addgif(sender: save_profilebtn)
        self.saveProfile()
    }
    func UploadImage(){
        
        let imageData = uploadImage.jpegData(compressionQuality: 0.8)
        let url = try! URLRequest(url: URL(string:AppConstants.baseUrl + "uploadImage")!, method: .post, headers: nil)
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                multipartFormData.append(imageData!, withName: "image", fileName: "file.png", mimeType: "image/png")
        },
            with: url,
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        if((response.result.value) != nil) {
                            print(response.result.value)
                            let data = response.result.value as! NSDictionary
                            let message = data["message"] as! String
                            if (message == "success" ){
                                let imageurl = data["image_url"] as! String
                                AppData.shared.profile_imageurl = imageurl
                            }
                        } else {
                            
                        }
                    }
                case .failure( _):
                    break
                }
        }
        )
    }
    
    func showProfile(){
        let firstname = AppData.shared.profile_customerDetailData["first_name"] as! String
        let lastname =    AppData.shared.profile_customerDetailData["last_name"] as! String
        self.user_firstName.text = firstname
        self.user_lastName.text = lastname
        let phoneNumber = AppData.shared.profile_customerDetailData["phone"] as! String
        self.user_phoneNumber.text = phoneNumber
        let image_url = AppData.shared.profile_customerDetailData["image"] as! String
        if (image_url.isEmpty){
            self.user_image.image = UIImage(named: "doc-512")
            
        }else{
            self.user_image.moa.url = image_url
        }
        
        let email = AppData.shared.profile_customerDetailData["email"] as! String
        self.user_Email.text = email
        let birthday = AppData.shared.profile_customerDetailData["birthday"] as! String
        self.user_birthDate.text = birthday
        //let zipcode = AppData.shared.profile_customerDetailData["zip"] as! String
        //self.user_Email.text = email
       
    }
    
    func saveProfile(){
        let email = self.user_Email.text as! String
        let firstname = self.user_firstName.text as! String
        let lastname = self.user_lastName.text  as! String
        let phonenumber = self.user_phoneNumber.text as! String
        let birthday = self.user_birthDate.text as! String
        let customerid = AppData.shared.profile_customerid
        let verified_type = AppData.shared.profile_customerDetailData["verifiedtype"] as! String
        let verified_value = AppData.shared.profile_customerDetailData["verfified_value"] as! String
        let fcmtoken = AppData.shared.profile_customerDetailData["token"] as! String
        AppData.shared.profile_customerDetailData.setValue(email, forKey: "email")
        AppData.shared.profile_customerDetailData.setValue(firstname, forKey: "first_name")
        AppData.shared.profile_customerDetailData.setValue(lastname, forKey: "last_name")
        AppData.shared.profile_customerDetailData.setValue(phonenumber, forKey: "phone")
        AppData.shared.profile_customerDetailData.setValue(AppData.shared.profile_imageurl, forKey: "image")
        var InputShippnigData = NSMutableArray()
        for index in 0..<AppData.shared.profile_shippingAddress.count {
            let shippingData = AppData.shared.profile_shippingAddress[index] as! NSDictionary
            let address_name = shippingData["address_name"] as! String
            let address_lat = shippingData["address_lat"] as! String
            let address_lng = shippingData["address_lng"] as! String
            let address_zip = shippingData["address_zipcode"] as! String
            let address_location = shippingData["address_location"] as! String
            let address_imageurl = shippingData["address_imageurl"] as! String
            let inputshipping :[String :Any] = ["address_name" : address_name,"address_location" : address_location,"address_lat" : address_lat, "address_lng" : address_lng, "address_zip": address_zip , "address_imageurl" : address_imageurl]
            InputShippnigData.add(inputshipping)
        }
        
        
        
        let url = URL(string: AppConstants.baseUrl + "updateprofile")!
        let jsondata: [String: Any] = [ "customerid" : AppData.shared.profile_customerid,"email" : email,"firstname" : firstname, "lastname" : lastname, "verifiedtype": verified_type,"verified_value" : verified_value ,"fcmtoken" : fcmtoken,"photourl" : AppData.shared.profile_imageurl,"password": "","birthday": birthday, "phone" : phonenumber, "shippingaddress" : InputShippnigData]
        print(jsondata)
        if let json = try? JSONSerialization.data(withJSONObject: jsondata, options: []) {
            if let content = String(data: json, encoding: String.Encoding.utf8) {
                // here `content` is the JSON dictionary containing the String
                let data : [String: Any] = ["json" : content]
                
                Alamofire.request(url, method: .post, parameters : data ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            AppData.shared.profile_discountArray = responseData["discountcodes"] as! NSMutableArray
                            AppData.shared.profile_customerid = responseData["customer_id"] as! String
                            AppData.shared.profile_customerDetailData.setValue(firstname, forKey: "first_name")
                            AppData.shared.profile_customerDetailData.setValue(lastname, forKey: "last_name")
                            AppData.shared.profile_customerDetailData.setValue(phonenumber, forKey: "phone")
                            AppData.shared.profile_customerDetailData.setValue(AppData.shared.profile_imageurl, forKey: "image")
                            AppData.shared.profile_customerDetailData.setValue(birthday, forKey: "birthday")
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "profileVC") as! ProfileViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                            
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                    }
                }
            }
        }
    }
    
  
}
