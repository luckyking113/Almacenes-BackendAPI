//
//  SearchViewController.swift
//  McFly
//
//  Created by LiuYan on 6/7/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController,UISearchBarDelegate{

    @IBOutlet weak var search_product: UISearchBar!
    
    @IBOutlet weak var searchResult_view: UICollectionView!
    
    @IBOutlet weak var selectVIew: UIView!
    
    @IBOutlet weak var subcat_btn1: UIButton!
    
    @IBOutlet weak var subcat_btn2: UIButton!
    
    @IBOutlet weak var subcat_btn3: UIButton!
    
    @IBOutlet weak var subcat_btn4: UIButton!
    var filterProducts = NSMutableArray()
    var subcatData1 = NSMutableArray()
    var subcatData2 = NSMutableArray()
    var subcatData3 = NSMutableArray()
    var subcatData4 = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        // Do any additional setup after loading the view.
    }
    func initUI(){
        //init Status
        self.searchResult_view.isHidden = true
        self.selectVIew.isHidden = false
        self.subcat_btn1.isHidden = false
        self.subcat_btn2.isHidden = false
        self.subcat_btn3.isHidden = false
        self.subcat_btn4.isHidden = false
        self.search_product.delegate = self
        self.searchResult_view.delegate = self
        self.searchResult_view.dataSource = self
        //Set Button title
        
        let sub1 = AppData.shared.categroy_Data[0] as! NSDictionary
        let sub1_name = sub1["cat_name"] as! String
        subcat_btn1.setTitle(sub1_name, for: .normal)
        let sub2 = AppData.shared.categroy_Data[1] as! NSDictionary
        let sub2_name = sub2["cat_name"] as! String
        subcat_btn2.setTitle(sub2_name, for: .normal)
        let sub3 = AppData.shared.categroy_Data[2] as! NSDictionary
        let sub3_name = sub3["cat_name"] as! String
        subcat_btn3.setTitle(sub3_name, for: .normal)
        let sub4 = AppData.shared.categroy_Data[3] as! NSDictionary
        let sub4_name = sub4["cat_name"] as! String
        subcat_btn1.setTitle(sub4_name, for: .normal)
        
        // Set SubCategory Data...
        for index in 0..<AppData.shared.product_Data.count {
            let product = AppData.shared.product_Data[index] as! NSDictionary
            let product_subname = product["cat_name"] as! String
            if (product_subname == sub1_name){
                self.subcatData1.add(product)
            }else if (product_subname == sub2_name) {
                self.subcatData2.add(product)
            }else if (product_subname == sub3_name) {
                self.subcatData3.add(product)
            }else if (product_subname == sub4_name){
                self.subcatData4 .add(product)
            }
        }
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        let bound  = searchResult_view.bounds
        layout.sectionInset = UIEdgeInsets(top: 20, left: 0, bottom: 10, right: 0)
        layout.itemSize = CGSize(width: bound.width/3, height: bound.height / 3)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        searchResult_view!.collectionViewLayout = layout
        
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SearchViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    override func viewWillAppear(_ animated: Bool) {
         self.searchResult_view.reloadData()
    }
    func showResult(){
        self.searchResult_view.isHidden = false
        self.searchResult_view.reloadData()
        self.selectVIew.isHidden = true
        self.subcat_btn1.isHidden = true
        self.subcat_btn2.isHidden = true
        self.subcat_btn3.isHidden = true
        self.subcat_btn4.isHidden = true
        self.viewWillAppear(true)
    }
    
    @IBAction func Search_sub1(_ sender: Any) {
        self.filterProducts = self.subcatData1
        self.search_product.text = subcat_btn1.titleLabel?.text
        self.showResult()
    }
    @IBAction func Search_sub2(_ sender: Any) {
        self.filterProducts = self.subcatData2
        self.search_product.text = subcat_btn2.titleLabel?.text
        self.showResult()
    }
    @IBAction func Search_sub3(_ sender: Any) {
        self.filterProducts = self.subcatData3
        self.search_product.text = subcat_btn3.titleLabel?.text
        self.showResult()
    }
    @IBAction func Search_sub4(_ sender: Any) {
//        self.filterProducts = self.subcatData4
//        self.search_product.text = subcat_btn4.titleLabel?.text
//        self.showResult()
    }
    func getData(keystring : String){
        self.filterProducts = NSMutableArray()
        for index in 0..<AppData.shared.product_Data.count {
            let product = AppData.shared.product_Data[index] as! NSDictionary
            let catname = product["cat_name"] as! String
            let subcatname = product["subcat_name"] as! String
            let productname = product["productname"] as! String
            if (catname.contains(keystring) || subcatname.contains(keystring) || productname.contains(keystring) ){
                self.filterProducts.add(product)
            }
        }
        self.showResult()
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if (searchText.count == 0){
            self.searchResult_view.isHidden = true
            self.selectVIew.isHidden = false
            self.subcat_btn1.isHidden = false
            self.subcat_btn2.isHidden = false
            self.subcat_btn3.isHidden = false
            self.subcat_btn4.isHidden = false
        }else {
            self.getData(keystring: searchText)
        }
        
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        self.search_product.endEditing(true)
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    
}
extension SearchViewController: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filterProducts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "searchcell", for: indexPath) as! SearchCell
        let product_data = filterProducts[indexPath.row] as! NSDictionary
        let image_name = product_data["productimage"] as! String
        let img_url = URL(string: AppConstants.imageproduct_url + image_name)!
        print(img_url)
        //            AppData.shared.downloadImage(from: img_url, imageView: cell.subimageView)
        cell.search_image.moa.url = AppConstants.imageproduct_url + image_name
        cell.search_image.moa.errorImage = UIImage(named: "placeholder")
        cell.search_pdprice.text = product_data["product_price"] as! String
        cell.search_pdName.text = product_data["productname"] as! String
        cell.viewcontroller = self
        cell.cellProductData = product_data
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "productVC") as! ProductViewController
        let product_data = filterProducts[indexPath.row] as! NSDictionary
        vc.product_detailData = product_data
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension SearchViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let bounds = collectionView.bounds
        return CGSize(width: bounds.width / 3, height: bounds.height / 3)
    }
}
