//
//  CartSubViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import moa
class CartSubViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
  
    

   
    
    @IBOutlet weak var usrCart_totalValue: UILabel!
    @IBOutlet weak var user_DiscountCode: UIView!
    @IBOutlet weak var userCartCollectionView: UICollectionView!
    @IBOutlet weak var userSelectCollectionView: UICollectionView!
    
    @IBOutlet weak var user_discount: UITextField!
    
    @IBOutlet weak var goto_homePage: UIButton!
    var randomProduct = NSMutableArray()
    var selectProduct = NSMutableArray()
    var randomNameStr : [String] = []
    
    
    @IBOutlet weak var empty_cart: UILabel!
    @IBOutlet weak var keep_shopbtn: UIButton!
    @IBOutlet weak var detail_tableView: UITableView!
    
    @IBOutlet weak var detail_btn: UIButton!
    
    
    @IBOutlet weak var view_height: NSLayoutConstraint!
    @IBOutlet weak var detail_containerheight: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userCartCollectionView.delegate = self
        userCartCollectionView.dataSource = self
        userSelectCollectionView.delegate = self
        userSelectCollectionView.dataSource = self
        detail_tableView.dataSource = self
        detail_tableView.delegate = self
        initUI()
        
       
    }
    func initUI(){
        user_DiscountCode.layer.borderColor = UIColor.gray.cgColor
        user_DiscountCode.layer.borderWidth = 0.5
        user_DiscountCode.layer.cornerRadius = 25
        user_DiscountCode.layer.masksToBounds = true
        user_discount.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        let newFrame : CGRect = CGRect( origin: CGPoint(x: self.view.frame.origin.x, y: self.view.frame.origin.y), size: CGSize(width: self.view.frame.width, height: 650))
        
        self.view.frame = newFrame
        
        
        detail_containerheight.constant = 225
        view_height.constant = 700
        
        detail_tableView.isHidden = true
        
    }
    @objc func textFieldDidChange(_ textField: UITextField) {
        AppData.shared.select_discountcode = self.user_discount.text as! String
    }
    
    @IBAction func Detail_Show(_ sender: Any) {
        let btn_string : String = detail_btn.titleLabel?.text ?? ""
        if (btn_string == "Detalles(+)"){
            detail_btn.setTitle("Detalles(-)", for: .normal)
            
//            let newFrame : CGRect = CGRect( origin: CGPoint(x: self.view.frame.origin.x, y: self.view.frame.origin.y), size: CGSize(width: self.view.frame.width, height: CGFloat(650 + 43 * AppData.shared.cartProductData.count)))
//            
//            self.view.frame = newFrame
            detail_containerheight.constant = CGFloat(225 + 43 * AppData.shared.cartProductData.count)
            view_height.constant = CGFloat(700 + 43 * AppData.shared.cartProductData.count)
            detail_tableView.isHidden = false
            detail_tableView.reloadData()
        }else if (btn_string == "Detalles(-)") {
            detail_btn.setTitle("Detalles(+)", for: .normal)
//            let newFrame : CGRect = CGRect( origin: CGPoint(x: self.view.frame.origin.x, y: self.view.frame.origin.y), size: CGSize(width: self.view.frame.width, height: 650))
//
//            self.view.frame = newFrame
            detail_containerheight.constant = 225
            view_height.constant = 700
            detail_tableView.isHidden = true
        }
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppData.shared.cartProductData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "detailCell", for: indexPath) as! DetailCell
        let cellData = AppData.shared.cartProductData[indexPath.row] as! NSDictionary
        let cartname = cellData["productname"] as! String
        let cartcount = UserDefaults.standard.integer(forKey: cartname) as! Int ?? 0
        if (cartcount != 0){
            let price = cellData["product_price"] as! String
            let db_price  = Double(price) as! Double
            let db_count = Double(cartcount) as! Double
            let each_total = db_price * db_count
            let show_total = db_price.format(f: ".2")
            let price_string = "$" + show_total
            cell.product_count.isHidden = false
           // cell.cart_price.isHidden = false
            cell.cart_name.isHidden = false
            cell.price = db_price
            cell.indexPath = indexPath
            cell.product_count.text = String(cartcount)
            cell.original = cartcount
            cell.cellcount = cartcount
            cell.total_value.text =  price_string
          //  cell.cart_price.text = "$" + price
            cell.cart_name.text = cartname
            cell.cellindex = indexPath.row
            cell.viewcontroller = self
            cell.tableView = tableView
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 43
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let personal = UIContextualAction(style: .normal, title: ""){
            (action,view,nil) in
            print("Personal")
            let cellData = AppData.shared.cartProductData[indexPath.row] as! NSDictionary
            let cartname = cellData["productname"] as! String
            let alert = CartDeleteDialog(title: cartname,vc:self, tableview: tableView,index :indexPath.row)
            alert.show(animated: true)
        }
        personal.backgroundColor = UIColor.red
        personal.image =  UIImage(named: "trash1")
        
        return UISwipeActionsConfiguration(actions: [personal])
    }
    
    
    
    
    
    @IBAction func Go_Home(_ sender: Any) {
        AppData.shared.addgif(sender: self.keep_shopbtn)
        if (AppData.shared.customer_zipcode == ""){
            let alert = SubmitZipCode(title: "",viewcontroller: self)
            alert.show(animated: true)
        }else {
            let alert = LoadingDialog(title: "" , viewcontroller: self)
            alert.show(animated: true)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        if (AppData.shared.cartProductData.count > 0){
            self.empty_cart.isHidden = true
            var total_price : Float = 0
            for index in 0..<AppData.shared.cartProductData.count {
                let pd_data = AppData.shared.cartProductData[index] as! NSDictionary
                let pd_name = pd_data["productname"] as! String
                let price = pd_data["product_price"] as! String
                let re_price = Float(price) as! Float
                let count = UserDefaults.standard.integer(forKey: pd_name) ?? 0
                let fl_count =  Float(count)
                total_price = total_price + re_price * fl_count
               
                AppData.shared.customer_totalPrice = total_price
            }
           // let total_str = String(total_price) as! String
             let show_total = total_price.format(f: ".2")
            usrCart_totalValue.text = "$" + show_total
           
            if (detail_tableView.isHidden == false){
                detail_btn.setTitle("Detalles(-)", for: .normal)
                detail_containerheight.constant = CGFloat(225 + 43 * AppData.shared.cartProductData.count)
                view_height.constant = CGFloat(700 + 43 * AppData.shared.cartProductData.count)
            }else {
                detail_btn.setTitle("Detalles(+)", for: .normal)
            }
            detail_tableView.reloadData()
            
        }else {
            self.empty_cart.isHidden = false
            detail_btn.setTitle("Detalles", for: .normal)
            detail_tableView.reloadData()
             usrCart_totalValue.text = ""
        }
        if (AppData.shared.categroy_Data.count > 0){
            for index in 0..<AppData.shared.categroy_Data.count {
                let each_data = AppData.shared.categroy_Data[index] as! NSDictionary
                let subCategory = each_data["subcategory"] as! NSMutableArray
                for sub_index in 0..<subCategory.count {
                    let each_subdata = subCategory[sub_index] as! NSDictionary
                    let product_Data = each_subdata["products"] as! NSMutableArray
                    for pd_index in 0..<product_Data.count {
                        let product = product_Data[pd_index] as! NSDictionary
                        self.randomProduct.add(product)
                    }
                }
            }
            let rand_count = randomProduct.count as! Int
            let limit_count = 8
            for rand_index in 0..<randomProduct.count {
                let random_number = Int.random(in: 0..<rand_count)
                let rand_product = randomProduct[random_number] as! NSDictionary
                let rand_name = rand_product["productname"] as! String
                if (!self.randomNameStr.contains(rand_name)){
                    self.selectProduct.add(rand_product)
                    randomNameStr.append(rand_name)
                }
                if (self.selectProduct.count > limit_count){
                    break;
                }
            }
        }
        self.userCartCollectionView.reloadData()
        self.userSelectCollectionView.reloadData()
    }
}
extension CartSubViewController: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (collectionView == self.userCartCollectionView){
            return AppData.shared.cartProductData.count
        }
        else {
            return self.selectProduct.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if (collectionView == self.userCartCollectionView){
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "usercartCell", for: indexPath) as! UserCartCell
            let product = AppData.shared.cartProductData[indexPath.row] as! NSDictionary
            let pd_image = product["productimage"] as! String
            let pd_name = product["productname"] as! String
            let pd_price = product["product_price"] as! String
            let imageurl = AppConstants.imageproduct_url + pd_image
            let count = UserDefaults.standard.integer(forKey: pd_name)
            let count_str = String(count)
            cell.user_cartImage.moa.url = imageurl
            cell.user_cartImage.moa.errorImage = UIImage(named: "placeholder")
            cell.user_cartName.text = pd_name
            cell.user_cartCount.text = "$" + pd_price
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "userselectCell", for: indexPath) as! UserSelectCell
            let product =  self.selectProduct[indexPath.row] as! NSDictionary
            let pd_image = product["productimage"] as! String
            let pd_name = product["productname"] as! String
            cell.user_selectname.text = pd_name
            cell.user_selectImage.moa.url = AppConstants.imageproduct_url + pd_image
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "productVC") as! ProductViewController
        if (collectionView == self.userCartCollectionView) {
            vc.product_detailData = AppData.shared.cartProductData[indexPath.row] as! NSDictionary
        }else {
            vc.product_detailData = self.selectProduct[indexPath.row] as! NSDictionary
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension CartSubViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if (collectionView == self.userCartCollectionView){
            let bounds = collectionView.bounds
            return CGSize(width: 120, height: 180)
        }else {
            let bounds = collectionView.bounds
            return CGSize(width: 120, height: 200)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
extension Float {
    func format(f: String) -> String {
        return String(format: "%\(f)f", self)
    }
}
extension Double {
    func format(f: String) -> String {
        return String(format: "%\(f)f", self)
    }
}
