//
//  SignUp2ViewController.swift
//  McFly
//
//  Created by LiuYan on 5/29/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
class SignUp2ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UITextFieldDelegate{

    @IBOutlet weak var profile_img: UIImageView!
    @IBOutlet weak var profile_firstName: UITextField!
    @IBOutlet weak var profile_LastName: UITextField!
    @IBOutlet weak var profile_PhoneNumber: UITextField!
    @IBOutlet weak var profile_Email: UITextField!
    
    @IBOutlet weak var profile_saveBtn: UIButton!
    
    @IBOutlet weak var profile_BirthDate: UITextField!
    var uploadImage : UIImage!
    
    @IBOutlet weak var name_view: UIView!
    @IBOutlet weak var mobile_numberView: UIView!
    
    @IBOutlet weak var lastname_view: UIView!
    
    @IBOutlet weak var birthday_view: UIView!
    
    @IBOutlet weak var email_view: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profile_firstName.delegate = self
        profile_LastName.delegate = self
        profile_PhoneNumber.delegate = self
        profile_Email.delegate = self
        profile_BirthDate.delegate = self
        
        
        
        self.navigationController?.navigationBar.isHidden = false
        profile_img.layer.cornerRadius = profile_img.frame.width / 2
        profile_img.layer.masksToBounds = true
        profile_saveBtn.layer.cornerRadius = 15
        profile_saveBtn.layer.masksToBounds = true
      
//        name_view.layer.borderColor = UIColor.blue.cgColor
//        name_view.layer.borderWidth = 1
//        name_view.layer.cornerRadius = 3
//        name_view.layer.masksToBounds = true
//        
//        lastname_view.layer.borderColor = UIColor.blue.cgColor
//        lastname_view.layer.borderWidth = 1
//        lastname_view.layer.cornerRadius = 3
//        lastname_view.layer.masksToBounds = true
//        
//        mobile_numberView.layer.borderColor = UIColor.blue.cgColor
//        mobile_numberView.layer.borderWidth = 1
//        mobile_numberView.layer.cornerRadius = 3
//        mobile_numberView.layer.masksToBounds = true
//        
//        birthday_view.layer.borderColor = UIColor.blue.cgColor
//        birthday_view.layer.borderWidth = 1
//        birthday_view.layer.cornerRadius = 3
//        birthday_view.layer.masksToBounds = true
//        
//        email_view.layer.borderColor = UIColor.blue.cgColor
//        email_view.layer.borderWidth = 1
//        email_view.layer.cornerRadius = 3
//        email_view.layer.masksToBounds = true
        
        
        if (AppData.shared.profile_useremail != ""){
            profile_Email.text = AppData.shared.profile_useremail
            profile_Email.layer.backgroundColor = UIColor.white.cgColor
            profile_Email.isEnabled = false
            profile_Email.isUserInteractionEnabled = false
        }
        if (AppData.shared.profile_phoneNumber != ""){
            profile_PhoneNumber.text = AppData.shared.profile_phoneNumber
            profile_PhoneNumber.layer.backgroundColor = UIColor.white.cgColor
            profile_PhoneNumber.isEnabled = false
            profile_PhoneNumber.isUserInteractionEnabled = false
        }
        if (!AppData.shared.profile_firstname.isEmpty) {
            self.profile_firstName.layer.backgroundColor = UIColor.white.cgColor
        }
        if (!AppData.shared.profile_lastname.isEmpty){
            self.profile_LastName.layer.backgroundColor = UIColor.white.cgColor
        }
        self.profile_firstName.text = AppData.shared.profile_firstname
        self.profile_LastName.text = AppData.shared.profile_lastname
        self.profile_BirthDate.addTarget(self, action: #selector(myTargetFunction), for: .touchDown)
        self.profile_BirthDate.endEditing(true)
        
        
        
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        // Do any additional setup after loading the view.
    }
    @objc func myTargetFunction(textField: UITextField) {
        print("myTargetFunction")
        self.profile_BirthDate.endEditing(true)
        self.profile_BirthDate.layer.backgroundColor = UIColor.white.cgColor
        let datedialog = CustomDatePicker(title: "", textfield: self.profile_BirthDate)
        datedialog.show(animated: true)
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (textField == self.profile_BirthDate){
            return false
        }else{
            return true
        }
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if (textField == self.profile_BirthDate){
            self.profile_BirthDate.endEditing(true)
        }
        textField.layer.backgroundColor = UIColor.white.cgColor
    }
    func textFieldShouldReturn(textField: UITextField!) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        if (textField == self.profile_BirthDate){
            textField.resignFirstResponder()
        }
        return true;
    }
    @objc func onClcikBack()
    {
        if (AppData.shared.profile_phoneNumber != ""){
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signinVC") as! SiginInViewController
            //self.present(verificationController, animated: true, completion: nil)
            self.navigationController?.pushViewController(verificationController, animated: true)
        }else {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signinVC") as! SiginInViewController
            //self.present(verificationController, animated: true, completion: nil)
            self.navigationController?.pushViewController(verificationController, animated: true)
        }
        
    }
    @IBAction func select_photo(_ sender: Any) {
        let alert = UIAlertController(title: "Elegir imagen", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Cámara", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Galeria", style: .default, handler: { _ in
            self.openPhotoLibrary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancelar", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
   
    
    @IBAction func save_profile(_ sender: Any) {
        self.profile_saveBtn.pulstate()
        let firstname = profile_firstName.text as! String
        if (firstname.isEmpty){
            self.showAlert("Escribe tu nombre!")
            return
        }else{
            AppData.shared.profile_firstname = firstname
        }
        let lastname = profile_LastName.text as! String
        if (lastname.isEmpty){
            self.showAlert("Escribe tu apellido!")
            return
        }else {
            AppData.shared.profile_lastname = lastname
        }
        let phonenumber = profile_PhoneNumber.text as! String
        if (phonenumber.isEmpty){
            self.showAlert("Escribe tu número de celular!")
            return
        }else {
            AppData.shared.profile_phoneNumber = phonenumber
        }
        let email = profile_Email.text as! String
        if (email.isEmpty){
            self.showAlert("Escribe tu correo electrónico!")
            return
        }else{
            AppData.shared.profile_useremail = email
        }
        let birthdate = profile_BirthDate.text as! String
        if (birthdate.isEmpty){
            self.showAlert("Anota tu fecha de nacimiento!")
            return
        }else {
            AppData.shared.profile_birthdate = birthdate
        }
      //  print(birthdate)
        self.saveProfile()
    }
    
    func openCamera() {
        if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera)) {
           // self.flag = 0
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You can't use the camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openPhotoLibrary() {
        //self.flag = 1
        let imagePicker = UIImagePickerController()
         imagePicker.delegate = self
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[.editedImage] as? UIImage {
            uploadImage = image
            self.profile_img.image = image
            self.UploadImage()
        }
        picker.dismiss(animated: true, completion: nil)
        
    }
   

    func UploadImage(){
       
        let imageData = uploadImage.jpegData(compressionQuality: 0.8)
        let url = try! URLRequest(url: URL(string:AppConstants.baseUrl + "uploadImage")!, method: .post, headers: nil)
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                multipartFormData.append(imageData!, withName: "image", fileName: "file.png", mimeType: "image/png")
        },
            with: url,
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        if((response.result.value) != nil) {
                            print(response.result.value)
                            let data = response.result.value as! NSDictionary
                            let message = data["message"] as! String
                            if (message == "success" ){
                                let imageurl = data["image_url"] as! String
                                AppData.shared.profile_imageurl = imageurl
                            }
                        } else {
                            
                        }
                    }
                case .failure( _):
                    break
                }
        }
        )
    }
    func saveProfile(){
         let url = URL(string: AppConstants.baseUrl + "customersignup")!
        let jsondata: [String: Any] = ["email" : AppData.shared.profile_useremail,"firstname" : AppData.shared.profile_firstname, "lastname" : AppData.shared.profile_lastname, "verifiedtype": AppData.shared.profile_accountType,"verified_value" : AppData.shared.profile_verficationvalue ,"fcmtoken" : AppData.shared.profile_fcmtoken,"photourl" : AppData.shared.profile_imageurl,"password": "", "phone" : AppData.shared.profile_phoneNumber, "shippingaddress" : AppData.shared.profile_shippingAddress, "birthday" : AppData.shared.profile_birthdate]
         print(jsondata)
        if let json = try? JSONSerialization.data(withJSONObject: jsondata, options: []) {
            if let content = String(data: json, encoding: String.Encoding.utf8) {
                // here `content` is the JSON dictionary containing the String
                let data : [String: Any] = ["json" : content]
              
                Alamofire.request(url, method: .post, parameters : data ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            AppData.shared.profile_discountArray = responseData["discountcodes"] as! NSMutableArray
                            let cus_id = responseData["customer_id"] as! Int
                            AppData.shared.profile_customerid = String(cus_id) as! String
                            self.Profile_data()
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                    }
                }
            }
        }
    }
    func Profile_data(){
        let url = URL(string: AppConstants.baseUrl + "customerlogin")!
        let jsondata: [String: Any] = ["verified_type": AppData.shared.profile_accountType,"verified_value" : AppData.shared.profile_verficationvalue ,"fcmToken" : AppData.shared.profile_fcmtoken]
        print(jsondata)
        Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                print(responseData)
                let message  = responseData["message"] as! String
                if (message == "success"){
                    AppData.shared.profile_loginstatus = true
                    let customer_detail = responseData["customerdetail"] as! NSMutableArray
                    AppData.shared.profile_customerDetailData = customer_detail[0] as! NSDictionary
                    AppData.shared.profile_customerid = AppData.shared.profile_customerDetailData["id"] as! String
                    let discountcodes = responseData["discountcodes"] as! NSMutableArray
                    AppData.shared.profile_discountArray = discountcodes
                    let shipppingaddress = responseData["shippingaddresses"] as! NSMutableArray
                    AppData.shared.profile_shippingAddress = shipppingaddress
                    AppData.shared.set_flag = 0
                    if (jsonString.contains("carddetail")){
                        let carddetailData = responseData["carddetail"] as! NSDictionary
                        AppData.shared.profile_carddetailData = carddetailData
                        let default_sourcecard = carddetailData["default_source"] as! String
                        AppData.shared.default_cardsource = default_sourcecard
                        let source = carddetailData["sources"] as! NSDictionary
                        let carddetail_datas = source["data"] as! NSMutableArray
                        AppData.shared.cardDetailData = carddetail_datas
                        
                    }
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "onboardVC") as! OnBoardVC
                    self.present(verificationController, animated: true, completion: nil)
                    
                }else if(message == "There is no registered account" && AppData.shared.profile_accountType != 0)  {
//                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
//                    //   self.present(verificationController, animated: true, completion: nil)
//                    self.navigationController?.pushViewController(verificationController, animated: true)
                }
                
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    func showAlert(_ message: String) {
        let alertController = UIAlertController(title: "Signup Process", message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertAction.Style.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
}
