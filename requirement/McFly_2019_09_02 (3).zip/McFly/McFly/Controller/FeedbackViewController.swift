//
//  FeedbackViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Cosmos
import Alamofire
class FeedbackViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource, UITextViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 9
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickerView.isHidden = true
        let strvalue = String(row + 1) as! String
        finalTip = strvalue
        AppData.shared.displayToastMessage("Your Tip is $" + strvalue)
        btn_other.setTitle("$" + strvalue, for: .normal)
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let titlestr = String(row + 1) as! String
        return titlestr
    }

    @IBOutlet weak var rating_bar: CosmosView!
    
    @IBOutlet weak var review_field: UITextView!
    
    @IBOutlet weak var review_submitbtn: UIButton!
    
    @IBOutlet weak var driver_tipView: UIView!
    
    @IBOutlet weak var btn_10: UIButton!
    @IBOutlet weak var btn_20: UIButton!
    @IBOutlet weak var btn_30: UIButton!
    @IBOutlet weak var btn_40: UIButton!
    
    @IBOutlet weak var btn_other: UIButton!
    var finalTip : String = "0.0"
    var orderid: String = ""
    var cardid : String = ""
    var orderindex : Int = 0
    var paytype : String = ""
    
    
    @IBOutlet weak var tipPickerView: UIPickerView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        self.title = ""
        
        // Do any additional setup after loading the view.
    }
    func initUI(){
        tipPickerView.isHidden = true
        tipPickerView.delegate = self
        tipPickerView.dataSource = self
        driver_tipView.layer.borderColor = UIColor.gray.cgColor
        driver_tipView.layer.borderWidth = 0.5
        
        btn_10.layer.borderColor = UIColor.gray.cgColor
        btn_10.layer.borderWidth = 0.5
        
        btn_20.layer.borderColor = UIColor.gray.cgColor
        btn_20.layer.borderWidth = 0.5
        
        btn_30.layer.borderColor = UIColor.gray.cgColor
        btn_30.layer.borderWidth = 0.5
        
        btn_40.layer.borderColor = UIColor.gray.cgColor
        btn_40.layer.borderWidth = 0.5
        
        btn_other.layer.borderColor = UIColor.gray.cgColor
        btn_other.layer.borderWidth = 0.5
        
        review_submitbtn.layer.cornerRadius = 15
        review_submitbtn.layer.masksToBounds = true
        
        rating_bar.settings.updateOnTouch = true
        rating_bar.didTouchCosmos = { rating in }
        rating_bar.didFinishTouchingCosmos = { rating in }
        self.review_field.layer.borderColor = UIColor.lightGray.cgColor
            self.review_field.layer.borderWidth = 1
            self.review_field.layer.cornerRadius = 5
            self.review_field.layer.masksToBounds = true
        self.review_field.text = "Escribe tu reseña aquí"
        self.review_field.textColor = UIColor.lightGray
        self.review_field.delegate = self
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Escribe tu reseña aquí"
            textView.textColor = UIColor.lightGray
        }
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func share_FeedBack(_ sender: Any) {
        let text = "  Hey! I ordered " + "on McFly.Check out my app at https://play.google.com/store/apps//details?id=com.xianshu.mcfly"
        let textShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textShare , applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction func Tip_10(_ sender: Any) {
        finalTip = "10"
        AppData.shared.displayToastMessage("Your Tip is $10")
    }
    @IBAction func Tip_20(_ sender: Any) {
        finalTip = "15"
        AppData.shared.displayToastMessage("Your Tip is $15")
    }
    @IBAction func Tip_30(_ sender: Any) {
        finalTip = "20"
        AppData.shared.displayToastMessage("Your Tip is $20")
    }
    @IBAction func Tip_40(_ sender: Any) {
        finalTip = "25"
        AppData.shared.displayToastMessage("Your Tip is $25")
    }
    @IBAction func Tip_Other(_ sender: Any) {
        tipPickerView.isHidden = false
        
    }
    
    
    @IBAction func Submit_FeedBack(_ sender: Any) {
//        self.review_submitbtn.pulstate()
        AppData.shared.addgif(sender: review_submitbtn)
        let feedback = self.review_field.text as! String
        let rating = self.rating_bar.rating as! Double
        let ratingString = String(rating) as! String
        let firstname = AppData.shared.profile_customerDetailData["first_name"] as! String
        let lastname = AppData.shared.profile_customerDetailData["last_name"] as! String
        let customername = firstname + lastname
        let customer_cardnumber = AppData.shared.profile_customerDetailData["customer_cardnumber"] as! String
        let orderData = AppData.shared.order_Data[orderindex] as! NSDictionary
        let orderCardNumber = orderData["card_number"] as! String
        if (orderCardNumber == "Cash" || orderCardNumber == "POS") {
            self.paytype = "0"
        }else {
            self.paytype = "1"
        }
        for index in 0..<AppData.shared.cardDetailData.count {
            let carddata = AppData.shared.cardDetailData[index] as! NSDictionary
            let card_id = carddata["id"] as! String
            if (card_id == AppData.shared.default_cardsource) {
                self.cardid = card_id
            }
        }
        let jsondata: [String:Any] = ["orderid" : orderid, "rating" : ratingString,"feedback": feedback,"tip": finalTip,"customername" : customername,
                                      "user_stripe_customer": customer_cardnumber,"card_id": cardid,"paytype" : self.paytype]
        print(jsondata)
        let url = URL(string: AppConstants.baseUrl + "provideFeedback")!
        print(url)
        Alamofire.request(url, method: .post,parameters: jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                if (message == "success"){
                    print("success")
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                    self.present(verificationController, animated: true, completion: nil)
                }else {
                    AppData.shared.displayToastMessage(message)
                }
                break
            case .failure(let error):
                print(error)

            }
        }
    }
    func showCardData(){
        if (AppData.shared.cardDetailData.count > 0){
            for index  in 0..<AppData.shared.cardDetailData.count {
                let cardData = AppData.shared.cardDetailData[index] as! NSDictionary
                let cardid = cardData["id"] as! String
                if (AppData.shared.default_cardsource == cardid){
                    let object = cardData["object"] as! String
                    if (object == "card") {
                       self.cardid = cardid
                        let cardtype = cardData["brand"] as! String
                        let cardtype_sm = cardtype.lowercased()
                        switch (cardtype_sm) {
                            case "visa" :
                                break
                            case "mastercard" :
                                break
                            case "american express" :
                                break
                            case "discover" :
                                
                                break
                            case "diners_club" :
                                break
                            case "jcb" :
                                break
                            default:
                                break
                        }
                       
                       
                        
                    }
                }
                
            }
        }else {
            
        }
    }
}
