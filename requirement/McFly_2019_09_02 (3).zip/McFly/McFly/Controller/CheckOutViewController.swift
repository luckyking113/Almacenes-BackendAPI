//
//  CheckOutViewController.swift
//  McFly
//
//  Created by LiuYan on 6/2/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import DLRadioButton
import Alamofire
import moa
class CheckOutViewController: UIViewController {
    
    
    @IBOutlet weak var deliver_address: UILabel!
    @IBOutlet weak var deliver_phoneNumber: UILabel!
    
    @IBOutlet weak var card_typeimage: UIImageView!
    @IBOutlet weak var card_name: UILabel!
    @IBOutlet weak var cash_infolabel: UILabel!
    
    @IBOutlet weak var cash_infoline: UILabel!
    
    @IBOutlet weak var cash_infovalue: UITextField!
    @IBOutlet weak var card_number: UILabel!
    
    @IBOutlet weak var card_radio: DLRadioButton!
    
    @IBOutlet weak var cash_radio: DLRadioButton!
    
    @IBOutlet weak var terminal: DLRadioButton!
    
    @IBOutlet weak var subtotal_lbl: UILabel!
    
    @IBOutlet weak var delivery_lbl: UILabel!
    
    @IBOutlet weak var taxtotal_lbl: UILabel!
    
    @IBOutlet weak var discount_lbl: UILabel!
    
    @IBOutlet weak var checkout_btn: UIButton!
    @IBOutlet weak var total_lbl: UILabel!
    
    @IBOutlet weak var edit_cardbtn: UIButton!
    var order_eachprices: String = ""
    var order_prices : String = ""
    var order_images : String = ""
    var order_names : String = ""
    var order_ids: String = ""
    var order_quantities: String = ""
    var order_amount : String = ""
    var sub_total: String = ""
    var tax_total: String = ""
    var card_numberstr : String = ""
    var cash_amount : String = ""
    var card_id : String = ""
    var total_value : Float = 0
    
    @IBOutlet weak var maindeliver_image: UIImageView!
    
    @IBOutlet weak var maindeliver_view: UILabel!
    
    @IBOutlet weak var maindeliver_title: UILabel!
    
    @IBOutlet weak var select_cardview: CardView!
    
    @IBOutlet weak var select_cardtitle: UILabel!
    
    @IBOutlet weak var selectcard_subview: UIView!
    
    @IBOutlet weak var terminal_label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        
        let cardgesture1 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        select_cardview.addGestureRecognizer(cardgesture1)
        let cardgesture2 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        select_cardtitle.addGestureRecognizer(cardgesture2)
        let cardgesture3 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        selectcard_subview.addGestureRecognizer(cardgesture3)
        let cardgesture4 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        card_typeimage.addGestureRecognizer(cardgesture4)
        let cardgesture5 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        card_name.addGestureRecognizer(cardgesture5)
        let cardgesture6 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        card_number.addGestureRecognizer(cardgesture6)
        
        
        let delivergesture1 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        maindeliver_image.addGestureRecognizer(delivergesture1)
        let delivergesture2 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        maindeliver_view.addGestureRecognizer(delivergesture2)
        let delivergesture3 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        maindeliver_title.addGestureRecognizer(delivergesture3)
      //  let delivergesture4 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        
        
        
    }
  
    
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @objc func SelectMainAddress(){
        // do other task
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @objc func cardlist(){
        // do other task
        if (self.card_number.isHidden == false){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "cardlistVC") as! CardListViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    @IBAction func Edit_CardNumber(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "cardlistVC") as! CardListViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func Checkout_action(_ sender: Any) {
        //self.checkout_btn.pulstate()
        AppData.shared.addgif(sender: checkout_btn)
        placeNewOrder()
    }
    
    @IBAction func card_button(_ sender: Any) {
        self.card_number.isHidden = false
        self.card_typeimage.isHidden = false
        self.card_name.isHidden = false
        self.edit_cardbtn.isHidden = false
        self.cash_infoline.isHidden = true
        self.cash_infolabel.isHidden = true
        self.cash_infovalue.isHidden = true
        self.card_numberstr = self.card_id
        self.terminal_label.isHidden = true
    }
    
    @IBAction func cash_radiobutton(_ sender: Any) {
        self.card_number.isHidden = true
        self.card_typeimage.isHidden = true
        self.card_name.isHidden = true
        self.edit_cardbtn.isHidden = true
        self.cash_infoline.isHidden = false
        self.cash_infolabel.isHidden = false
        self.cash_infovalue.isHidden = false
        self.card_numberstr = "Cash"
        self.terminal_label.isHidden = true
    }
    
    @IBAction func terminal_cardradiobutton(_ sender: Any) {
        self.card_number.isHidden = true
        self.card_typeimage.isHidden = true
        self.card_name.isHidden = true
        self.edit_cardbtn.isHidden = true
        self.cash_infoline.isHidden = true
        self.cash_infolabel.isHidden = true
        self.cash_infovalue.isHidden = true
        self.card_numberstr = "POS"
        self.terminal_label.isHidden = false
    }
    override func viewWillAppear(_ animated: Bool) {
        showCardData()
        orderData()
        self.maindeliver_image.moa.url = AppData.shared.default_mainaddressimage
        self.deliver_address.text = AppData.shared.default_maindeliveraddress
        let phonenumber = AppData.shared.profile_customerDetailData["phone"] as! String
        self.deliver_phoneNumber.text = phonenumber
        let ware_housedeliveryfee : String = AppData.shared.ware_houseData["delivery_fee"] as! String
        self.delivery_lbl.text = "$" + ware_housedeliveryfee
      //  self.discount_lbl.text = AppData.shared.select_discountcode
    }
    func showCardData(){
        if (AppData.shared.cardDetailData.count > 0){
            for index  in 0..<AppData.shared.cardDetailData.count {
                let cardData = AppData.shared.cardDetailData[index] as! NSDictionary
                let cardid = cardData["id"] as! String
                if (AppData.shared.default_cardsource == cardid){
                    let object = cardData["object"] as! String
                    if (object == "card") {
                        self.card_radio.isSelected = true
                        self.cash_radio.isSelected = false
                        self.terminal.isSelected = false
                        self.card_number.isHidden = false
                        self.card_typeimage.isHidden = false
                        self.card_name.isHidden = false
                        self.edit_cardbtn.isHidden = false
                        self.cash_infoline.isHidden = true
                        self.cash_infolabel.isHidden = true
                        self.cash_infovalue.isHidden = true
                        let cardtype = cardData["brand"] as! String
                        let cardtype_sm = cardtype.lowercased()
                        switch (cardtype_sm) {
                            case "visa" :
                                self.card_typeimage.image = UIImage(named: "stp_card_visa")
                                break
                            case "mastercard" :
                                self.card_typeimage.image = UIImage(named: "stp_card_mastercard")
                                break
                            case "american express" :
                                self.card_typeimage.image = UIImage(named: "stp_card_amex")
                                break
                            case "discover" :
                                self.card_typeimage.image = UIImage(named: "stp_card_discover")
                                break
                            case "diners_club" :
                                self.card_typeimage.image = UIImage(named: "stp_card_diners")
                            case "jcb" :
                                self.card_typeimage.image = UIImage(named: "stp_card_jcb")
                            default:
                                self.card_typeimage.image = UIImage(named: "stp_card_unknown")
                        }
                        self.card_name.text = cardtype
                        let last4 = cardData["last4"] as! String
                        self.card_number.text = "**** **** " + last4
                        self.card_id = cardid
                        self.card_numberstr = self.card_id
                        //print(self.card_numberstr)
                    }
                }
                
            }
        }
    }
    func orderData(){
        if (AppData.shared.cartProductData.count > 0){
            var sub_totalvalue : Float = 0
            var taxtotoal_value : Float = 0
            for index in 0..<AppData.shared.cartProductData.count {
                let carteachData = AppData.shared.cartProductData[index] as! NSDictionary
                let product_id = carteachData["productid"] as! String
                let product_price = carteachData["product_price"] as! String
                let product_tax = carteachData["product_tax"] as! String
                let product_name = carteachData["productname"] as! String
                let product_images = carteachData["productimage"] as! String
                let count: Int = UserDefaults.standard.integer(forKey: product_name)
                let countstr: String  = String(count)
                let each_total : Float =  Float(product_price) as! Float  * Float(count)  as! Float
                let price_str: String = String(each_total) as! String
                sub_totalvalue = sub_totalvalue + each_total
                let tax_value : Float = Float(product_tax) as! Float
                taxtotoal_value = taxtotoal_value + each_total * tax_value
                if (self.order_ids == ""){
                    self.order_ids += product_id
                    self.order_quantities += countstr
                    self.order_eachprices += product_price
                    self.order_images += product_images
                    self.order_names += product_name
                    self.order_prices += price_str
                }else {
                    self.order_ids += "," + product_id
                    self.order_quantities += "," + countstr
                    self.order_eachprices += "," + product_price
                    self.order_images += "," + product_images
                    self.order_names += "," + product_name
                    self.order_prices += "," + price_str
                }
            }
            //print(self.order_ids)
           // print(self.order_names)
            self.sub_total = String(sub_totalvalue)
            self.tax_total = String(taxtotoal_value)
            self.subtotal_lbl.text = "$" + self.sub_total
            self.taxtotal_lbl.text = "$" + self.tax_total
            let ware_housedeliveryfee : String = AppData.shared.ware_houseData["delivery_fee"] as! String
            let float_fee : Float = Float(ware_housedeliveryfee) as! Float
            let totalvalue : Float = sub_totalvalue + taxtotoal_value + float_fee
            let totalstr : String = String(totalvalue)
            
            if (AppData.shared.select_discountcode == ""){
                self.discount_lbl.isEnabled = false
                self.discount_lbl.text = ""
                self.total_lbl.text = "$" + totalstr
                self.total_value = 100 * totalvalue
            }else {
               
                let count : Int = AppData.shared.profile_discountArray.count
                var flag: Int = 0
                for index in 0..<count {
                    let discountdata = AppData.shared.profile_discountArray[index] as! NSDictionary
                    let discountname = discountdata["name"] as! String
                    if (discountname.elementsEqual(AppData.shared.select_discountcode)){
                        flag = 1
                        self.discount_lbl.isEnabled = true
                        self.discount_lbl.text = AppData.shared.select_discountcode
                        let discountvalue = discountdata["value"] as! String
                        let discountcode: Float = Float(discountvalue) as! Float
                        let dis_totalvalue = totalvalue * (100 - discountcode) / 100
                        let dis_totalstr: String = String(dis_totalvalue) as! String
                        self.total_lbl.text = "$" + dis_totalstr
                        self.total_value = 100 * dis_totalvalue
                        
                    }
                }
                if (flag == 0){
                    AppData.shared.displayToastMessage("Your discount name is wrong")
                    self.discount_lbl.isEnabled = false
                    self.discount_lbl.text = ""
                    self.total_lbl.text = "$" + totalstr
                    self.total_value = 100 * totalvalue
                }
            }
         }
    }
    func placeNewOrder() {
        var url : URL!
       
        url = URL(string: AppConstants.baseUrl + "placeNeworder")!
        let customer_cardname = AppData.shared.profile_customerDetailData["customer_cardname"] ?? "null"
        let customer_cardnumber = AppData.shared.profile_customerDetailData["customer_cardnumber"] ?? "null"
       
        let shipping_address = AppData.shared.default_maindeliverid
        let warehouse_id = AppData.shared.ware_houseData["id"] as! String
        let warehouse_name = AppData.shared.ware_houseData["name"] as! String
        if (self.card_numberstr == self.card_id) {
            let  jsondata : [String : Any] = ["customer_id" : AppData.shared.profile_customerid,"product_ids" : self.order_ids,"product_quantities" : self.order_quantities ,"amount" : String(self.total_value),"card_number": self.card_id, "cash_amount": "0" , "payment_method" : customer_cardname,"shipping_address" : shipping_address, "warehouse_id": warehouse_id ,"user_stripe_customer" : customer_cardnumber, "warehouse_name": warehouse_name, "product_prices": self.order_prices, "product_images": self.order_images, "product_names": self.order_names]
            print(jsondata)
            
            Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
                response in

                switch response.result {
                case .success:
                    print(response)
                    let jsonString = response.result.value as! String
                    let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                    let message  = responseData["message"] as! String

                    if (message == "success"){
                        print("success")
                        AppData.shared.cartProductData = NSMutableArray()
                        AppData.shared.order_Data = NSMutableArray()
                       
                        UserDefaults.standard.removeObject(forKey: "cart_dataarray")
                        UserDefaults.standard.removeObject(forKey: "cartCount")
                        //UserDefaults.standard.integer(forKey: "cartCount")
                        let alert = LoadingDialog(title: "" , viewcontroller: self)
                        alert.show(animated: true)

                    }
                    break
                case .failure(let error):

                    print(error)
                }
            }

            
            
        }else if (self.card_numberstr == "Cash") {
            let cashamount = self.cash_infovalue.text as! String
            let  jsondata : [String : Any]  = ["customer_id" : AppData.shared.profile_customerid,"product_ids" : self.order_ids,"product_quantities" : self.order_quantities ,"amount" : String(self.total_value),"card_number": "Cash", "cash_amount": cashamount , "payment_method" : customer_cardname,"shipping_address" : shipping_address, "warehouse_id": warehouse_id ,"user_stripe_customer" : customer_cardnumber, "warehouse_name": warehouse_name, "product_prices": self.order_prices, "product_images": self.order_images, "product_names": self.order_names]
            print(jsondata)
            
            Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
                response in
                
                switch response.result {
                case .success:
                    print(response)
                    let jsonString = response.result.value as! String
                    let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                    let message  = responseData["message"] as! String
                    
                    if (message == "success"){
                        print("success")
                        AppData.shared.cartProductData = NSMutableArray()
                        AppData.shared.order_Data = NSMutableArray()
                        
                        UserDefaults.standard.removeObject(forKey: "cart_dataarray")
                        UserDefaults.standard.removeObject(forKey: "cartCount")
                        //UserDefaults.standard.integer(forKey: "cartCount")
                        let alert = LoadingDialog(title: "" , viewcontroller: self)
                        alert.show(animated: true)
                        
                    }
                    break
                case .failure(let error):
                    
                    print(error)
                }
            }

        }else if (self.card_numberstr == "POS") {
            let  jsondata : [String : Any] = ["customer_id" : AppData.shared.profile_customerid,"product_ids" : self.order_ids,"product_quantities" : self.order_quantities ,"amount" : String(self.total_value),"card_number": "POS", "cash_amount": "0" , "payment_method" : customer_cardname,"shipping_address" : shipping_address, "warehouse_id": warehouse_id ,"user_stripe_customer" : customer_cardnumber, "warehouse_name": warehouse_name, "product_prices": self.order_prices, "product_images": self.order_images, "product_names": self.order_names]
            print(jsondata)
            
            Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
                response in
                
                switch response.result {
                case .success:
                    print(response)
                    let jsonString = response.result.value as! String
                    let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                    let message  = responseData["message"] as! String
                    
                    if (message == "success"){
                        print("success")
                        AppData.shared.cartProductData = NSMutableArray()
                        AppData.shared.order_Data = NSMutableArray()
                        
                        UserDefaults.standard.removeObject(forKey: "cart_dataarray")
                        UserDefaults.standard.removeObject(forKey: "cartCount")
                        //UserDefaults.standard.integer(forKey: "cartCount")
                        let alert = LoadingDialog(title: "" , viewcontroller: self)
                        alert.show(animated: true)
                        
                    }
                    break
                case .failure(let error):
                    
                    print(error)
                }
            }

        }
        
        
       
//
    }
}
