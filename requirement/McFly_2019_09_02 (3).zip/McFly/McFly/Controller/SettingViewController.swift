//
//  SettingViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
class SettingViewController: UIViewController {

    
    @IBOutlet weak var notification_switch: UISwitch!
    
    @IBOutlet weak var discount_switch: UISwitch!
    var status_value : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    func initUI(){
        //Set BackButton ........
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        
    }
    override func viewWillAppear(_ animated: Bool) {
        let notification_value = AppData.shared.profile_customerDetailData["allow_stageemail"] as! String
        let discount_value = AppData.shared.profile_customerDetailData["allow_discountemail"] as! String
        if (notification_value == "0"){
            self.notification_switch.setOn(true, animated: true)
        }else {
            self.notification_switch.setOn(false, animated: true)
        }
        if (discount_value == "0"){
            self.discount_switch.setOn(true, animated: true)
        }else {
            self.discount_switch.setOn(false, animated: true)
        }
    }
    
    @IBAction func notification_Action(_ sender: Any) {
        let staus = self.notification_switch.isOn
        print("testvalue")
        print(staus)
        self.UpdateSetting(allowparam: 0, status: staus)
    }
    
    @IBAction func discount_Action(_ sender: Any) {
        let staus = self.discount_switch.isOn
        print("secondvalue")
        print(staus)
        self.UpdateSetting(allowparam: 1, status: staus)
    }
    func UpdateSetting(allowparam : Int,status: Bool){
        print(status)
        if (status){
            self.status_value = 0
        }else {
            self.status_value = 1
        }
        let url = URL(string: AppConstants.baseUrl + "updateEmailconfirm")!
        let jsondata: [String: Any] = [ "customerid" : AppData.shared.profile_customerid,"allow_param" : allowparam,"value" : self.status_value]
        print(jsondata)
        if let json = try? JSONSerialization.data(withJSONObject: jsondata, options: []) {
            if let content = String(data: json, encoding: String.Encoding.utf8) {
                // here `content` is the JSON dictionary containing the String
                Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            let valueStr: String = String(self.status_value)
                            if (allowparam == 0){
                                AppData.shared.profile_customerDetailData.setValue(valueStr, forKeyPath: "allow_stageemail")
                                let printvalue = AppData.shared.profile_customerDetailData["allow_stageemail"] as! String
                                print(printvalue)
                            }else {
                                 AppData.shared.profile_customerDetailData.setValue(valueStr, forKeyPath: "allow_discountemail")
                                let printvalue = AppData.shared.profile_customerDetailData["allow_discountemail"] as! String
                                print(printvalue)
                            }
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                    }
                }
            }
        }
    }
    
}
