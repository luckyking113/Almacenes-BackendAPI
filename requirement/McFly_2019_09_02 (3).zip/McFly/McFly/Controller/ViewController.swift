//
//  ViewController.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import SwiftGifOrigin
import CoreLocation
class ViewController: UIViewController,CLLocationManagerDelegate{
    var locationManager = CLLocationManager()
    @IBOutlet weak var splash_imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let stest = 3 / 2 as! Int
        print(stest)
        self.showLocation()
        AppData.shared.uiColorArray.append(AppData.shared.color1)
        AppData.shared.uiColorArray.append(AppData.shared.color2)
        AppData.shared.uiColorArray.append(AppData.shared.color3)
        AppData.shared.uiColorArray.append(AppData.shared.color4)
        AppData.shared.uiColorArray.append(AppData.shared.color5)
        AppData.shared.uiColorArray.append(AppData.shared.color6)
        AppData.shared.uiColorArray.append(AppData.shared.color7)
        AppData.shared.uiColorArray.append(AppData.shared.color8)
        AppData.shared.uiColorArray.append(AppData.shared.color9)
        AppData.shared.uiColorArray.append(AppData.shared.color1)
        AppData.shared.uiColorArray.append(AppData.shared.color2)
        AppData.shared.uiColorArray.append(AppData.shared.color3)
        AppData.shared.uiColorArray.append(AppData.shared.color4)
        AppData.shared.uiColorArray.append(AppData.shared.color5)
        AppData.shared.uiColorArray.append(AppData.shared.color6)
        AppData.shared.uiColorArray.append(AppData.shared.color7)
        AppData.shared.uiColorArray.append(AppData.shared.color8)
        AppData.shared.uiColorArray.append(AppData.shared.color9)
        
        AppData.shared.profile_verficationvalue = UserDefaults.standard.string(forKey: "verified_value") ?? ""
       
        if (AppData.shared.profile_verficationvalue != ""){
            AppData.shared.default_maindeliveraddress = UserDefaults.standard.string(forKey: "main_deliveraddress") ?? ""
            AppData.shared.default_maindelivertitle = UserDefaults.standard.string(forKey: "main_delivertitle") ?? ""
            AppData.shared.default_maindeliverid = UserDefaults.standard.string(forKey: "main_deliverid") ?? ""
            AppData.shared.default_mainaddressimage = UserDefaults.standard.string(forKey: "main_imageurl") ?? ""
            AppData.shared.customer_zipcode = UserDefaults.standard.string(forKey: "main_zipcode") ?? ""
          //  AppData.shared.default_maindeliverid = UserDefaults.standard.string(forKey: "main_deliverid") ?? ""
            AppData.shared.set_flag = 1
            AppData.shared.zipdialog_flag  = 0
            print(AppData.shared.default_maindeliverid)
        }else {
            AppData.shared.default_maindeliveraddress = ""
            AppData.shared.default_maindelivertitle = ""
            AppData.shared.default_maindeliverid = ""
            AppData.shared.default_mainaddressimage = ""
            AppData.shared.customer_zipcode = ""
            AppData.shared.set_flag = 1
           // AppData.shared.default_maindeliverid = ""
        }
        let cartDictionay : [String : Any] = UserDefaults.standard.value(forKey: "cart_dataarray") as? [String: Any] ?? [:]
        if (cartDictionay.isEmpty) {
            
        }else {
            AppData.shared.cartProductData = NSMutableArray()
            let cartData = cartDictionay["cartproduct_array"] as! NSMutableArray
            let data_count = cartData.count
            if (data_count > 0) {
                for index in 0..<data_count {
                    let cart_eachData = cartData[index] as! NSDictionary
                    AppData.shared.cartProductData.add(cart_eachData)
                }
            }
        }
        // UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
        // Do any additional setup after loading the view, typically from a nib.
       self.navigationController?.navigationBar.isHidden = true
       self.splash_imageView.image = UIImage.gif(asset: "splash")
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.5) { // Change `2.0` to the desired number of seconds.
            // Code you want to be delayed
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signinVC") as! SiginInViewController
           // self.present(verificationController, animated: true, completion: nil)
            self.navigationController?.pushViewController(verificationController, animated: true)
            //self.present(verificationController, animated: true, completion: nil)
        }
    }
    func showLocation (){
        let locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Check for Location Services
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
        }
        
        //Zoom to user location
        if let userLocation = locationManager.location?.coordinate {
            let lat = userLocation.latitude as! Double
            let lng = userLocation.longitude as! Double
            
        }
        
        self.locationManager = locationManager
        
        DispatchQueue.main.async {
            self.locationManager.startUpdatingLocation()
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "hh a" // "a" prints "pm" or "am"
        let hourString = formatter.string(from: Date())
        print("hourString")
        print(hourString)
        
    }


}


