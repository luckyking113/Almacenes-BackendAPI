//
//  SelectMainDeliverAddressViewController.swift
//  McFly
//
//  Created by LiuYan on 6/15/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import moa
class SelectMainDeliverAddressViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    
    @IBOutlet weak var Show_messagelbl: UILabel!
    @IBOutlet weak var address_listView: UITableView!
    
    @IBOutlet weak var Add_Addresbtn: UIButton!
    var goback: String = ""
    
    @IBOutlet weak var select_name: UILabel!
    
    @IBOutlet weak var selected_address: UILabel!
    
    @IBOutlet weak var selected_image: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        address_listView.delegate = self
        address_listView.dataSource = self
        Add_Addresbtn.layer.cornerRadius = 25
        Add_Addresbtn.layer.masksToBounds = true
        // Do any additional setup after loading the view.
       
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        address_listView.addGestureRecognizer(longPress)
    }
    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
        if sender.state == UIGestureRecognizer.State.began {
            let touchPoint = sender.location(in: address_listView)
            if let indexPath = address_listView.indexPathForRow(at: touchPoint) {
                // your code here, get the row for the indexPath or do whatever you want
                //AppData.shared.select_indexship = indexPath.row
                let cellData = AppData.shared.profile_shippingAddress[indexPath.row] as! NSDictionary
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "newshipVC") as! AddNewShippingAddressViewController
                vc.flag_str = "edit"
                vc.gotoFlag = "maindeliver"
                AppData.shared.gotopage = self.goback
                vc.address_Data = cellData
                vc.ship_index = indexPath.row
                AppData.shared.selectship_image = ""
                AppData.shared.select_shipname = ""
                AppData.shared.select_shipzipcode = ""
                
               // vc.address_Data = cellShipData
                
                self.navigationController?.pushViewController(vc, animated: true)
                print("testtesttest")
            }
        }
    }
    @objc func onClcikBack()
    {
       if (goback == "profile"){
        let default_id = UserDefaults.standard.string(forKey: "main_deliverid") ?? ""
        let default_zipcode = UserDefaults.standard.string(forKey: "main_zipcode") ?? ""
        if (default_id == AppData.shared.default_maindeliverid) {
            AppData.shared.zipdialog_flag = 1
        }else {
            AppData.shared.zipdialog_flag = 0
            UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
            UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
            UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
            UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
            UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
            if (AppData.shared.cartProductData.count > 0) {
                for index in 0..<AppData.shared.cartProductData.count {
                    let cartData = AppData.shared.cartProductData[index] as! NSDictionary
                    let cartName = cartData["productname"] as! String
                    UserDefaults.standard.set(0, forKey: cartName)
                }
            }
            AppData.shared.initCartData()
            UserDefaults.standard.set(0,forKey: "cartCount")
            UserDefaults.standard.set(nil, forKey: "cart_dataarray")
        }
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "profileVC") as! ProfileViewController
            self.navigationController?.pushViewController(vc, animated: true)
       }else if (goback == "home"){
//            AppData.shared.wrong_warehouse = 1
       
        
            if (AppData.shared.set_flag == 1){
                let default_id = UserDefaults.standard.string(forKey: "main_deliverid") ?? ""
                let default_zipcode = UserDefaults.standard.string(forKey: "main_zipcode") ?? ""
                if (default_zipcode != ""){
                    if (default_id == AppData.shared.default_maindeliverid) {
                        AppData.shared.zipdialog_flag = 1
                    }else {
                        AppData.shared.zipdialog_flag = 0
                        UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
                        UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
                        UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
                        UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
                        UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
                        print("saved")
                        if (AppData.shared.cartProductData.count > 0) {
                            for index in 0..<AppData.shared.cartProductData.count {
                                let cartData = AppData.shared.cartProductData[index] as! NSDictionary
                                let cartName = cartData["productname"] as! String
                                UserDefaults.standard.set(0, forKey: cartName)
                            }
                        }
                        AppData.shared.initCartData()
                        UserDefaults.standard.set(0,forKey: "cartCount")
                        UserDefaults.standard.set(nil, forKey: "cart_dataarray")
                    }
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                    self.present(verificationController, animated: true, completion: nil)
                }else {
                    AppData.shared.zipdialog_flag = 0
                    UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
                    UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
                    UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
                    UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
                    UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
                    print("saved")
                    if (AppData.shared.cartProductData.count > 0) {
                        for index in 0..<AppData.shared.cartProductData.count {
                            let cartData = AppData.shared.cartProductData[index] as! NSDictionary
                            let cartName = cartData["productname"] as! String
                            UserDefaults.standard.set(0, forKey: cartName)
                        }
                    }
                    AppData.shared.initCartData()
                    UserDefaults.standard.set(0,forKey: "cartCount")
                    UserDefaults.standard.set(nil, forKey: "cart_dataarray")
                
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                    self.present(verificationController, animated: true, completion: nil)
                }
               
            }else {
                UserDefaults.standard.set("", forKey: "main_deliveraddress")
                UserDefaults.standard.set("", forKey: "main_delivertitle")
                UserDefaults.standard.set("", forKey: "main_imageurl")
                UserDefaults.standard.set("", forKey: "main_zipcode")
                UserDefaults.standard.set("", forKey: "main_deliverid")
                if (AppData.shared.cartProductData.count > 0) {
                    for index in 0..<AppData.shared.cartProductData.count {
                        let cartData = AppData.shared.cartProductData[index] as! NSDictionary
                        let cartName = cartData["productname"] as! String
                        UserDefaults.standard.set(0, forKey: cartName)
                    }
                }
                AppData.shared.initCartData()
                UserDefaults.standard.set(0,forKey: "cartCount")
                UserDefaults.standard.set(nil, forKey: "cart_dataarray")
                let alert = LoadingDialog(title: "" , viewcontroller: self)
                alert.show(animated: true)
            }
       }
       else {
            let default_id = UserDefaults.standard.string(forKey: "main_deliverid") ?? ""
            let default_zipcode = UserDefaults.standard.string(forKey: "main_zipcode") ?? ""
            if (default_id == AppData.shared.default_maindeliverid) {
                AppData.shared.zipdialog_flag = 1
            }else {
                AppData.shared.zipdialog_flag = 0
                UserDefaults.standard.set(AppData.shared.default_maindeliveraddress, forKey: "main_deliveraddress")
                UserDefaults.standard.set(AppData.shared.default_maindelivertitle, forKey: "main_delivertitle")
                UserDefaults.standard.set(AppData.shared.default_mainaddressimage, forKey: "main_imageurl")
                UserDefaults.standard.set(AppData.shared.customer_zipcode, forKey: "main_zipcode")
                UserDefaults.standard.set(AppData.shared.default_maindeliverid, forKey: "main_deliverid")
                if (AppData.shared.cartProductData.count > 0) {
                    for index in 0..<AppData.shared.cartProductData.count {
                        let cartData = AppData.shared.cartProductData[index] as! NSDictionary
                        let cartName = cartData["productname"] as! String
                        UserDefaults.standard.set(0, forKey: cartName)
                    }
                }
                AppData.shared.initCartData()
                UserDefaults.standard.set(0,forKey: "cartCount")
                UserDefaults.standard.set(nil, forKey: "cart_dataarray")
            }
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
        self.present(verificationController, animated: true, completion: nil)
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if (AppData.shared.default_maindeliveraddress != ""){
            self.Show_messagelbl.isHidden = true
            self.select_name.isHidden = false
            self.selected_image.isHidden = false
            self.selected_address.isHidden = false
            
            self.select_name.text = AppData.shared.default_maindelivertitle
            self.selected_image.moa.url = AppData.shared.default_mainaddressimage
            self.selected_address.text = AppData.shared.default_maindeliveraddress
            self.address_listView.reloadData()
        }else {
            self.Show_messagelbl.isHidden = false
            self.select_name.isHidden = true
            self.selected_image.isHidden = true
            self.selected_address.isHidden = true
            self.Show_messagelbl.text = "⚠️ Seleccionar Dirección"
            self.address_listView.reloadData()
        }
       
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppData.shared.profile_shippingAddress.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "delivercell", for: indexPath) as! SelectDeliverCell
        let cellData = AppData.shared.profile_shippingAddress[indexPath.row] as! NSDictionary
        cell.cellData = cellData
        let addresslocation = cellData["address_location"] as! String
        let addressimageurl = cellData["address_imageurl"] as! String
        let addressname = cellData["address_name"] as! String
        let addressid = cellData["address_id"] as! String
        cell.address_name.text = addressname
        cell.address_image.moa.url = addressimageurl
        cell.address = addresslocation
        cell.viewcontroller = self
        if (AppData.shared.default_maindeliveraddress == addresslocation &&  AppData.shared.default_maindeliverid == addressid) {
            cell.main_flag = 1
            cell.setmain_btn.isSelected = true
            cell.set_card(flag_btn: cell.main_flag)
        }else {
            cell.main_flag = 0
            cell.setmain_btn.isSelected = false
            cell.set_card(flag_btn: cell.main_flag)
        }
        cell.address_lbl.text = addresslocation
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let personal = UIContextualAction(style: .normal, title: ""){
            (action,view,nil) in
            print("Personal")
            
            let alert = ShipDeleteDialog(title: "",vc:self, tableview: tableView,index :indexPath.row)
            alert.show(animated: true)
        }
        personal.backgroundColor = UIColor.red
        personal.image =  UIImage(named: "trash1")
        
        return UISwipeActionsConfiguration(actions: [personal])
    }
    
    @IBAction func Add_Address(_ sender: Any) {
        AppData.shared.addgif(sender: Add_Addresbtn)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "newshipVC") as! AddNewShippingAddressViewController
        vc.flag_str = "add"
        vc.gotoFlag = "maindeliver"
        AppData.shared.gotopage = self.goback
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}
