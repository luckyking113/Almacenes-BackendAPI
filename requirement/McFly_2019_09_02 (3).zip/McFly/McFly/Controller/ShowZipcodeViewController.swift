//
//  ShowZipcodeViewController.swift
//  McFly
//
//  Created by LiuYan on 6/16/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import GoogleMaps
import GooglePlaces
class ShowZipcodeViewController: UIViewController,CLLocationManagerDelegate, MKMapViewDelegate {
    
    
    @IBOutlet weak var mapView: MKMapView!
    var locationManager = CLLocationManager()
    var warehouse : ImageAnnotation!
    var userannotation: ImageAnnotation!
    var zipcode : String = ""
    var address : String = ""
    @IBOutlet weak var location_btn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
        self.title = "Tu Código Postal es!"
        AppData.shared.displayToastMessage("Enciende tu ubicación")
        
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        self.showLocation()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Show_Users(_ sender: Any) {
        self.mapView.addAnnotation(userannotation)
        self.mapView.showAnnotations([self.userannotation], animated: true)
       // self.title = self.zipcode
            location_btn.setTitle("Tu Código Postal es " + self.zipcode, for: .normal)
        
    }
    @objc func onClcikBack()
    {
        AppData.shared.zipdialog_flag = 0
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
        self.present(verificationController, animated: true, completion: nil)
    }
    func showLocation (){
        let locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Check for Location Services
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
        }
        
        //Zoom to user location
        if let userLocation = locationManager.location?.coordinate {
            let lat = userLocation.latitude as! Double
            let lng = userLocation.longitude as! Double
            print("testtetstestste")
            print(lat)
            print(lng)
            self.convertLatLongToAddress(latitude: lat, longitude: lng,userlocation: userLocation)
            
            
           
            let viewRegion = MKCoordinateRegion(center: userLocation, latitudinalMeters: 100, longitudinalMeters: 100)
            self.mapView.setRegion(viewRegion, animated: false)
        }
        
        self.locationManager = locationManager
        
        DispatchQueue.main.async {
            self.locationManager.startUpdatingLocation()
        }
        
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "customannotation")
        annotationView.canShowCallout = true
        annotationView.isDraggable = true
        
        let pinImage = UIImage(named: "pinmarker")
        let size = CGSize(width: 40, height: 40)
        UIGraphicsBeginImageContext(size)
        pinImage!.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
        
        annotationView.image = resizedImage
        return annotationView
    }
    func mapViewDidFinishLoadingMap(_ mapView: MKMapView) {
        // this is where visible maprect should be set
        mapView.showAnnotations(mapView.annotations, animated: true)
    }
    func convertLatLongToAddress(latitude:Double,longitude:Double,userlocation : CLLocationCoordinate2D){
        
      //  let geoCoder = CLGeocoder()
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
     //  let location1 = CLLocation(latitude: latitude, longitude: longitude)
        let geocoder = GMSGeocoder()
        geocoder.reverseGeocodeCoordinate(location, completionHandler: {response,error in
            if let gmsAddress = response!.firstResult(){
                let zipcode = gmsAddress.postalCode as! String
                self.zipcode = zipcode
                let address_array = gmsAddress.lines as! [String]
                var address_str: String = ""
                for index in 0..<address_array.count {
                    let sub_adress = address_array[index] as! String
                    address_str = address_str + sub_adress
                }
                self.address = address_str
                //                self.add_partaddress.text = address2
                print(address_str)
                 self.userannotation = ImageAnnotation(pinTitle: self.address, pinSubTitle: self.zipcode, pinlocation: location)
            }
        })
//        geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, error) -> Void in
//
//            // Place details
//            var placeMark: CLPlacemark!
//            placeMark = placemarks?[0]
//
//            // Location name
//            if let address = placeMark.addressDictionary {
//
//                let addressFormat = address as NSDictionary
//                let real_address = addressFormat["FormattedAddressLines"] as! NSArray
//                print(real_address)
//                var show_address : String = ""
//                for index in 0..<real_address.count {
//                    let str = real_address[index] as! String
//                    if (index == 0){
//                        show_address =  str
//                    }else if (index == real_address.count - 1){
//                        show_address = show_address + str
//                    }else {
//                        show_address = show_address + str + ","
//                    }
//
//                }
//                self.address = show_address
//            }
//            if let postalcode = placeMark.postalCode {
//                self.zipcode =  postalcode
//            }
//            // Country
//            if let country = placeMark.country {
//                print(country)
//                self.address = self.address + "," + country
//            }
//            self.userannotation = ImageAnnotation(pinTitle: self.address, pinSubTitle: self.zipcode, pinlocation: userlocation)
//        })
        
    }
    
    
}
