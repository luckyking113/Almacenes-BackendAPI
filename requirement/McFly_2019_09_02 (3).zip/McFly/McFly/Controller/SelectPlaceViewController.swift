//
//  SelectPlaceViewController.swift
//  McFly
//
//  Created by LiuYan on 6/2/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
import CoreLocation
import GoogleMaps
class SelectPlaceViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
  
    

    
    @IBOutlet weak var address_field: UITextField!
    
    @IBOutlet weak var address_indicator: UIActivityIndicatorView!
    
    @IBOutlet weak var address_tabel: UITableView!
    var flag_str : String = ""
    var predict_addressData = NSMutableArray()
    var zipcodestrings = NSMutableArray()
    var gotoFlag : String = ""
    var flag: Int = 0
    var stringsArray : [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        address_tabel.delegate = self
        address_tabel.dataSource = self
        self.address_indicator.isHidden = true
        address_field.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingDidEnd)
        // Do any additional setup after loading the view.
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @objc func textFieldDidChange(_ textField: UITextField) {
         self.predict_addressData = NSMutableArray()
        let ad_string = self.address_field.text as! String
        let newString = ad_string.replacingOccurrences(of: " ", with: "%20")
        self.SuggestAddress(address_str: newString)
    }
    func SuggestAddress(address_str: String){
        self.predict_addressData.removeAllObjects()
         self.stringsArray.removeAll()
       
        self.address_indicator.isHidden = false
        self.address_indicator.startAnimating()
        let url = URL(string: AppConstants.baseUrl + "getsugestedaddress")!
        // here `content` is the JSON dictionary containing the
        let jsondata: [String: Any] = ["address" : address_str]
            Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    self.address_indicator.isHidden = true
                    self.address_indicator.stopAnimating()
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            var searchdata = NSMutableArray()
                            let location = responseData["location"] as! NSDictionary
                            let adddress_data = location["predictions"] as! NSMutableArray
                            if (adddress_data.count > 0){
                                for index in 0..<adddress_data.count {
                                    let eachData = adddress_data[index] as! NSDictionary
                                    let addressstring = eachData["description"] as! String
                                    let mainData = eachData["structured_formatting"] as! NSDictionary
                                    let mainstr = mainData["main_text"] as! String
                                    if (addressstring.contains("Mexico")){
                                        
                                        self.predict_addressData.add(eachData)
                                    }
                                }
                            }
                            self.address_tabel.reloadData()
                            
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.predict_addressData.count > 0){
            return self.predict_addressData.count
        }else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addressCell", for: indexPath) as! AddressCell
        let cellData = self.predict_addressData[indexPath.row] as! NSDictionary
        let sub_data = cellData["structured_formatting"] as! NSDictionary
        let mainstr = sub_data["main_text"] as! String
        cell.main_address.text = sub_data["main_text"] as! String
        let descriptionstr = cellData["description"] as! String
        let fixstr = descriptionstr.replacingOccurrences(of: mainstr + ",", with: "") as! String
        cell.description_lbl.text = fixstr
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 67
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cellData = self.predict_addressData[indexPath.row] as! NSDictionary
       // let sub_data = cellData["structured_formatting"] as! NSDictionary
        let address  = cellData["description"] as! String
        
        self.getLocationfromAddress(address: address)
       
    }
    func getLocationfromAddress(address : String) {
        
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(address) { (placemarks, error) in
            guard
                let placemarks = placemarks,
                let location = placemarks.first?.location
                else {
                    // handle no location found
                   self.flag = 1
                    
                    return
            }
            let las = location.coordinate as! CLLocationCoordinate2D
            print(las)
            let postalcode = placemarks.first?.postalCode as! String
            print(postalcode)
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "mapVC") as! MapViewController
            vc.flag_str = self.flag_str
            vc.address_location = location.coordinate as! CLLocationCoordinate2D
            vc.address = address
            vc.zipcode = postalcode
            vc.gotoFlag = self.gotoFlag
            self.navigationController?.pushViewController(vc, animated: true)
            
           
            // Use your location
        }
    }
    
}
