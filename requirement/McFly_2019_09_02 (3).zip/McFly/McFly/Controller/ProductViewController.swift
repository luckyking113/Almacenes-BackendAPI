//
//  ProductViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import moa
class ProductViewController: UIViewController {

    @IBOutlet weak var product_img: UIImageView!
    @IBOutlet weak var product_quantity: UILabel!
    @IBOutlet weak var product_description: UILabel!
    @IBOutlet weak var product_cost: UILabel!
    @IBOutlet weak var card_view: CardView!
    var product_detailData = NSDictionary()
    var quantity: Int = 0
    var limit_quantity : Int = 0
    var category_name: String = ""
    
    @IBOutlet weak var add_btn: UIButton!
    @IBOutlet weak var minus_btn: UIButton!
    
    @IBOutlet weak var cart_btn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        // Do any additional setup after loading the view.
        
    }
    func initUI(){
        //product_img.image = UIImage(named: "image1.png")
        let imageurl = product_detailData["productimage"] as! String
        let img_url = URL(string: AppConstants.imageproduct_url + imageurl)!
        //print(img_url)
        //AppData.shared.downloadImage(from: img_url, imageView: self.product_img)
        product_img.moa.url = AppConstants.imageproduct_url + imageurl
        product_img.moa.errorImage = UIImage(named: "ic_images")
        let cost = product_detailData["product_price"] as! String
        self.product_cost.text = "$" + cost
        let description = product_detailData["productname"] as! String
        self.product_description.text = description
        quantity = 1
        self.product_quantity.text = String(quantity)
        
        let limit_count = product_detailData["quantity"] as! String
        self.limit_quantity = Int(limit_count) as! Int
        
        product_quantity.layer.cornerRadius =  product_quantity.frame.width / 2
        product_quantity.layer.masksToBounds = true
        
        
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func add_number(_ sender: Any) {
        AppData.shared.addgif(sender: self.add_btn)
        quantity = quantity + 1
        let imageurl = product_detailData["productimage"] as! String
        let img_url = URL(string: AppConstants.imageproduct_url + imageurl)!
        product_img.moa.url = AppConstants.imageproduct_url + imageurl
        product_img.moa.errorImage = UIImage(named: "placeholder")
        print(quantity)
        if (quantity > limit_quantity){
            quantity = limit_quantity
            AppData.shared.displayToastMessage("This is maximum quantity")
        }
        let quantity_str = String(quantity)
        self.product_quantity.text = quantity_str
    }
    
    @IBAction func minus_number(_ sender: Any) {
        AppData.shared.addgif(sender: self.minus_btn)
        quantity = quantity - 1
        print(quantity)
        if (quantity <= 0){
            quantity = 0
             product_img.image = UIImage(named: "placeholder")
        }else {
            let imageurl = product_detailData["productimage"] as! String
            let img_url = URL(string: AppConstants.imageproduct_url + imageurl)!
            product_img.moa.url = AppConstants.imageproduct_url + imageurl
            product_img.moa.errorImage = UIImage(named: "placeholder")
        }
        let quantity_str = String(quantity)
        self.product_quantity.text = quantity_str
    }
    
    @IBAction func Addto_Cart(_ sender: Any) {
        if (quantity > 0){
            AppData.shared.addgif(sender: self.cart_btn)
            if (AppData.shared.profile_loginstatus){
                if (AppData.shared.wrong_warehouse == 1){
                    if (AppData.shared.default_maindeliverid != ""){
                        if (self.category_name == "Alcoholes"){
                            let birthday = AppData.shared.profile_customerDetailData["birthday"] as! String
                            let birthdate: [String] = birthday.components(separatedBy: "-")
                            let birthyear : String = birthdate[0] as! String
                            let year : Int = Calendar.current.component(.year, from: Date())
                            let cal_year : Int = Int(birthday) as! Int
                            let age : Int = year - cal_year
                            if (age <= 18) {
                                self.showAlert("You can 't pick up Alcholes.")
                            }else {
                                let pd_countstr = self.product_quantity.text as! String
                                // print(pd_countstr)
                                let pd_count = Int(pd_countstr) as! Int
                                // print(pd_count)
                                if (pd_count > 0){
                                    print(AppData.shared.cartProductData.count)
                                    if let tabItems = tabBarController?.tabBar.items {
                                        // In this case we want to modify the badge number of the third tab:
                                        let tabItem = tabItems[1]
                                        AppData.shared.cartBadge_number = AppData.shared.cartBadge_number + pd_count
                                        UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
                                        let badge_str = String(AppData.shared.cartBadge_number) as! String
                                        
                                        let product_name = product_detailData["productname"] as! String
                                        var productcount = UserDefaults.standard.integer(forKey: product_name) ?? 0
                                        //print(productcount)
                                        if (productcount == 0){
                                            productcount = productcount + pd_count
                                            UserDefaults.standard.set(productcount, forKey: product_name)
                                            print(productcount)
                                            AppData.shared.cartProductData.add(product_detailData)
                                            let saveData :[String : Any] = ["cartproduct_array" : AppData.shared.cartProductData]
                                            UserDefaults.standard.set(saveData, forKey: "cart_dataarray")
                                        }else {
                                            productcount = productcount + pd_count
                                            print(productcount)
                                            UserDefaults.standard.set(productcount, forKey: product_name)
                                        }
                                        print(AppData.shared.cartProductData.count)
                                        //
                                        tabItem.badgeValue = badge_str
                                    }
                                    
                                }
                            }
                        }else {
                            let pd_countstr = self.product_quantity.text as! String
                            // print(pd_countstr)
                            let pd_count = Int(pd_countstr) as! Int
                            // print(pd_count)
                            if (pd_count > 0){
                                print(AppData.shared.cartProductData.count)
                                if let tabItems = tabBarController?.tabBar.items {
                                    // In this case we want to modify the badge number of the third tab:
                                    let tabItem = tabItems[1]
                                    AppData.shared.cartBadge_number = AppData.shared.cartBadge_number + pd_count
                                    UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
                                    let badge_str = String(AppData.shared.cartBadge_number) as! String
                                    
                                    let product_name = product_detailData["productname"] as! String
                                    var productcount = UserDefaults.standard.integer(forKey: product_name) ?? 0
                                    //print(productcount)
                                    if (productcount == 0){
                                        productcount = productcount + pd_count
                                        UserDefaults.standard.set(productcount, forKey: product_name)
                                        print(productcount)
                                        AppData.shared.cartProductData.add(product_detailData)
                                        let saveData :[String : Any] = ["cartproduct_array" : AppData.shared.cartProductData]
                                        UserDefaults.standard.set(saveData, forKey: "cart_dataarray")
                                    }else {
                                        productcount = productcount + pd_count
                                        print(productcount)
                                        UserDefaults.standard.set(productcount, forKey: product_name)
                                    }
                                    print(AppData.shared.cartProductData.count)
                                    //
                                    tabItem.badgeValue = badge_str
                                }
                                
                            }
                        }
                    }
                    else {
                        let deliverzip = DeliverZip(title: "", viewcontroller: self)
                        deliverzip.show(animated: true)
                    }
                    
                } else if (AppData.shared.wrong_warehouse == 0) {
                    let deliverzip = DeliverZip(title: "", viewcontroller: self)
                    deliverzip.show(animated: true)
                }
            }else {
                let alert = SignUpDialog(title: "",viewcontroller: self)
                alert.show(animated: true)
                return
            }
        }
        
        
        
    }
    func showAlert(_ message: String) {
        let alertController = UIAlertController(title: "Pick up Process", message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertAction.Style.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
}
