//
//  ProfileViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import moa
class ProfileViewController: UIViewController {

    @IBOutlet weak var user_profileImage: UIImageView!
    
    @IBOutlet weak var user_phoneNumber: UILabel!
    
    @IBOutlet weak var user_Name: UILabel!
    @IBOutlet weak var showVisaCard_view: UIView!
    
    @IBOutlet weak var noCard_lbl1: UILabel!
    @IBOutlet weak var noCard_lbl2: UILabel!
    
    @IBOutlet weak var noCard_lbl3: UITextField!
    @IBOutlet weak var showVisaCard_Label: UILabel!
    @IBOutlet weak var showVisaCard_Text: UILabel!
    
    @IBOutlet weak var visaCardType_image: UIImageView!
    
    @IBOutlet weak var singin_btn: UIButton!
    
    @IBOutlet weak var singout_btn: UIButton!
    
    @IBOutlet weak var signup_btn: UIButton!
    
    @IBOutlet weak var editCard_btn: UIButton!
    
    @IBOutlet weak var order_historybtn: UIButton!
    @IBOutlet weak var main_deliveraddress: UILabel!
    
    @IBOutlet weak var edit_profilebtn: UIButton!
    
    @IBOutlet weak var select_shiptitle: UILabel!
    @IBOutlet weak var setting_btn: UIButton!
    
    @IBOutlet weak var card_EditView: CardView!
    
    @IBOutlet weak var deliver_icon: UIImageView!
    @IBOutlet weak var deliver_SelectView: CardView!
    
    @IBOutlet weak var default_address: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated:true)
        default_address.isHidden = true
        user_profileImage.layer.cornerRadius = user_profileImage.frame.width / 2
        user_profileImage.layer.masksToBounds = true
        let cardgesture1 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        let cardgesture2 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        let cardgesture3 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        let cardgesture4 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        let cardgesture5 = UITapGestureRecognizer(target: self, action: #selector(cardlist))
        
        
        let delivergesture1 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        let delivergesture2 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        let delivergesture3 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        let delivergesture4 = UITapGestureRecognizer(target: self, action: #selector(SelectMainAddress))
        
        self.card_EditView.addGestureRecognizer(cardgesture1)
        self.card_EditView.isUserInteractionEnabled = true
        self.showVisaCard_view.addGestureRecognizer(cardgesture2)
        self.showVisaCard_view.isUserInteractionEnabled = true
        self.showVisaCard_Label.addGestureRecognizer(cardgesture3)
        self.showVisaCard_Label.isUserInteractionEnabled = true
        self.showVisaCard_Text.addGestureRecognizer(cardgesture4)
        self.showVisaCard_Text.isUserInteractionEnabled = true
        self.visaCardType_image.addGestureRecognizer(cardgesture5)
        self.visaCardType_image.isUserInteractionEnabled = true
        
        self.deliver_SelectView.addGestureRecognizer(delivergesture1)
        self.deliver_SelectView.isUserInteractionEnabled = true
        self.deliver_icon.addGestureRecognizer(delivergesture2)
        self.deliver_icon.isUserInteractionEnabled = true
        self.main_deliveraddress.addGestureRecognizer(delivergesture3)
        self.main_deliveraddress.isUserInteractionEnabled = true
        self.select_shiptitle.addGestureRecognizer(delivergesture4)
        self.select_shiptitle.isUserInteractionEnabled = true
        // Do any additional setup after loading the view.
    }
    @objc func cardlist(){
        // do other task
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "cardlistVC") as! CardListViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @objc func SelectMainAddress(){
        // do other task
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
        vc.goback = "profile"
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if (AppData.shared.profile_loginstatus){
            showProfile()
        }else {
            self.singin_btn.isHidden = false
            self.signup_btn.isHidden = false
            self.singout_btn.isHidden = true
        }
        
    }
    override func viewDidAppear(_ animated: Bool) {
        if (AppData.shared.profile_loginstatus){
            if let tabItems = tabBarController?.tabBar.items {
                // In this case we want to modify the badge number of the third tab:
                AppData.shared.cartBadge_number = UserDefaults.standard.integer(forKey: "cartCount") ?? 0
                if (AppData.shared.cartBadge_number > 0){
                    let badge_str : String = String(AppData.shared.cartBadge_number) as! String
                    let tabItem = tabItems[1]
                    tabItem.badgeValue = badge_str
                }else {
                    let tabItem = tabItems[1]
                    tabItem.badgeValue = nil
                }
                
            }
        }
        
    }
    
    @IBAction func edit_Profile(_ sender: Any) {
        //self.edit_profilebtn.pulstate()
        AppData.shared.addgif(sender: edit_profilebtn)
        if (AppData.shared.profile_loginstatus == true){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "editprofileVC") as! EditProfileViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            AppData.shared.displayToastMessage("Please try Signin or Signup.")
            return
        }
       
    }
    @IBAction func setting_Page(_ sender: Any) {
       // self.setting_btn.pulstate()
        AppData.shared.addgif(sender: setting_btn)
        if (AppData.shared.profile_loginstatus == true){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "settingVC") as! SettingViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            AppData.shared.displayToastMessage("Please try Signin or Signup.")
            return
        }
      
    }
    
    @IBAction func order_History(_ sender: Any) {
       // self.order_historybtn.pulstate()
        AppData.shared.addgif(sender: order_historybtn)
        if (AppData.shared.profile_loginstatus == true){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "orderVC") as! OrderViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            AppData.shared.displayToastMessage("Please try Signin or Signup.")
            return
        }
        
    }
    
    @IBAction func edit_CardNumber(_ sender: Any) {
        //self.editCard_btn.pulstate()
        if (AppData.shared.profile_loginstatus == true){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "cardlistVC") as! CardListViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            //AppData.shared.displayToastMessage("Please try Signin or Signup.")
            return
        }
        
    }
    @IBAction func Select_MainAddress(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
        vc.goback = "profile"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func Signin_Action(_ sender: Any) {
        //self.singin_btn.pulstate()
        AppData.shared.addgif(sender: singin_btn)
        UserDefaults.standard.set( "", forKey: "verified_value")
        UserDefaults.standard.set(-1,forKey: "verified_type")
        AppData.shared.initAppData()
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let alertController = storyBoard.instantiateViewController(withIdentifier: "signinVC") as! SiginInViewController
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func Signout_Action(_ sender: Any) {
       // self.singout_btn.pulstate()
        AppData.shared.addgif(sender: singout_btn)
        UserDefaults.standard.set( "", forKey: "verified_value")
        UserDefaults.standard.set(-1,forKey: "verified_type")
//        AppData.shared.cartBadge_number = UserDefaults.standard.integer(forKey: "cartCount") ?? 0
        UserDefaults.standard.set(0,forKey: "cartCount")
        UserDefaults.standard.set(nil, forKey: "cart_dataarray")
         AppData.shared.initAppData()
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let alertController = storyBoard.instantiateViewController(withIdentifier: "signinVC") as! SiginInViewController
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func SignUp_Action(_ sender: Any) {
        //self.signup_btn.pulstate()
        AppData.shared.addgif(sender: signup_btn)
        AppData.shared.initAppData()
        UserDefaults.standard.set( "", forKey: "verified_value")
        UserDefaults.standard.set(-1,forKey: "verified_type")
        AppData.shared.categroy_Data = NSMutableArray()
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let alertController = storyBoard.instantiateViewController(withIdentifier: "signupVC") as! SignUpViewController
        self.present(alertController, animated: true, completion: nil)
    }
    func showProfile(){
        if (AppData.shared.profile_customerid != ""){
            let loginStatus = AppData.shared.profile_customerDetailData["status"] as! String
            if (loginStatus == "1") {
                let firstname = AppData.shared.profile_customerDetailData["first_name"] as! String
                 let lastname =    AppData.shared.profile_customerDetailData["last_name"] as! String
                self.user_Name.text = firstname + "  " + lastname
                let phoneNumber = AppData.shared.profile_customerDetailData["phone"] as! String
                self.user_phoneNumber.text = phoneNumber
                let image_url = AppData.shared.profile_customerDetailData["image"] as! String
                if (image_url.isEmpty){
                      self.user_profileImage.image = UIImage(named: "doc-512")
                }else{
                     self.user_profileImage.moa.url = image_url
                }
               
              
                self.singin_btn.isHidden = true
                self.signup_btn.isHidden = true
                self.singout_btn.isHidden = false
                if (AppData.shared.default_maindeliveraddress != ""){
                    self.main_deliveraddress.text = AppData.shared.default_maindeliveraddress
                    self.select_shiptitle.text = AppData.shared.default_maindelivertitle
                    self.deliver_icon.moa.url = AppData.shared.default_mainaddressimage
                    self.select_shiptitle.isHidden = false
                    self.deliver_icon.isHidden = false
                    self.main_deliveraddress.isHidden = false
                    self.default_address.isHidden = true
                }else {
                     self.main_deliveraddress.isHidden = true
                     self.select_shiptitle.isHidden = true
                     self.deliver_icon.isHidden = true
                    self.default_address.isHidden = false
                     self.default_address.text = "Seleccionar Dirección ⚠️"
                }
              
                
              
                self.showCardData()
                
            }
        }else {
            
            self.singin_btn.isHidden = false
            self.signup_btn.isHidden = false
            self.singout_btn.isHidden = true
           
        }
        
        
    }
    func showCardData(){
        if (AppData.shared.cardDetailData.count > 0){
            for index  in 0..<AppData.shared.cardDetailData.count {
                let cardData = AppData.shared.cardDetailData[index] as! NSDictionary
                let cardid = cardData["id"] as! String
                if (AppData.shared.default_cardsource == cardid){
                    let object = cardData["object"] as! String
                    if (object == "card") {
                        self.showVisaCard_Text.isHidden = false
                        self.showVisaCard_view.isHidden = false
                        self.showVisaCard_Label.isHidden = false
                        // self.editCard_btn.isEnabled = true
                        self.noCard_lbl1.isHidden = true
                        self.noCard_lbl2.isHidden = true
                        self.noCard_lbl3.isHidden = true
                       
                        let cardtype = cardData["brand"] as! String
                        let cardtype_sm = cardtype.lowercased()
                        switch (cardtype_sm) {
                        case "visa" :
                            self.visaCardType_image.image = UIImage(named: "stp_card_visa")
                            break
                        case "mastercard" :
                            self.visaCardType_image.image = UIImage(named: "stp_card_mastercard")
                            break
                        case "american express" :
                            self.visaCardType_image.image = UIImage(named: "stp_card_amex")
                            break
                        case "discover" :
                            self.visaCardType_image.image = UIImage(named: "stp_card_discover")
                            break
                        case "diners_club" :
                            self.visaCardType_image.image = UIImage(named: "stp_card_diners")
                        case "jcb" :
                            self.visaCardType_image.image = UIImage(named: "stp_card_jcb")
                        default:
                            self.visaCardType_image.image = UIImage(named: "stp_card_unknown")
                        }
                        self.showVisaCard_Label.text = cardtype
                        let last4 = cardData["last4"] as! String
                        self.showVisaCard_Text.text = "**** **** " + last4
                       
                    }
                }
                
            }
        }else {
            self.showVisaCard_Text.isHidden = true
            self.showVisaCard_view.isHidden = true
            self.showVisaCard_Label.isHidden = true
            // self.editCard_btn.isEnabled = false
            self.noCard_lbl1.isHidden = false
            self.noCard_lbl2.isHidden = false
            self.noCard_lbl3.isHidden = false
        }
    }
    
    
}
