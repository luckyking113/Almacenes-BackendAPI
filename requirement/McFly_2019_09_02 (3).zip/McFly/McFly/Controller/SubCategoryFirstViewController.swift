//
//  SubCategoryFirstViewController.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
import moa
class SubCategoryFirstViewController: UIViewController {

    @IBOutlet weak var subcategory_view: UICollectionView!
    var subCategoryData =  NSMutableArray()
    var productData = NSMutableArray()
    var filterData = NSMutableArray()
    var total_count : Int = 0
    var buttonArray:[UIButton] = []
    var uiColorArray = [UIColor]()
    var category_name : String = ""
    @IBOutlet weak var subcategory_ContainerView: UIView!
    
    @IBOutlet weak var bubble_height: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        AppData.shared.uiColorArray.shuffle()
        subcategory_view.delegate = self
        subcategory_view.dataSource = self
        if (category_name == "Solo 18+"){
             self.title = "Solo 18+"
        }else {
             self.title = category_name
        }
        print(category_name)
       self.bubble_height.constant = 40
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        // Do any additional setup after loading the view.
        initUI()
        let button = UIButton(frame: CGRect(x:5, y:5, width:40, height:30))
        button.titleLabel?.font = UIFont.systemFont(ofSize: 10.0)
        
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.white.cgColor
        button.layer.backgroundColor = AppData.shared.uiColorArray[0].cgColor
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.setTitle("Todo", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.addTarget(self, action: #selector(FileterCategory), for: .touchUpInside)
        buttonArray.append(button)
        self.subcategory_ContainerView.addSubview(buttonArray[0])
        
       
        let framewidth = self.subcategory_ContainerView.frame.width
        if (subCategoryData.count > 0){
            let count = subCategoryData.count as! Int
           
            var x : Int = 50
            var y : Int = 5
            for index in 0..<count {
                let eachsub_catdata = subCategoryData[index] as! NSDictionary
                let eachsub_pddata  = eachsub_catdata["products"] as! NSMutableArray
                let subcategoryName = eachsub_catdata["name"] as! String
                 print("Subcateogry" + subcategoryName)
                if (subcategoryName != ""){
                    //add search Buttons
                    let length = subcategoryName.count as! Int
                    var width = 10 * (length)
                    if (length <= 5) {
                        width = 10 * length
                    }
                    if (length > 12 )
                    {
                        width = 10 * (length - 4)
                    }
                    if (length == 12){
                        width = 10 * (length - 3)
                    }
                    if (x + width > Int(framewidth) - 30){
                        self.bubble_height.constant = self.bubble_height.constant + 40
                        x = 5
                        y = y + 40
                        
                    }
                    let button = UIButton(frame: CGRect(x:x, y:y, width:width, height:30))
                    button.titleLabel?.font = UIFont.systemFont(ofSize: 10.0)
                    let blueColor = AppData.shared.uiColorArray[buttonArray.count]
                    button.layer.borderWidth = 1
                    button.layer.backgroundColor = blueColor.cgColor
                    button.layer.borderColor = UIColor.white.cgColor
                    button.layer.cornerRadius = 15
                    button.layer.masksToBounds = true
                    x = x + width + 10
                    
                    button.setTitle(subcategoryName, for: .normal)
                    button.setTitleColor(UIColor.white, for: .normal)
                    button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
                    button.addTarget(self, action: #selector(FileterCategory), for: .touchUpInside)
                    buttonArray.append(button)
                    self.subcategory_ContainerView.addSubview(buttonArray[buttonArray.count - 1])
                    //////////
                    let sub_count = eachsub_pddata.count as! Int
                    let real_count = sub_count
                    total_count = total_count + real_count
                    for sub_index in 0..<sub_count {
                        let product = eachsub_pddata[sub_index] as! NSDictionary
                        productData.add(product)
                    }
                }
                
            }
            filterData = productData
           // print(total_count)
           // print(productData.count)
        }
      
    }
    @objc func FileterCategory(sender: UIButton!) {
        //let sendercolor = sender.titleLabel?.textColor
        let sendertext = sender.titleLabel?.text as! String
        
        print(sendertext)
        //let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        print(buttonArray.count)
        for index in 0..<buttonArray.count {
            let buttontext = buttonArray[index].titleLabel?.text as! String
                print(buttontext)
            if (sendertext == buttontext){
                let bordercolor = AppData.shared.uiColorArray[index] as! UIColor
                buttonArray[index].layer.backgroundColor = UIColor.white.cgColor
                buttonArray[index].layer.borderWidth = 1
                buttonArray[index].layer.borderColor = bordercolor.cgColor
                buttonArray[index].setTitleColor(bordercolor, for: .normal)
            }else {
                //
                let bgcolor = AppData.shared.uiColorArray[index] as! UIColor
                buttonArray[index].layer.backgroundColor = bgcolor.cgColor
                buttonArray[index].layer.borderWidth = 1
                buttonArray[index].layer.borderColor = UIColor.white.cgColor
                
                buttonArray[index].setTitleColor(UIColor.white, for: .normal)
            }
        }
        if (sendertext == "Todo"){
            filterData = productData
            self.subcategory_view.reloadData()
        }else {
            for index in 0..<subCategoryData.count{
                let eachsub_catdata = subCategoryData[index] as! NSDictionary
                let eachsub_pddata  = eachsub_catdata["products"] as! NSMutableArray
                let subcategoryName = eachsub_catdata["name"] as! String
                if (subcategoryName == sendertext){
                    filterData = eachsub_pddata
                    self.subcategory_view.reloadData()
                }
            }
        }
        
    }

    func initUI(){
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        let bound  = subcategory_view.bounds
        layout.sectionInset = UIEdgeInsets(top: 20, left: 0, bottom: 10, right: 0)
        layout.itemSize = CGSize(width: bound.width/3, height: bound.height / 3)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        subcategory_view!.collectionViewLayout = layout
        
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
}

extension SubCategoryFirstViewController: UICollectionViewDataSource, UICollectionViewDelegate{
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return filterData.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "subcell1", for: indexPath) as! SubCategoryCell
            let product_data = filterData[indexPath.row] as! NSDictionary
            let image_name = product_data["productimage"] as! String
            let img_url = URL(string: AppConstants.imageproduct_url + image_name)!
            print(img_url)
//            AppData.shared.downloadImage(from: img_url, imageView: cell.subimageView)
            cell.subimageView.moa.url = AppConstants.imageproduct_url + image_name
            cell.subimageView.moa.errorImage = UIImage(named: "placeholder")
            let price =  product_data["product_price"] as! String
            cell.fash_cost.text =  "$" + price
            cell.fash_name.text = product_data["productname"] as! String
            cell.viewcontroller = self
            cell.cellProductData = product_data
            cell.categoryname = self.category_name
            return cell
        }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "productVC") as! ProductViewController
        let product_data = filterData[indexPath.row] as! NSDictionary
        vc.product_detailData = product_data
        vc.category_name = self.category_name
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension SubCategoryFirstViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       let bounds = collectionView.bounds
       return CGSize(width: bounds.width / 3, height: bounds.height / 3)
    }
}
