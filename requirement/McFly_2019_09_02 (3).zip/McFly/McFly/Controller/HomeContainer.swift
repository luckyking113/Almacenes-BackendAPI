//
//  HomeContainer.swift
//  McFly
//
//  Created by LiuYan on 7/10/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class HomeContainer: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
