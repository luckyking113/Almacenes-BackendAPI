//
//  OrderViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
class OrderViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate {
   
    @IBOutlet weak var order_tableView: UITableView!
    
    @IBOutlet weak var order_SearchBar: UISearchBar!
    var orderSearchData  = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        order_tableView.dataSource = self
        order_tableView.delegate = self
        initUI()
        orderCollectData()       
    }
    func initUI(){
        order_SearchBar.delegate = self
        self.orderSearchData = AppData.shared.orderHistory_Data
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.orderSearchData.count > 0){
            return self.orderSearchData.count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ordercell", for: indexPath) as! OrderCell
        cell.selectionStyle = .none
        let cellOrderData = self.orderSearchData[indexPath.row] as! NSDictionary
        let orderid = cellOrderData["order_id"] as! String
        
        cell.order_idlbl.text = "Orden #" + orderid
        cell.orderid = orderid
        cell.orderNumber = indexPath.row
        let orderaddress = cellOrderData["shipping_addresslocation"] as! String
        cell.order_addresslbl.text = orderaddress
        let orderamount = cellOrderData["amount"] as! String
        cell.order_amountlbl.text = "$" + orderamount
        let orderstatus = cellOrderData["status"] as! String
        let orderdate = cellOrderData["order_time"] as! String
        let orderdatestr : [String] = orderdate.components(separatedBy: " ")
        let orderdatestr1 = orderdatestr[0] as! String
        let ordertimestr = orderdatestr[1] as! String
        let std_data : [String] = orderdatestr1.components(separatedBy: "-")
        let mexico_data = std_data[2] + "/" + std_data[1] + "/" + std_data[0]
        let timedata: [String]  = ordertimestr.components(separatedBy: ":")
        var checktime = Int(timedata[0]) as! Int
        var checkstr : String = ""
        if (checktime > 12) {
            checkstr = "p.m"
            checktime = checktime - 12
        }else {
            checkstr = "a.m"
        }
        let fixtimestr = String(checktime) as! String
        let showtimestr = fixtimestr + ":" + timedata[1] + " " + checkstr
        cell.order_datelbl.text = mexico_data
        cell.order_timelbl.text = showtimestr
        switch orderstatus {
            case "1":
                cell.order_status.text = "Estatus de orden: " + "Pendiente"
                cell.order_status.textColor = UIColor(red: 64/255, green: 233/255, blue: 12/255, alpha: 1.0)
              
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
            
                break
            case "2":
                cell.order_status.text = "Estatus de orden: " + "Procesando"
                 cell.order_status.textColor = UIColor(red: 64/255, green: 233/255, blue: 12/255, alpha: 1.0)
               
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
                break
            case "3":
                cell.order_status.text = "Estatus de orden: " + "En Recolección"
                cell.order_status.textColor = UIColor(red: 19/255, green: 11/255, blue: 247/255, alpha: 1.0)
              
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
                break
            case "4":
                cell.order_status.text = "Estatus de orden: " + "Recolectada"
                cell.order_status.textColor = UIColor(red: 230/255, green: 11/255, blue: 230/255, alpha: 1.0)
                
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
                break
            case "5":
                cell.order_status.text = "Estatus de orden: " + "En Camino"
                cell.order_status.textColor = UIColor(red: 12/255, green: 233/255, blue: 233/255, alpha: 1.0)
                
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
                break
            case "6":
                cell.order_status.text = "Estatus de orden: " + "Entregado"
                cell.controller = self
                cell.order_status.textColor = UIColor(red: 12/255, green: 233/255, blue: 233/255, alpha: 1.0)
                cell.orderNumber = indexPath.row
               
                cell.ordercofirm_image.isHidden = false
                cell.orderconfirm_button.isHidden = false
                break
            case "7":
                cell.order_status.text = "Estatus de orden: " + "completed"
                cell.controller = self
                cell.order_status.textColor = UIColor(red: 12/255, green: 233/255, blue: 233/255, alpha: 1.0)
                cell.orderNumber = indexPath.row
                
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
                break
            default:
                cell.order_status.text = "Estatus de orden: " + "Entregado"
                cell.order_status.textColor = UIColor(red: 12/255, green: 233/255, blue: 233/255, alpha: 1.0)
               
                cell.ordercofirm_image.isHidden = true
                cell.orderconfirm_button.isHidden = true
                break
        }
        cell.controller = self
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 110
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ordertrackVC") as! OrderTrackViewController
        vc.orderindex = indexPath.row
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func orderCollectData(){
        if (AppData.shared.profile_loginstatus){
            if (AppData.shared.set_flag == 1){
                let alert = LoadingDataDialog(title: "" , viewcontroller: self)
                alert.show(animated: true)
                let url = URL(string: AppConstants.baseUrl + "customerOrderhistory/" + AppData.shared.profile_customerid)!
                Alamofire.request(url, method: .get,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        alert.dismiss(animated: true)
                        if (message == "success"){
                            print("success")
                            let orderData = responseData["orders"] as! NSMutableArray
                            AppData.shared.order_Data = orderData
                            self.order_tableView.reloadData()
                            
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                    }
                }
            }
        }
       
    }
    func SearchOrder(orderstr: String){
        self.orderSearchData = NSMutableArray()
        for index in 0..<AppData.shared.order_Data.count {
            let ordereachdata = AppData.shared.order_Data[index] as! NSDictionary
            let orderuniqueid = ordereachdata["order_id"] as! String
            if (orderuniqueid.contains(orderstr)) {
                self.orderSearchData.add(ordereachdata)
            }
        }
        self.order_tableView.reloadData()
        
        
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if (searchText.count == 0){
           self.orderSearchData = AppData.shared.order_Data
            self.order_tableView.reloadData()
        }else {
            self.SearchOrder(orderstr: searchText)
        }
        
    }
    
}
