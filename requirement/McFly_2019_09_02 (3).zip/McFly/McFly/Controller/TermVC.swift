//
//  TermVC.swift
//  McFly
//
//  Created by LiuYan on 8/18/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import WebKit
class TermVC: UIViewController {

    
    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var conitinue_btn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.conitinue_btn.layer.cornerRadius  = 5
        self.conitinue_btn.layer.masksToBounds = true
        self.initUI()
        // Do any additional setup after loading the view.
    }
    func initUI(){
        let url = Bundle.main.url(forResource: "term", withExtension: "pdf")
        if let url = url {
            let urlRequest = URLRequest(url: url)
            webView.load(urlRequest)
        }
    }
    

    @IBAction func Next_action(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
        self.present(verificationController, animated: true, completion: nil)
    }
}
