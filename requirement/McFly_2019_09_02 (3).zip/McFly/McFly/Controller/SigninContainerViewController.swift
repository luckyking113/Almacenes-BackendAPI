//
//  SigninContainerViewController.swift
//  McFly
//
//  Created by LiuYan on 6/11/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class SigninContainerViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
}
