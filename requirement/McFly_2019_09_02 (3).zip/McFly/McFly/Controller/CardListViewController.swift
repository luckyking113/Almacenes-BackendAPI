//
//  CardListViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
class CardListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var cardListTableView: UITableView!
    @IBOutlet weak var addNewCard: UIButton!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        cardListTableView.addGestureRecognizer(longPress)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.cardListTableView.reloadData()
    }
    func initUI(){
        addNewCard.layer.cornerRadius = 25
        addNewCard.layer.masksToBounds = true
        
        cardListTableView.delegate = self
        cardListTableView.dataSource = self
        //Add Back Button in Navigation Bar................
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    @objc func handleLongPress(sender: UILongPressGestureRecognizer){
        if sender.state == UIGestureRecognizer.State.began {
            let touchPoint = sender.location(in: cardListTableView)
            if let indexPath = cardListTableView.indexPathForRow(at: touchPoint) {
                // your code here, get the row for the indexPath or do whatever you want
              self.showRemoveCardDialog(row: indexPath.row)
            }
        }
    }
    
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cardlistCell", for: indexPath) as! CardListCell
        let cellCardData = AppData.shared.cardDetailData[indexPath.row] as! NSDictionary
        let customer_name = cellCardData["id"] as! String
        print(customer_name)
        print(AppData.shared.default_cardsource)
        cell.controller = self
        cell.cellCardData = cellCardData
        if (AppData.shared.default_cardsource == customer_name){
            cell.flag = 1
            cell.set_card(flag_btn: cell.flag)
            cell.default_btn.isSelected = true
        }else {
            cell.flag = 0
            cell.set_card(flag_btn: cell.flag)
            cell.default_btn.isSelected = false
        }
        let card_name = cellCardData["brand"] as! String
        let card_last4 = cellCardData["last4"] as! String
        let object = cellCardData["object"] as! String
        cell.card_no.text = card_name
        cell.card_number.text = "**** ****" + card_last4
        if (object == "card") {
            let cardtype_sm = card_name.lowercased()
            switch (cardtype_sm) {
            case "visa" :
                cell.card_image.image = UIImage(named: "stp_card_visa")
                break
            case "mastercard" :
                cell.card_image.image = UIImage(named: "stp_card_mastercard")
                break
            case "american express" :
                cell.card_image.image = UIImage(named: "stp_card_amex")
                break
            case "discover" :
                cell.card_image.image = UIImage(named: "stp_card_discover")
                break
            case "diners_club" :
                cell.card_image.image = UIImage(named: "stp_card_diners")
            case "jcb" :
                cell.card_image.image = UIImage(named: "stp_card_jcb")
            default:
                cell.card_image.image = UIImage(named: "stp_card_unknown")
            }
        }
        
        
        return cell
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (AppData.shared.cardDetailData.count > 0){
            return AppData.shared.cardDetailData.count
        }else {
            return 0
        }
    }
    
    @IBAction func Add_Card(_ sender: Any) {
//        self.addNewCard.pulstate()
        AppData.shared.addgif(sender: addNewCard)
        let alert = AddCardDialog(title: "" , viewcontroller: self)
        alert.show(animated: true)
    }
    func showRemoveCardDialog(row : Int){
        let alert = UIAlertController(title: "", message: "Are you sure want to delete this card?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            self.RemoveCard(row: row)
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        
        self.present(alert, animated: true)
    }
    func RemoveCard(row: Int){
//        let alert = LoadingDialog(title: "",viewcontroller: self)
//        alert.show(animated: true)
        AppData.shared.showLoadingIndicator(view: self.view)
        let url = URL(string: AppConstants.baseUrl + "removeCard")!
        let userEmail = AppData.shared.profile_customerDetailData["customer_cardnumber"] as! String
        let cellCardData = AppData.shared.cardDetailData[row] as! NSDictionary
        let customer_name = cellCardData["id"] as! String
        let jsondata:[String : Any] = ["user_stripe_customer": userEmail, "id" : customer_name]
        Alamofire.request(url, method: .post,parameters : jsondata, encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                //alert.dismiss(animated: true)
                AppData.shared.hideLoadingIndicator()
                if (message == "success"){
                    print("success")
                    AppData.shared.cardDetailData = NSMutableArray()
                    if (jsonString.contains("data")){
                        let cardjsondata = responseData["data"] as! NSDictionary
                        let customerdata = cardjsondata["customer"] as! NSDictionary
                        
                        AppData.shared.default_cardsource = customerdata["default_source"] as! String
                        let sourcedata = customerdata["sources"] as! NSDictionary
                        AppData.shared.cardDetailData = sourcedata["data"] as! NSMutableArray
                        self.viewWillAppear(true)
                        
                    }
                }
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    
}
