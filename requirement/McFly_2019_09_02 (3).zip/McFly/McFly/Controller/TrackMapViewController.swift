//
//  TrackMapViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire
import GooglePlaces
import GoogleMaps
class CustomAnnotation : NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    init(pinTitle: String, pinSubTitle:String,pinlocation:CLLocationCoordinate2D) {
        self.coordinate = pinlocation
        self.title = pinTitle
        self.subtitle = pinSubTitle
    }
}
class TrackMapViewController: UIViewController ,CLLocationManagerDelegate,GMSMapViewDelegate{

    @IBOutlet weak var trackMap: GMSMapView!
    
    @IBOutlet weak var track_timeanddistance: UILabel!
    var orderunique_id : Int = 0
    var orderid : String = ""
    var locationManager: CLLocationManager!
    var count: Int  = 0
    var drivermaker = GMSMarker()
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        trackMap.delegate = self
        self.title = "Rastrear Orden #" + orderid
        let locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Check for Location Services
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
        }
        
       
        self.locationManager = locationManager
        
        DispatchQueue.main.async {
            self.locationManager.startUpdatingLocation()
        }
       
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    func initUI(){
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        self.getLastTrack()
//        self.makeGetCall()
    }
    
    func getLastTrack(){
        let cellOrderData = AppData.shared.order_Data[orderunique_id] as! NSDictionary
        let order_number = cellOrderData["id"] as! String
        let order_lat = cellOrderData["shipping_addresslat"] as! String
        let order_lng = cellOrderData["shipping_addresslng"] as! String
        let url = URL(string: AppConstants.baseUrl + "getlocationdata_byorderid/" + order_number)!
//        print(url)
        print(order_lat)
        print(order_lng)
        print(order_number)
        let geturl : String = AppConstants.baseUrl + "getlocationdata_byorderid/" + order_number
        Alamofire.request(geturl,
                          method: .get).responseJSON { (response) in
                            switch response.result {
                            case .success(let json):
                                let data = json as! [String: Any]
                                print(data)
                                let message = data["message"] as! String
                                if (message.elementsEqual("success")){
                                    let trackdata = data["trackdata"] as! NSArray
                                    let trackorder_data1 = trackdata[0] as! NSDictionary
                                    let trackorder_lat = trackorder_data1["order_lat"] as! String
                                    let trackorder_lng = trackorder_data1["order_lng"] as! String
                                    
                                    let order_lati = Double(order_lat) as! Double
                                    let order_lngi = Double(order_lng) as! Double
                                    let track_lat = Double(trackorder_lat) as! Double
                                    let track_lng = Double(trackorder_lng) as! Double
                                    var bounds = GMSCoordinateBounds()
                                    let end_marker = GMSMarker()
                                    end_marker.position = CLLocationCoordinate2D(latitude: order_lati, longitude: order_lngi)
                                    end_marker.map = self.trackMap
                                    bounds = bounds.includingCoordinate(end_marker.position)
                                  
                                    self.drivermaker.position = CLLocationCoordinate2D(latitude: track_lat, longitude: track_lng)
                                    
                                    let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 60))
                                    imageView.image = UIImage(named: "driver")
                                    imageView.transform = CGAffineTransform(translationX: 0, y: 60)
                                    self.drivermaker.iconView = imageView
                                    self.drivermaker.map = self.trackMap
                                    bounds = bounds.includingCoordinate(self.drivermaker.position)
                                    self.trackMap.setMinZoom(1, maxZoom: 15)//prevent to over zoom on fit and animate if bounds be too small
                                    
                                    let update = GMSCameraUpdate.fit(bounds, withPadding: 50)
                                    self.trackMap.animate(with: update)
                                    
                                    self.trackMap.setMinZoom(1, maxZoom: 20)
                                   
                                    self.getlocatonAPI(start_lat: trackorder_lat, start_lng: trackorder_lng, end_lat: order_lat, end_lng: order_lng)
                                    
                                }
                                break
                            case .failure(let error):
                                
                                break
                            }
        }
    }
   
    func getlocatonAPI(start_lat: String,start_lng: String,end_lat: String,end_lng: String){
        let url = URL(string: AppConstants.direction_url)!
        let jsondata: [String: Any] = ["start_lat": start_lat,"start_lng" : start_lng, "end_lat":end_lat, "end_lng": end_lng]
        Alamofire.request(url, method: .post,parameters: jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
               // print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                if (message == "success"){
                    print("success")
                    let locationdata = responseData["location"] as! NSDictionary
                    let routesdata = locationdata["routes"] as! NSMutableArray
                    print(routesdata)
                    if (routesdata.count > 0){
                        let data = routesdata[0] as! NSDictionary
                        let legdata = data["legs"] as! NSArray
                        let data2 = legdata[0] as! NSDictionary
                        let distance = data2["distance"] as! NSDictionary
                        let distance_str : String = distance["text"] as! String
                      //  let distance_double : Int = distance["value"] as! Int
                        let duration = data2["duration"] as! NSDictionary
                        let duration_str = duration["text"] as! String
                        //let duration_double = duration["value"] as! Int
                        self.track_timeanddistance.text = distance_str + "(" + duration_str + ")"
                        let start_latdb:Double = Double(start_lat) as! Double
                        let start_lngdb: Double = Double(start_lng) as! Double
                        let start_location = CLLocationCoordinate2D(latitude: start_latdb, longitude: start_lngdb)
                       
                      
                        let end_latdb: Double = Double(end_lat) as! Double
                        let end_lngdb : Double = Double(end_lng) as! Double
                        
                        let stepdata = data2["steps"] as! NSMutableArray
                        if (stepdata.count > 0){
                            for index in 0..<stepdata.count {
                                let step_eachdata = stepdata[index] as! NSDictionary
                                let startlocation = step_eachdata["start_location"] as! NSDictionary
                                let endlocation = step_eachdata["end_location"] as! NSDictionary
                                let eachstart_lat = startlocation["lat"] as! Double
                                let eachstart_lng = startlocation["lng"] as! Double
                                let eachend_lat = endlocation["lat"] as! Double
                                let eachend_lng = endlocation["lng"] as! Double
                                let each_startlatdb = Double(eachstart_lat) as! Double
                                let each_startlngdb = Double(eachstart_lng) as! Double
                                let each_endlatdb = Double(eachend_lat) as! Double
                                let each_endlngdb = Double(eachend_lng) as! Double
                                let path = GMSMutablePath()
                              
                                path.add(CLLocationCoordinate2D(latitude: each_startlatdb, longitude: each_startlngdb))
                                path.add(CLLocationCoordinate2D(latitude: each_endlatdb, longitude: each_endlngdb))
                                if (index == 0){
                                   let point1 = CLLocation(latitude: each_startlatdb, longitude: each_startlngdb)
                                   let point2 = CLLocation(latitude: each_endlatdb, longitude: each_endlngdb)
                                   let angle = self.getBearingBetweenTwoPoints1(point1: point1, point2: point2)
                                   print(angle)
                                    self.drivermaker.rotation = 90 + angle
                                }
                                let polyline = GMSPolyline(path: path)
                                polyline.strokeColor = .red
                                polyline.strokeWidth = 2.0
                                polyline.map = self.trackMap
                                
                            }
                            self.trackMap.animate(toZoom: 15.5)
                        }
//                        self.drawPolyline()
                     }
                    
                    
                }else {
                    AppData.shared.displayToastMessage(message)
                }
                break
            case .failure(let error):
                print(error)
                
            }
        }
    }
    
    func degreesToRadians(degrees: Double) -> Double { return degrees * .pi / 180.0 }
    func radiansToDegrees(radians: Double) -> Double { return radians * 180.0 / .pi }
    func getBearingBetweenTwoPoints1(point1 : CLLocation, point2 : CLLocation) -> Double {
        
        let lat1 = degreesToRadians(degrees: point1.coordinate.latitude)
        let lon1 = degreesToRadians(degrees: point1.coordinate.longitude)
        
        let lat2 = degreesToRadians(degrees: point2.coordinate.latitude)
        let lon2 = degreesToRadians(degrees: point2.coordinate.longitude)
        
        let dLon = lon2 - lon1
        
        let y = sin(dLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        let radiansBearing = atan2(y, x)
        
        return radiansToDegrees(radians: radiansBearing)
    }
}
