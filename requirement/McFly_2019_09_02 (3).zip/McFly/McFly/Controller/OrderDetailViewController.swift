//
//  OrderDetailViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import Alamofire
import moa
class OrderDetailViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var userNamelbl: UILabel!
    @IBOutlet weak var order_idlbl: UILabel!
    @IBOutlet weak var order_datelbl: UILabel!
    
    @IBOutlet weak var shipping_addresslbl:UILabel!
    
    @IBOutlet weak var order_status: UILabel!
    
    @IBOutlet weak var orderDetailview: UICollectionView!
    
    @IBOutlet weak var deliverview: UIView!
    @IBOutlet weak var deliever_btn: UIButton!
    
    @IBOutlet weak var main_delivername: UILabel!
    
    @IBOutlet weak var ship_image: UIImageView!
    var orderindex : Int = 0
    var orderDataArray = NSMutableArray()
    
    @IBOutlet weak var sub_containerheight: NSLayoutConstraint!
    @IBOutlet weak var container_height: NSLayoutConstraint!
    @IBOutlet weak var product_viewheight: NSLayoutConstraint!
    
    @IBOutlet weak var button_height: NSLayoutConstraint!
   
    @IBOutlet weak var space_height: NSLayoutConstraint!
    
    
    @IBOutlet weak var card_typeimage: UIImageView!
    
    @IBOutlet weak var card_name: UILabel!
    
    @IBOutlet weak var card_number: UILabel!
    
    @IBOutlet weak var delivery_fee: UILabel!
    
    @IBOutlet weak var tax_fee: UILabel!
    
    @IBOutlet weak var total_value: UILabel!
    
    @IBOutlet weak var subtotal_value: UILabel!
    
    @IBOutlet weak var cash_value: UILabel!
    var tax_value: Float = 0.0
    var subtotal_price : Float = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
       
        orderDetailview.delegate = self
        orderDetailview.dataSource = self
        let orderData = AppData.shared.order_Data[orderindex] as! NSDictionary
        let orderid = orderData["order_id"] as! String
        order_idlbl.text = "Ref." + orderid
        let orderdate = orderData["order_time"] as! String
        let datestr = orderdate.components(separatedBy: " ")
        let timestr = datestr[1] as! String
        let datestrarray : [String] = datestr[0].components(separatedBy: "-")
        let timestrarray = timestr.components(separatedBy: ":")
        var hour_str = Int(timestrarray[0]) as! Int
        var checktime: String = ""
        if (hour_str > 12){
            checktime = "p.m"
            hour_str = hour_str - 12
        }else {
            checktime = "a.m"
            
        }
        let timefixstr = String(hour_str) as! String
        
        let timestring = datestrarray[2] + "/" + datestrarray[1] + "/" + datestrarray[0] + " " + timefixstr + ":" + timestrarray[1] + " " + checktime
       
        order_datelbl.text = timestring 
        let orderAddress = orderData["shipping_addresslocation"] as! String
        
        let orderAddressname = orderData["shippingaddress_name"] as! String
        let shipimageurl = orderData["shipping_addressimageurl"] as! String
        self.ship_image.moa.url = shipimageurl
        self.shipping_addresslbl.text = orderAddress
        let orderstatus = orderData["status"] as! String
        self.main_delivername.text = orderAddressname
        let firstname = AppData.shared.profile_customerDetailData["first_name"] as! String
        let lastname =    AppData.shared.profile_customerDetailData["last_name"] as! String
        self.userNamelbl.text = firstname + " " + lastname
        let ware_housedeliveryfee : String = AppData.shared.ware_houseData["delivery_fee"] as! String
        self.tax_fee.text =  "$" + ware_housedeliveryfee
        let totalvalue = orderData["amount"] as! String
        self.subtotal_value.text = "$" + totalvalue
        
        let card_num = orderData["card_number"] as! String
        
        if (card_num == "Cash") {
            self.cash_value.isHidden = false
            self.card_name.isHidden = true
            self.card_number.isHidden = true
            let cash_amount = orderData["cash_amount"] as! String
            self.card_typeimage.image = UIImage(named: "cash")
            self.cash_value.text = "$" + cash_amount
        }else if (card_num == "POS") {
            self.cash_value.isHidden = false
            self.card_name.isHidden = true
            self.card_number.isHidden = true
            //let cash_amount = orderData["cash_amount"] as! String
            self.card_typeimage.image = UIImage(named: "terminal")
            self.cash_value.text = "Pagando con terminal"
        }else {
            let count = AppData.shared.cardDetailData.count
            for index in 0..<count {
                let carddetail = AppData.shared.cardDetailData[index] as! NSDictionary
                let cardnumber = carddetail["id"] as! String
                if (card_num.elementsEqual(cardnumber)) {
                    let brand = carddetail["brand"] as! String
                    let last4 = carddetail["last4"] as! String
                    self.card_name.text = brand
                    self.card_number.text = "**** ****" + last4
                    let cardtype_sm = brand.lowercased()
                    switch (cardtype_sm) {
                    case "visa" :
                        self.card_typeimage.image = UIImage(named: "stp_card_visa")
                        break
                    case "mastercard" :
                        self.card_typeimage.image = UIImage(named: "stp_card_mastercard")
                        break
                    case "american express" :
                        self.card_typeimage.image = UIImage(named: "stp_card_amex")
                        break
                    case "discover" :
                        self.card_typeimage.image = UIImage(named: "stp_card_discover")
                        break
                    case "diners_club" :
                        self.card_typeimage.image = UIImage(named: "stp_card_diners")
                    case "jcb" :
                        self.card_typeimage.image = UIImage(named: "stp_card_jcb")
                    default:
                        self.card_typeimage.image = UIImage(named: "stp_card_unknown")
                    }
                }
            }
            
        }
        
    
        
        
        switch orderstatus {
        case "1":
            order_status.text =  "Estatus de orden:" + "Pendiente"
            deliever_btn.isHidden = true
            button_height.constant = 0
            self.space_height.constant = space_height.constant + 17.5
            //deliverview.isHidden = true
            break
        case "2":
            order_status.text = "Estatus de orden:" + "Procesando"
            deliever_btn.isHidden = true
            button_height.constant = 0
            self.space_height.constant = space_height.constant + 17.5
            //deliverview.isHidden = true
            break
        case "3":
            order_status.text = "Estatus de orden:" + "En Recolección"
            deliever_btn.isHidden = true
          button_height.constant = 0
            self.space_height.constant = space_height.constant + 17.5
            break
        case "4":
            order_status.text = "Estatus de orden:" + "Recolectada"
            deliever_btn.isHidden = true
          button_height.constant = 0
            self.space_height.constant = space_height.constant + 17.5
            break
        case "5":
            order_status.text = "Estatus de orden:" +  "En Camino"
            deliever_btn.isHidden = true
           // deliverview.isHidden = true
            break
        case "6":
            order_status.text = "Estatus de orden:" + "Entregado"
            deliever_btn.isHidden = false
            button_height.constant = 30
            self.space_height.constant = 10
            break
        default:
            order_status.text = "Estatus de orden:" + "Entregado"
            deliever_btn.isHidden = true
            button_height.constant = 0
            self.space_height.constant = space_height.constant + 17.5
            break
        }
        orderDetailData()
        initUI()
    }
    func initUI(){
        deliever_btn.layer.cornerRadius = 15
        deliever_btn.layer.masksToBounds = true
        // Do any additional setup after loading the view.
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    func stringtoDate(datestr: String)->String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myDate = dateFormatter.date(from: datestr)!
        
        dateFormatter.dateFormat = "dd MMM YYYY"
        let somedateString = dateFormatter.string(from: myDate)
        return somedateString
    }
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (orderDataArray.count > 0){
            return orderDataArray.count
        }else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "orderdetailCell", for: indexPath) as! OrderDetailCell
        let cellOrderData = orderDataArray[indexPath.row] as! NSDictionary
        let imageurl = cellOrderData["product_image"] as! String
        let pd_count = cellOrderData["quantity"] as! String
        let pd_name = cellOrderData["product_name"] as! String
        let pd_amount = cellOrderData["amount"] as! String
        let pd_imageurl = AppConstants.imageproduct_url + imageurl
        cell.order_imageview.moa.url = pd_imageurl
        cell.product_name.text = pd_name
        cell.product_count.text = pd_count + "pzs"
        cell.product_amount.text = "$" + pd_amount
        return cell
    }
   
   
    @IBAction func Deliver_Action(_ sender: Any) {
      //  self.deliever_btn.pulstate()
        AppData.shared.addgif(sender: deliever_btn)
        self.UpdateOrder()
    }
    func orderDetailData(){
        let orderData = AppData.shared.order_Data[orderindex] as! NSDictionary
        let orderid = orderData["id"] as! String
        let url = URL(string: AppConstants.baseUrl + "getOrder_detail/" + orderid)!
        print(url)
        Alamofire.request(url, method: .post ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            self.orderDataArray = responseData["orderdata"] as! NSMutableArray
                            if (self.orderDataArray.count > 0) {
                                let count = self.orderDataArray.count
                                let height_count = count / 2 + 1
                                if (height_count > 1){
                                    self.container_height.constant = self.container_height.constant + 146 * (CGFloat(height_count) - 1)
                                    self.sub_containerheight.constant = self.sub_containerheight.constant + 146 * (CGFloat(height_count) - 1)
                                }
                                print(height_count)
                                self.product_viewheight.constant = 146 * CGFloat(height_count)
                                let subcount = AppData.shared.product_Data.count
                                for index in 0..<count {
                                     let cellOrderData = self.orderDataArray[index] as! NSDictionary
                                     let pd_name = cellOrderData["product_name"] as! String
                                     let pd_amount = cellOrderData["amount"] as! String
                                     let pd_quantity = cellOrderData["quantity"] as! String
                                    let pd_value = Float(pd_amount) as! Float
                                    let quantity = Float(pd_quantity) as! Float
                                    let pd_price = pd_value  * quantity
                                    self.subtotal_price = self.subtotal_price + pd_price
                                    for index_sub in 0..<subcount {
                                        let productdata = AppData.shared.product_Data[index_sub] as! NSDictionary
                                        let productname = productdata["productname"] as! String
                                        let pd_tax = productdata["product_tax"] as! String
                                        if (pd_name.elementsEqual(productname)){
                                            let pd_taxvalue = Float(pd_tax) as! Float
                                            self.tax_value = self.tax_value + pd_taxvalue
                                        }
                                    }
                                }
                                self.total_value.text = "$" + String(self.tax_value)
                                self.delivery_fee.text = "$" + String(self.subtotal_price)
                                
                            }
                            self.orderDetailview.reloadData()
                        }
                        break
                    case .failure(let error):
                        print(error)
                        
            }
          }
    }
    func UpdateOrder(){
        let orderData = AppData.shared.order_Data[orderindex] as! NSDictionary
        let orderid = orderData["id"] as! String
        let jsondata: [String:Any] = ["orderid" : orderid, "driverid" : AppData.shared.profile_customerid,"drivername": "","status": "7"]
        let url = URL(string: AppConstants.baseUrl + "getOrder_detail/" + orderid)!
        print(url)
        Alamofire.request(url, method: .post,parameters: jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                if (message == "success"){
                    print("success")
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "feedbackVC") as! FeedbackViewController
                    vc.orderid = orderid
                    vc.orderindex = self.orderindex
                    self.navigationController?.pushViewController(vc, animated: true)
                }else {
                    AppData.shared.displayToastMessage(message)
                }
                break
            case .failure(let error):
                print(error)
                
            }
        }
    }
    
}
extension OrderDetailViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
        let bounds = collectionView.bounds
        
        return CGSize(width: bounds.width / 2 - 5, height: bounds.width / 2 - 5)
      
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
}
