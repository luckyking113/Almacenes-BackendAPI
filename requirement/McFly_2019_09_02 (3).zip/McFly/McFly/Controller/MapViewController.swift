//
//  MapViewController.swift
//  McFly
//
//  Created by LiuYan on 6/2/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import MapKit
import GoogleMaps
import GooglePlaces
class ImageAnnotation : NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    init(pinTitle: String, pinSubTitle:String,pinlocation:CLLocationCoordinate2D) {
        self.coordinate = pinlocation
        self.title = pinTitle
        self.subtitle = pinSubTitle
    }
}
class MapViewController: UIViewController, MKMapViewDelegate, UIGestureRecognizerDelegate,CLLocationManagerDelegate, GMSMapViewDelegate
{

    
    @IBOutlet weak var address_field: UITextField!
    
    @IBOutlet weak var add_partaddress: UITextField!
    
   
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var confirm_addressBtn: UIButton!
    var flag_str : String = ""
    var address : String = ""
    var address_location  : CLLocationCoordinate2D!
    var zipcode : String = ""
    var gotoFlag : String = ""
    var locationManager = CLLocationManager()
     var marker = GMSMarker()
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.mapView.delegate = self
        if (self.address != ""){
            self.address_field.text = address
            
           
        }
        self.address_field.addTarget(self, action: #selector(myTargetFunction), for: .touchDown)
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
        // Do any additional setup after loading the view.
        let locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Check for Location Services
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
        }
        self.locationManager = locationManager
        
        DispatchQueue.main.async {
            self.locationManager.startUpdatingLocation()
        }
        
        setMapview()
    }
    @objc func myTargetFunction(textField: UITextField) {
        if (textField == self.address_field){
            let autocompleteController = GMSAutocompleteViewController()
            autocompleteController.delegate = self
            
            // Specify the place data types to return.
            let fields: GMSPlaceField = GMSPlaceField(rawValue: UInt(GMSPlaceField.name.rawValue) |
                UInt(GMSPlaceField.placeID.rawValue) | GMSPlaceField.formattedAddress.rawValue |
                UInt(GMSPlaceField.coordinate.rawValue))!
            autocompleteController.placeFields = fields
            
            // Specify a filter.
//            let filter = GMSAutocompleteFilter()
//            filter.type = .address
//            autocompleteController.autocompleteFilter = filter
            
            // Display the autocomplete view controller.
            present(autocompleteController, animated: true, completion: nil)
        }
        print("myTargetFunction")
    }
    override func viewWillAppear(_ animated: Bool) {
       
    }
    func setMapview(){
        if (self.address.isEmpty){
            if let userLocation = locationManager.location?.coordinate {
                let lat = userLocation.latitude as! Double
                let lng = userLocation.longitude as! Double
                let camera = GMSCameraPosition.camera(withLatitude: lat,
                                                      longitude: lng,
                                                      zoom: 16)
                self.mapView.camera = camera
                
                marker.position = CLLocationCoordinate2D(latitude: lat, longitude: lng)
                marker.isDraggable = true
                marker.map = self.mapView
            }
        }else {
            let camera = GMSCameraPosition.camera(withLatitude: self.address_location.latitude,
                                                  longitude: self.address_location.longitude,
                                                  zoom: 16)
            self.mapView.camera = camera
         
            marker.position = CLLocationCoordinate2D(latitude: self.address_location.latitude, longitude: self.address_location.longitude)
            marker.map = self.mapView
        }
       
        self.mapView.settings.compassButton = true
        self.mapView.settings.myLocationButton =  true
        self.mapView.isMyLocationEnabled = true
//        marker.isDraggable = true
        
       
        
    }
    func mapView(_ mapView: GMSMapView, didDrag marker: GMSMarker) {
      //  print("dragged")
    }
    func mapView(_ mapView: GMSMapView, didBeginDragging marker: GMSMarker) {
        // print("begindragged")
        self.address_field.text = "Cargando..."
    }
    func mapView(_ mapView: GMSMapView, didEndDragging marker: GMSMarker) {
      
    }
    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
        self.address_field.text = "Cargando..."
        self.mapView.clear()
        let location = self.mapView.camera.target
        marker.position = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
        marker.map = self.mapView
        self.address_location = marker.position
        let geocoder = GMSGeocoder()
        let position = marker.position
        geocoder.reverseGeocodeCoordinate(position, completionHandler: {response,error in
            if let gmsAddress = response!.firstResult(){
                let zipcode = gmsAddress.postalCode as! String
                self.zipcode = zipcode
                let address_array = gmsAddress.lines as! [String]
                var address_str: String = ""
                for index in 0..<address_array.count {
                    let sub_adress = address_array[index] as! String
                    address_str = address_str + sub_adress
                }
                self.address_field.text = address_str
                //                self.add_partaddress.text = address2
                print(address_str)
            }
        })
    }
    func mapViewDidChangeVisibleRegion(_ mapView: MKMapView) {
       
    }
    
    @objc func onClcikBack()
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func confirm_address(_ sender: Any) {
        //self.confirm_addressBtn.pulstate()
        AppData.shared.addgif(sender: confirm_addressBtn)
        let confirmStr = self.address_field.text as! String
        if (confirmStr.isEmpty){
            AppData.shared.displayToastMessage("No confirmed location")
            return
        }
        let add_partString = self.add_partaddress.text as! String
        if (add_partString.isEmpty){
            AppData.shared.select_shipping_address = confirmStr
        }else {
            AppData.shared.select_shipping_address = confirmStr + add_partString
        }
        AppData.shared.select_shipzipcode = self.zipcode
        AppData.shared.select_shippin_address_lon = self.address_location.longitude
        AppData.shared.select_shipping_address_lat = self.address_location.latitude
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "newshipVC") as! AddNewShippingAddressViewController
        vc.flag_str = self.flag_str
        vc.gotoFlag = self.gotoFlag
        _ = self.navigationController?.popViewController(animated: true)
        
    }
   
   
   
}
extension MapViewController: GMSAutocompleteViewControllerDelegate {
    
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        print("Place name: \(place.name)")
        print("Place ID: \(place.placeID)")
        print("Place attributions: \(place.attributions)")
        print("Place attributions: \(place.formattedAddress)")
        dismiss(animated: true, completion: nil)
        let address_str = place.formattedAddress as! String
        let camera = GMSCameraPosition.camera(withLatitude: place.coordinate.latitude,
                                              longitude: place.coordinate.longitude,
                                              zoom: 16)
        self.mapView.camera = camera
        self.mapView.clear()
        marker.position = CLLocationCoordinate2D(latitude: place.coordinate.latitude, longitude: place.coordinate.longitude)
        marker.map = self.mapView
        self.address_field.text = address_str
        self.address_location = place.coordinate
        let geocoder = GMSGeocoder()
        geocoder.reverseGeocodeCoordinate(place.coordinate, completionHandler: {response,error in
            if let gmsAddress = response!.firstResult(){
                let zipcode = gmsAddress.postalCode as! String
                self.zipcode = zipcode
                print(zipcode)
            }
        })
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // TODO: handle the error.
        print("Error: ", error.localizedDescription)
    }
    
    // User canceled the operation.
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    // Turn the network activity indicator on and off again.
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
}
