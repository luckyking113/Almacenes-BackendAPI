//
//  CartViewController.swift
//  McFly
//
//  Created by LiuYan on 5/27/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import MaterialComponents.MaterialBottomSheet
class CartViewController: UIViewController {

    
    @IBOutlet weak var checkout_btn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
    }
    func initUI(){
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    @objc func onClcikBack()
    {
        if (AppData.shared.customer_zipcode == ""){
            let alert = SubmitZipCode(title: "",viewcontroller: self)
            alert.show(animated: true)
        }else {
            let alert = LoadingDialog(title: "" , viewcontroller: self)
            alert.show(animated: true)
        }
    }
    @IBAction func checkOut_action(_ sender: Any) {
        AppData.shared.addgif(sender: checkout_btn)
        let loginStatus = AppData.shared.profile_customerDetailData["status"] as! String
       
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "checkoutVC") as! CheckOutViewController
//        self.navigationController?.pushViewController(vc, animated: true)
        let weekday = Calendar.current.component(.weekday, from: Date())
        let formatter = DateFormatter()
        formatter.dateFormat = "hh a" // "a" prints "pm" or "am"
        let hourString = formatter.string(from: Date())
        switch weekday {
            case 1:
                let ware_sundaystarttime = AppData.shared.ware_houseData["sun_working_starttime"] as! String
                let ware_sundayendtime = AppData.shared.ware_houseData["sun_working_endtime"] as! String
                
                
                
                break
        case 2:
                let ware_mondaystarttime = AppData.shared.ware_houseData["mon_working_starttime"] as! String
                let ware_mondayendtime = AppData.shared.ware_houseData["mon_working_endtime"] as! String

                break
            case 3:
                let ware_tuesdaystarttime = AppData.shared.ware_houseData["tue_working_starttime"] as! String
                let ware_tuesdayendtime = AppData.shared.ware_houseData["tue_working_endtime"] as! String
                
                break
            case 4:
                let ware_wendnesdaystarttime = AppData.shared.ware_houseData["wed_working_starttime"] as! String
                let ware_wendnesdayendtime = AppData.shared.ware_houseData["wed_working_endtime"] as! String
                
                break
            case 5:
                let ware_thursdaystarttime = AppData.shared.ware_houseData["thu_working_starttime"] as! String
                let ware_thursdayendtime = AppData.shared.ware_houseData["tue_working_endtime"] as! String
                
                break
            case 6:
                let ware_fridaystarttime = AppData.shared.ware_houseData["fri_working_starttime"] as! String
                let ware_fridayendtime = AppData.shared.ware_houseData["fri_working_endtime"] as! String
                
                break
            case 7:
                let ware_saturdaystarttime = AppData.shared.ware_houseData["sat_working_starttime"] as! String
                let ware_saturdayendtime = AppData.shared.ware_houseData["sat_working_endtime"] as! String
                
                break
            default:
                break
        }
        
        
       if (AppData.shared.cartProductData.count == 0){
            AppData.shared.displayToastMessage("Por favor selecciona minimo un producto")
        }else if (loginStatus != "1"){
            AppData.shared.displayToastMessage("Please  try login or sign up")
        }else if (AppData.shared.warehouseworkingstatus == 0 && AppData.shared.customer_zipcode != ""){
            let alert = CustomAlert(title: "¡Lo sentimos!")
            alert.show(animated: true)

        }else if (AppData.shared.customer_totalPrice < 50){
            let alert = CartAlert(title: "Casi... pero aun no")
            alert.show(animated: true)
        }else {
            if (AppData.shared.select_discountcode == ""){
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "checkoutVC") as! CheckOutViewController
                self.navigationController?.pushViewController(vc, animated: true)
            } else
            {
                if (checkdiscountcode() == true){
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "checkoutVC") as! CheckOutViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                }else {
                    AppData.shared.displayToastMessage("Sorry!.this shipping is out of area")
                }
            }
        }
       
    }
    func checkdiscountcode()->Bool{
        var flag : Bool = false
        let ship_addressData = AppData.shared.profile_shippingAddress[AppData.shared.select_indexship] as! NSDictionary
        let select_zipcode = ship_addressData["address_zipcode"] as! String
        let warehouse_ziocodeArray = AppData.shared.ware_houseData["zip_code"] as! String
        let zipcode_array : [String] = warehouse_ziocodeArray.components(separatedBy: ",")
        for index in 0..<zipcode_array.count {
            if (zipcode_array[index] == select_zipcode){
                flag = true
                
            }
        }
        return flag
    }
    override func viewDidAppear(_ animated: Bool) {
        
        if (AppData.shared.profile_loginstatus){
            if let tabItems = tabBarController?.tabBar.items {
                // In this case we want to modify the badge number of the third tab:
                AppData.shared.cartBadge_number = UserDefaults.standard.integer(forKey: "cartCount") ?? 0
                if (AppData.shared.cartBadge_number > 0){
                    let badge_str : String = String(AppData.shared.cartBadge_number) as! String
                    let tabItem = tabItems[1]
                    tabItem.badgeValue = badge_str
                }
                else {
                    let tabItem = tabItems[1]
                    tabItem.badgeValue = nil
                }
                
            }
        }
        
    }
}
