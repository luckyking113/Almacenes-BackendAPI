//
//  HomeViewController.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import moa
class HomeViewController: UIViewController {

    @IBOutlet weak var home_collectionView: UICollectionView!
    @IBOutlet weak var home_collectionview2: UICollectionView!
    var col_count1: Int = 0
    var col_count2 : Int = 0
    
    @IBOutlet weak var order_alertbtn: UIButton!
    
    @IBOutlet weak var Order_ViewTable: UITableView!
    
    @IBOutlet weak var collectionview1: NSLayoutConstraint!
    
    
    @IBOutlet weak var tableview_height: NSLayoutConstraint!
    
    @IBOutlet weak var colletionview2: NSLayoutConstraint!
    
    @IBOutlet weak var main_deliveraddressbtn: UIButton!
    var titlebutton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .plain, target: nil, action: nil)
        let searchImageicon = UIImage(named: "search")!
        let zipimageicon = UIImage(named: "location3")!
        let searchBtn: UIButton = UIButton(type: UIButton.ButtonType.custom) as! UIButton
        searchBtn.setImage(searchImageicon, for: .normal)
        searchBtn.addTarget(self, action: #selector(searchBtnPressed), for: .touchUpInside)
        searchBtn.frame = CGRect(origin : CGPoint(x:0, y:0), size: CGSize(width: 20, height: 20))
        let searchBarBtn = UIBarButtonItem(customView: searchBtn)
        
        let zipcodebtn: UIButton = UIButton(type: UIButton.ButtonType.custom) as! UIButton
        zipcodebtn.setImage(zipimageicon, for: .normal)
        zipcodebtn.addTarget(self, action: #selector(submitzipcode), for: .touchUpInside)
        zipcodebtn.frame = CGRect(origin : CGPoint(x:-10, y:0), size: CGSize(width: 20, height: 20))
        let clipBarBtn = UIBarButtonItem(customView: zipcodebtn)
        self.navigationItem.setRightBarButtonItems([searchBarBtn], animated: false)
        self.navigationItem.setLeftBarButtonItems([clipBarBtn], animated: false)
        
        titlebutton =  UIButton(type: .custom)
        titlebutton.frame = CGRect(x: 0, y: 0, width: 200, height: 40)
        titlebutton.setTitleColor(UIColor.darkGray, for: .normal)
        titlebutton.semanticContentAttribute = UIApplication.shared
            .userInterfaceLayoutDirection == .rightToLeft ? .forceLeftToRight : .forceRightToLeft
      
//        titlebutton.imageEdgeInsets = UIEdgeInsets(top: 5, left: (titlebutton.frame.width - 35), bottom: 5, right: 5)
//        titlebutton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: (titlebutton.imageView?.frame.width)!)
        let image = UIImage(named: "title1.png")
        titlebutton.setImage(image, for: .normal)
        titlebutton.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        titlebutton.addTarget(self, action: #selector(clickOnButton), for: .touchUpInside)
        
        if (AppData.shared.default_maindeliveraddress != ""){
            let address_strarray : [String] = AppData.shared.default_maindeliveraddress.components(separatedBy: ",")
            let streetaddress = address_strarray[0]
            titlebutton.setTitle(streetaddress, for: .normal)
            navigationItem.titleView = titlebutton
        }
        
        
        home_collectionView.dataSource = self
        home_collectionView.delegate = self
        home_collectionview2.delegate = self
        home_collectionview2.dataSource = self
        Order_ViewTable.delegate = self
        Order_ViewTable.dataSource = self
        Order_ViewTable.isHidden = true
        // Do any additional setup after loading the view.
        //main_deliveraddressbtn.titleLabel!.lineBreakMode = .byWordWrapping
       // main_deliveraddressbtn.titleLabel!.numberOfLines = 2
       // main_deliveraddressbtn.titleLabel!.textAlignment = .center
        if (AppData.shared.zipdialog_flag == 0){
            if (AppData.shared.default_maindeliverid == ""){
                let alert = SubmitZipCode(title: "",viewcontroller: self)
                alert.show(animated: true)
            }else {
                var flag : Int = 0
                let zipcodearray = AppConstants.warehouse_zipcode.components(separatedBy: ",")
                for index in 0..<zipcodearray.count {
                    let zipcode = zipcodearray[index] as! String
                    if (AppData.shared.customer_zipcode.elementsEqual(zipcode)){
                        AppData.shared.set_flag = 1
                        flag = 1
                    }
                    
                }
                if (flag == 0) {
                    AppData.shared.set_flag = 0
                }
//                print(AppData.shared.set_flag)
//                print(AppData.shared.customer_zipcode)
                let alert = LoadingDialog(title: "" , viewcontroller: self)
                alert.show(animated: true)
            }
            
        }
        
    }
    @objc func clickOnButton() {
        print("test")
        if  (AppData.shared.profile_loginstatus) {
            if (AppData.shared.default_maindeliveraddress != ""){
                AppData.shared.set_flag = 1
            }else{
                AppData.shared.set_flag = 0
            }
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
            vc.goback = "home"
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            let alert = SignUpDialog(title: "",viewcontroller: self)
            alert.show(animated: true)
        }
       
    }
    
    @IBAction func select_mainaddress(_ sender: Any) {
      
    }
    @IBAction func Order_tableshow(_ sender: Any) {
        AppData.shared.addgif(sender: order_alertbtn)
        if (AppData.shared.profile_loginstatus){
            if (AppData.shared.wrong_warehouse == 1){
                if (Order_ViewTable.isHidden){
                    Order_ViewTable.isHidden = false
                }else {
                    Order_ViewTable.isHidden = true
                    
                }
            }else {
                let alert = CheckZipCode(title: "",viewcontroller: self)
                alert.show(animated: true)
            }
            
        }else {
            Order_ViewTable.isHidden = true
            if (AppData.shared.wrong_warehouse == 1){
                
            }else {
                let alert = CheckZipCode(title: "",viewcontroller: self)
                alert.show(animated: true)
            }
        }
        
        
    }
    @objc func submitzipcode(sender : UIButton!){
        let alert = SubmitZipCode(title: "",viewcontroller: self)
        alert.show(animated: true)
    }
    @objc func searchBtnPressed(sender : UIButton!){
        if (AppData.shared.product_Data.count > 0) {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "searchVC") as! SearchViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            AppData.shared.displayToastMessage("There are no products")
        }
    }
    @IBAction func submit_zipcode(_ sender: Any) {
        
    }
    
    @IBAction func Search_product(_ sender: Any) {
       
        
    }
    override func viewDidAppear(_ animated: Bool) {
        if (AppData.shared.categroy_Data.count > 0){
            print("dddd")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.home_collectionView.reloadData()
                self.home_collectionview2.reloadData()
            }
            
        }
        print("wrongwarehousse")
        print(AppData.shared.wrong_warehouse)
        if (AppData.shared.profile_loginstatus){
            if (AppData.shared.wrong_warehouse == 1){
                
                if (AppData.shared.order_Data.count > 0){
                    self.order_alertbtn.isHidden = false
                    print(AppData.shared.order_Data)
                    if (AppData.shared.default_maindeliveraddress == ""){
                        //self.main_deliveraddressbtn.isHidden = true
                        if (AppData.shared.show_address != ""){
                            titlebutton.setTitle(AppData.shared.show_address, for: .normal)
                            navigationItem.titleView = titlebutton
                            collectionview1.constant = 30
                            colletionview2.constant = 30
                        }else{
                            titlebutton.setTitle("⚠️ Selecciona tu dirección!", for: .normal)
                            navigationItem.titleView = titlebutton
                            collectionview1.constant = 30
                            colletionview2.constant = 30
                        }
                      
                    }else {
                        let address_strarray : [String] = AppData.shared.default_maindeliveraddress.components(separatedBy: ",")
                        let streetaddress = address_strarray[0]
                        titlebutton.setTitle(streetaddress, for: .normal)
                        navigationItem.titleView = titlebutton
                        collectionview1.constant = 30
                        colletionview2.constant = 30
                    }
                    let frame: CGRect = self.view.frame
                   // var tbl_height: CGFloat = CGFloat(71 * AppData.shared.order_Data.count) as! CGFloat
//                    if (AppData.shared.order_Data.count < 13){
//                        tbl_height = CGFloat(71 * AppData.shared.order_Data.count) as! CGFloat
//                    }else {
//                        tbl_height = CGFloat(71 * 13) as! CGFloat
//                    }
                    self.tableview_height.constant = 0
                    var tbl_height : CGFloat = 0
                    for index in 0..<AppData.shared.order_Data.count {
                        let orderdata = AppData.shared.order_Data[index] as! NSDictionary
                        let orderstatus = orderdata["status"] as! String
                        
                            if (orderstatus != "6") {
                                tbl_height = tbl_height + 45
                            }else{
                                tbl_height = tbl_height + 71
                            }
                        
                        
                    }
                    print(tbl_height)
                    self.tableview_height.constant = tbl_height
                    let countstr = String(AppData.shared.order_Data.count) as! String
                    let alertstring = "Tienes " + countstr + " ordenes activas"
                    self.order_alertbtn.layer.backgroundColor = UIColor.init(red: 39/255, green: 149/255, blue: 246/255, alpha: 1.0).cgColor
                    self.order_alertbtn.setTitle(alertstring, for: .normal)
                    self.order_alertbtn.setTitleColor(UIColor.white, for: .normal)
                }else {
                    print("testtest")
                    if (AppData.shared.default_maindeliveraddress == ""){
                       // self.main_deliveraddressbtn.isHidden = true
                        if (AppData.shared.show_address != ""){
                            titlebutton.setTitle(AppData.shared.show_address, for: .normal)
                            navigationItem.titleView = titlebutton
                            self.order_alertbtn.isHidden = true
                            collectionview1.constant = 0
                            colletionview2.constant = 0
                        }else{
                            titlebutton.setTitle("⚠️ Selecciona tu dirección!", for: .normal)
                            navigationItem.titleView = titlebutton
                            self.order_alertbtn.isHidden = true
                            collectionview1.constant = 0
                            colletionview2.constant = 0
                        }
                       
                    }else {
                        //self.main_deliveraddressbtn.isHidden = false
                      //  self.main_deliveraddressbtn.setTitle(AppData.shared.default_maindeliveraddress, for: .normal)
                        let address_strarray : [String] = AppData.shared.default_maindeliveraddress.components(separatedBy: ",")
                        let streetaddress = address_strarray[0]
                        print(streetaddress)
                        //self.main_deliveraddressbtn.setTitle(streetaddress, for: .normal)
                        titlebutton.setTitle(streetaddress, for: .normal)
                         navigationItem.titleView = titlebutton
                        self.order_alertbtn.isHidden = true
                        collectionview1.constant = 0
                        colletionview2.constant = 0
                    }
                    
                }
                if let tabItems = tabBarController?.tabBar.items {
                    // In this case we want to modify the badge number of the third tab:
                    AppData.shared.cartBadge_number = UserDefaults.standard.integer(forKey: "cartCount") ?? 0
                    if (AppData.shared.cartBadge_number > 0){
                        let badge_str : String = String(AppData.shared.cartBadge_number) as! String
                        let tabItem = tabItems[1]
                        tabItem.badgeValue = badge_str
                    }
                    else {
                        let tabItem = tabItems[1]
                        tabItem.badgeValue = nil
                    }
                    
                }
            }else if (AppData.shared.wrong_warehouse == 0) {
                //make Yellow Alert Button
                self.order_alertbtn.isHidden = false
                collectionview1.constant = 30
                colletionview2.constant = 30
                 self.order_alertbtn.layer.backgroundColor = UIColor.yellow.cgColor
                 self.order_alertbtn.setTitle("Aún no llegamos a tu área", for: .normal)
                 self.order_alertbtn.setTitleColor(UIColor.blue, for: .normal)
                if (AppData.shared.default_maindeliveraddress == ""){
                   // self.main_deliveraddressbtn.isHidden = true
                    titlebutton.setTitle("⚠️ Selecciona tu dirección!", for: .normal)
                    navigationItem.titleView = titlebutton
                    collectionview1.constant = 30
                    colletionview2.constant = 30
                }else {
                    //self.main_deliveraddressbtn.isHidden = false
                    //self.main_deliveraddressbtn.setTitle(AppData.shared.default_maindeliveraddress, for: .normal)
                   // let address_strarray : [String] = AppData.shared.default_maindeliveraddress.components(separatedBy: ",")
                    //let streetaddress = address_strarray[0]
                    //self.main_deliveraddressbtn.setTitle(streetaddress, for: .normal)
                    if (AppData.shared.show_address != ""){
                        titlebutton.setTitle(AppData.shared.show_address, for: .normal)
                        navigationItem.titleView = titlebutton
                        collectionview1.constant = 30
                        colletionview2.constant = 30
                    }else{
                        titlebutton.setTitle("⚠️ Selecciona tu dirección!", for: .normal)
                        navigationItem.titleView = titlebutton
                        collectionview1.constant = 30
                        colletionview2.constant = 30
                    }
                   
                }
            }
            
        }else {
            if (AppData.shared.wrong_warehouse == 0){
//                if let tabBarController = self.tabBarController {
//                    let indexToRemove = 2
//                    let count : Int = tabBarController.viewControllers?.count as! Int
//                    if indexToRemove < count {
//                        var viewControllers = tabBarController.viewControllers
//
//                        let tabbaritem : [UITabBarItem] =  tabBarController.tabBar.items
//                    }
//                }
                //make Yellow Alert Button
                //self.main_deliveraddressbtn.isHidden = true
                titlebutton.setTitle("⚠️ Selecciona tu dirección!", for: .normal)
                navigationItem.titleView = titlebutton
                collectionview1.constant = 30
                colletionview2.constant = 30
                self.order_alertbtn.isHidden = false
                self.order_alertbtn.layer.backgroundColor = UIColor.yellow.cgColor
                self.order_alertbtn.setTitle("We can 't deliver in your area", for: .normal)
                self.order_alertbtn.setTitleColor(UIColor.blue, for: .normal)
            }else {
                collectionview1.constant = 0
                colletionview2.constant = 0
                self.order_alertbtn.isHidden = true
                titlebutton.setTitle("⚠️ Selecciona tu dirección!", for: .normal)
                navigationItem.titleView = titlebutton
                //self.main_deliveraddressbtn.isHidden = true
//                if let tabBarController = self.tabBarController {
//                    let indexToRemove = 2
//                    let count : Int = tabBarController.viewControllers?.count as! Int
//                    if indexToRemove < count {
//                        var viewControllers = tabBarController.viewControllers
//                        viewControllers?.remove(at: indexToRemove)
//                        tabBarController.viewControllers = viewControllers
//                    }
//                }
            }
        }
       
       
    }
}
extension HomeViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppData.shared.order_Data.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
         let orderdata = AppData.shared.order_Data[indexPath.row] as! NSDictionary
        let orderstatus = orderdata["status"] as! String
        
            let ordercell = tableView.dequeueReusableCell(withIdentifier: "orderactiveCell", for: indexPath) as! OrderActiveCell
            ordercell.selectionStyle = .none
            
            ordercell.cell_orderData = orderdata
            let orderid = orderdata["order_id"] as! String
            ordercell.orderNumber = indexPath.row
            ordercell.orderid = orderid
            ordercell.controller = self
            ordercell.order_idlbl.text = "Orden #" + orderid
            
            let ordertime = orderdata["order_time"] as! String
            let orderdatestr : [String] = ordertime.components(separatedBy: " ")
            let orderdatestr1 = orderdatestr[0] as! String
            let datestr : [String] = orderdatestr1.components(separatedBy: "-")
            let timestr :[String] = orderdatestr[1].components(separatedBy: ":")
            var checktime = Int(timestr[0]) as! Int
            var showtimestr : String = ""
            if (checktime > 12) {
                showtimestr = "p.m"
                checktime = checktime - 12
            }else {
                showtimestr = "a.m"
            }
            let fixtimestr = String(checktime) as! String
            let mexicodate =  datestr[2] + "/" + datestr[1]  + "   " + fixtimestr + ":" + timestr[1]  + " " + showtimestr
            ordercell.order_datelbl.text = mexicodate
            switch orderstatus {
            case "1":
                ordercell.order_statuslbl.text = "Estatus: Pendiente"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                break
            case "2":
                ordercell.order_statuslbl.text = "Estatus: Procesando"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                break
            case "3":
                ordercell.order_statuslbl.text = "Estatus: En Recolección"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                break
            case "4":
                ordercell.order_statuslbl.text = "Estatus: Recolectada"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                break
            case "5":
                ordercell.order_statuslbl.text = "Estatus: En Camino"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                break
            case "6":
                ordercell.order_statuslbl.text = "Estatus: Entregado"
                ordercell.order_confirmbtn.isHidden = false
                ordercell.confrim_buttonheight.constant = 20
                break
            case "7":
                ordercell.order_statuslbl.text = "Completed"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                break
            default:
                ordercell.order_statuslbl.text = "Estatus: Entregado"
                ordercell.order_confirmbtn.isHidden = true
                ordercell.confrim_buttonheight.constant = 0
                
                break
            }
            
            return ordercell
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ordertrackVC") as! OrderTrackViewController
        vc.orderindex = indexPath.row
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let orderdata = AppData.shared.order_Data[indexPath.row] as! NSDictionary
        let orderstatus = orderdata["status"] as! String
        if (orderstatus != "6") {
            print("45")
            return 30
            
        }else {
            print("71")
            return 71
        }
    }
    
}



extension HomeViewController: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (AppData.shared.categroy_Data.count > 0){
           let rest = AppData.shared.categroy_Data.count % 2
            if (rest == 0){
                 col_count1 = AppData.shared.categroy_Data.count / 2
                 col_count2 = AppData.shared.categroy_Data.count / 2
                if (collectionView == self.home_collectionView){
                    return col_count1
                }else {
                    return col_count2
                }
            }else {
                col_count1 = (AppData.shared.categroy_Data.count + 1) / 2
                col_count2 = col_count1 - 1
                if (collectionView == self.home_collectionView){
                    return col_count1
                }else {
                    return col_count2
                }
            }
        }else {
            if (collectionView == self.home_collectionView){
                return 0
            }else {
                return 0
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if (collectionView == self.home_collectionView){
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "homecell", for: indexPath) as! HomeCell
            let cat_data = AppData.shared.categroy_Data[indexPath.row] as! NSDictionary
            let cat_img = cat_data["cat_image"] as! String
            let img_url = URL(string: AppConstants.image_url + cat_img)!
            print(img_url)
            //AppData.shared.downloadImage(from: img_url, imageView: cell.image)
            cell.image.moa.url = AppConstants.image_url + cat_img
            cell.image.moa.errorImage = UIImage(named: "placeholder")
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "homecell2", for: indexPath) as! HomeCell2
            let cat_data = AppData.shared.categroy_Data[indexPath.row + col_count1] as! NSDictionary
            let cat_img = cat_data["cat_image"] as! String
            let img_url = URL(string: AppConstants.image_url + cat_img)!
            print(img_url)
            //AppData.shared.downloadImage(from: img_url, imageView: cell.image2)
            cell.image2.moa.url = AppConstants.image_url + cat_img
            cell.image2.moa.errorImage = UIImage(named: "placeholder")
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "subcategory1") as! SubCategoryFirstViewController
        if (collectionView == home_collectionView){
            let cat_data = AppData.shared.categroy_Data[indexPath.row] as! NSDictionary
            let cat_name = cat_data["cat_name"] as! String
            let sub_data = cat_data["subcategory"] as! NSMutableArray
            vc.subCategoryData = sub_data
            vc.category_name = cat_name
        }else {
            let cat_data = AppData.shared.categroy_Data[indexPath.row + col_count1] as! NSDictionary
            let sub_data = cat_data["subcategory"] as! NSMutableArray
            let cat_name = cat_data["cat_name"] as! String
            vc.subCategoryData = sub_data
            vc.category_name = cat_name
        }
       
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
extension HomeViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if (collectionView == self.home_collectionView){
            let cat_data = AppData.shared.categroy_Data[indexPath.row] as! NSDictionary
            let bounds = collectionView.bounds
            let cat_height = cat_data["cat_imageheight"] as! String
           
            let img_height = Float(cat_height) as! Float
             print(img_height)
           
            let height = CGFloat(img_height) as! CGFloat
            return CGSize(width: bounds.width, height: height)
        }else {
            let bounds = collectionView.bounds
            let cat_data = AppData.shared.categroy_Data[indexPath.row + col_count1 ] as! NSDictionary
            let cat_height = cat_data["cat_imageheight"] as! String
             print(cat_height)
            let img_height = Float(cat_height) as! Float
            let height = CGFloat(img_height) as! CGFloat
            return CGSize(width: bounds.width, height: height)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0 
    }
    
}
