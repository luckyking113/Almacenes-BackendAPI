//
//  OnBoardVC.swift
//  McFly
//
//  Created by LiuYan on 8/17/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class OnBoardVC: UIViewController, UITextViewDelegate, UIGestureRecognizerDelegate{

    
    @IBOutlet weak var next_btn: UIButton!
    
    @IBOutlet weak var term_btn: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        next_btn.layer.cornerRadius = 5
        next_btn.layer.masksToBounds = true
        let attributedString = NSMutableAttributedString(string: "Al seleccionar el botón de ‘Continuar’ estoy aceptando los términos y condiciones que conlleva usar esta aplicación. Puedes encontrar los términos y condiciones en https://www.mcflydelivery.com/terminos-y-condiciones/")
        let string1 = "https://www.mcflydelivery.com/terminos-y-condiciones/"
        let count = attributedString.length
        let location = count - string1.count
        attributedString.addAttribute(.link, value: "https://www.mcflydelivery.com/terminos-y-condiciones/", range: NSRange(location: location, length: string1.count))
        
        term_btn.attributedText = attributedString
        term_btn.textAlignment = .center
        term_btn.isSelectable = false
        term_btn.isUserInteractionEnabled = true
        let tapTerm = UITapGestureRecognizer(target: self, action: #selector(Open))
        tapTerm.delegate = self
        term_btn.addGestureRecognizer(tapTerm)
        
        // Do any additional setup after loading the view.
    }
    @objc func Open(){
        print("click")
        let url = URL(string: "https://www.mcflydelivery.com/terminos-y-condiciones/")!
        UIApplication.shared.open(url)
    }
    
    @IBAction func Next_Action(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
        self.present(verificationController, animated: true, completion: nil)
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        
        return true
    }
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
        UIApplication.shared.open(URL)
        return false
    }
}
