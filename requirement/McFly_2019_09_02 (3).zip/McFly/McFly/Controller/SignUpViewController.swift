//
//  SignUpViewController.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import FirebaseAuth
import GoogleSignIn
import FacebookLogin
import FBSDKCoreKit
import FBSDKLoginKit
import InstagramLogin
import Alamofire
import IQKeyboardManagerSwift
class SignUpViewController: UIViewController, GIDSignInDelegate, GIDSignInUIDelegate {

    
    @IBOutlet weak var signUpView: UIView!
    @IBOutlet weak var phone_number: UITextField!
    var instagramLogin: InstagramLoginViewController!
    var instagram_accessToken : String = ""
    var instagram_id : String = ""
    
    @IBOutlet weak var fb_loginbt: UIButton!
    
    @IBOutlet weak var g_signupbtn: UIButton!
    
    @IBOutlet weak var instasignup_btn: UIButton!
    
    @IBOutlet weak var signup_btn: UIButton!
    
    @IBOutlet weak var goto_loginbtn: UIButton!
    
    @IBOutlet weak var guest_btn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        // Do any additional setup after loading the view.
    }
    func initUI() {
        self.navigationController?.navigationBar.isHidden = true
        signUpView.layer.cornerRadius = 20
        signUpView.layer.masksToBounds = true
        self.phone_number.keyboardType = .numberPad
    }
    
    @IBAction func goto_loginPage(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func signup_action(_ sender: Any) {
        //signup_btn.pulstate()
        AppData.shared.addgif(sender: signup_btn)
        let phoneNumber = self.phone_number.text as! String
        if (phoneNumber.isEmpty){
            self.showAlert("Please enter PhoneNumber")
        }
       
    }
    func showAlert(_ message: String) {
        let alertController = UIAlertController(title: "Signup Process", message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertAction.Style.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func Google_SignUp(_ sender: Any) {
       // g_signupbtn.pulstate()
        AppData.shared.addgif(sender: g_signupbtn)
        GIDSignIn.sharedInstance().signIn()
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print(error.localizedDescription)
            self.showAlert("Google Authentication Failed.")
            return
        }
        print(user.userID)
        print(user.profile.email)
        AppData.shared.profile_useremail = user.profile.email as! String
        AppData.shared.profile_verficationvalue = user.userID as! String
        AppData.shared.profile_accountType = 2
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
        //   self.present(verificationController, animated: true, completion: nil)
        self.navigationController?.pushViewController(verificationController, animated: true)
    }
    
    @IBAction func Fb_SignUp(_ sender: Any) {
        //fb_loginbt.pulstate()
        AppData.shared.addgif(sender: fb_loginbt)
        let fbLoinManager : LoginManager = LoginManager()
        fbLoinManager.logIn(permissions: ["email"], from: self){
            (result, error) in
            if (error == nil){
                let fbLoginResult : LoginManagerLoginResult = result!
                if fbLoginResult.grantedPermissions != nil {
                    if (fbLoginResult.grantedPermissions.contains("email")){
                        if((AccessToken.current) != nil){
                            GraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, email"]).start(completionHandler: { (connection, result, error) -> Void in
                                if (error == nil){
                                    print(result)
                                    let user_data = result as! NSDictionary
                                    AppData.shared.profile_useremail = user_data["email"] as! String
                                    AppData.shared.profile_firstname = user_data["first_name"] as! String
                                    AppData.shared.profile_lastname = user_data["last_name"] as! String
                                    AppData.shared.profile_verficationvalue = user_data["id"] as! String
                                    AppData.shared.profile_accountType = 1
                                    
                                   
                                }
                            })
                        }
                        
                    }
                }
            }
        }
    }
    
    @IBAction func Instagram_login(_ sender: Any) {
        instasignup_btn.pulstate()
        AppData.shared.addgif(sender: instasignup_btn)
        loginWithInstagram()
    }
    
    func loginWithInstagram() {
        
        // 2. Initialize your 'InstagramLoginViewController' and set your 'ViewController' to delegate it
        instagramLogin = InstagramLoginViewController(clientId: AppConstants.clientID, redirectUri: AppConstants.redirectUri)
        instagramLogin.delegate = self
        
        // 3. Customize it
        instagramLogin.scopes = [.basic, .publicContent] // [.basic] by default; [.all] to set all permissions
        instagramLogin.title = "Instagram" // If you don't specify it, the website title will be showed
        instagramLogin.progressViewTintColor = .blue // #E1306C by default
        
        // If you want a .stop (or other) UIBarButtonItem on the left of the view controller
        instagramLogin.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .stop, target: self, action: #selector(dismissLoginViewController))
        
        // You could also add a refresh UIBarButtonItem on the right
        instagramLogin.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .refresh, target: self, action: #selector(refreshPage))
     
        // 4. Present it inside a UINavigationController (for example)
        present(UINavigationController(rootViewController: instagramLogin), animated: true)
    }
    
    @objc func dismissLoginViewController() {
        instagramLogin.dismiss(animated: true)
    }
    
    @objc func refreshPage() {
        instagramLogin.reloadPage()
    }
    
    @IBAction func Do_laterSignup(_ sender: Any) {
        //guest_btn.pulstate()
        //AppData.shared.addgif(sender: instasignup_btn)
        AppData.shared.profile_loginstatus = false
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
        self.present(verificationController, animated: true, completion: nil)
    }
    override func viewDidAppear(_ animated: Bool) {
        print("kkkkk")
        if (instagram_id != ""){
            
        }
    }
    
    
}
extension SignUpViewController: InstagramLoginViewControllerDelegate {
    
    func instagramLoginDidFinish(accessToken: String?, error: InstagramError?) {
        if (error != nil){
            return
        }
        print(accessToken)
        self.instagram_accessToken = accessToken as! String
//        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
//        self.present(verificationController, animated: true, completion: nil)
        // Whatever you want to do ...
        let session = URLSession.shared
        let url = URL(string: AppConstants.getInstagramIDurl + self.instagram_accessToken)!
//        let json: [String: Any] = ["email" : email,"password" : password]
//
//        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        var request = URLRequest(url: url)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
       // request.httpBody = jsonData
        session.dataTask(with: request, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) in
            if let data = data{
                do{
                    let json = try JSONSerialization.jsonObject(with: data)
                    let  check_result = json as! NSDictionary
                    let  user_data = check_result["data"] as! NSDictionary
                    print(user_data)
                    let user_id = user_data["id"] as! String
                    self.instagram_id = user_id
                    AppData.shared.profile_verficationvalue = user_id
                    AppData.shared.profile_accountType = 3
                    print(user_id)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // Change `2.0` to the desired number of seconds.
                        // Code you want to be delayed
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
                        //   self.present(verificationController, animated: true, completion: nil)
                        self.navigationController?.pushViewController(verificationController, animated: true)
                    }
                  
                }
                catch {
                    print(error)
                }
            }
            
        }).resume()
        // And don't forget to dismiss the 'InstagramLoginViewController'
        instagramLogin.dismiss(animated: true)
    }
}
