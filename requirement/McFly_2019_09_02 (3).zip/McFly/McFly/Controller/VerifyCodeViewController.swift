//
//  VerifyCodeViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import SVPinView
import FirebaseAuth
class VerifyCodeViewController: UIViewController {

    
    
    @IBOutlet weak var pinVew: SVPinView!
    
    @IBOutlet weak var submit_btn: UIButton!
    var  phone_number : String = ""

    @IBOutlet weak var phone_label: UILabel!
    
    @IBOutlet weak var resend_link: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        configurePinView()
        // Do any additional setup after loading the view.
        let attributedString = NSMutableAttributedString(string: "Si no has recibido el código de verificación en un minuto, da click en Reenviar")
        let string1 = "Reenviar"
        let count = attributedString.length
        let location = count - string1.count
        attributedString.addAttribute(.link, value: "", range: NSRange(location: location, length: string1.count))
        resend_link.attributedText = attributedString
        resend_link.textAlignment = .center
        resend_link.isUserInteractionEnabled = true
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(Resend))
        resend_link.addGestureRecognizer(tapgesture)
    }
    @objc func Resend(){
        PhoneAuthProvider.provider().verifyPhoneNumber(self.phone_number, uiDelegate: nil) { (verificationID, error) in
            if error != nil {
                // Show alert here
                // self.showAlert("Authentication Failed!")
                print(error)
                //  AppData.shared.displayToastMessage(phoneNumber)
                return
            }
            AppData.shared.verification_id = verificationID as! String
        }
    }
    
    func configurePinView() {
       // self.navigationController?.navigationBar.isHidden = false
        phone_label.text = phone_number + "?"
        submit_btn.layer.cornerRadius = 15
        submit_btn.layer.masksToBounds = true
        //pinView.activeBorderLineThickness = 4
        pinVew.pinLength = 6
     //   pinVew.secureCharacter = "\u{25CF}"
        pinVew.interSpace = 2
        pinVew.textColor = UIColor.blue.withAlphaComponent(0.6)
        pinVew.borderLineColor = UIColor.blue.withAlphaComponent(0.6)
        pinVew.activeBorderLineColor = UIColor.white
        pinVew.activeFieldBackgroundColor = UIColor.clear
        pinVew.borderLineThickness = 1
        pinVew.activeBorderLineThickness = 1
       // pinVew.shouldSecureText = true
        pinVew.allowsWhitespaces = false
        pinVew.style = .box
        pinVew.fieldBackgroundColor = UIColor.clear
        pinVew.activeFieldBackgroundColor = UIColor.blue.withAlphaComponent(0.1)
        pinVew.fieldCornerRadius = 0
        pinVew.activeFieldCornerRadius = 0
        pinVew.placeholder = "******"
        pinVew.becomeFirstResponderAtIndex = 0
        
        pinVew.font = UIFont.systemFont(ofSize: 15)
        pinVew.keyboardType = .phonePad
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    
    @objc func dismissKeyboard() {
        
    }
    
    @IBAction func close_dialog(_ sender: Any) {
          _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submit_VerCode(_ sender: Any) {
        self.submit_btn.pulstate()
        let verifyCode = self.pinVew.getPin()
        let credential = PhoneAuthProvider.provider().credential(withVerificationID: AppData.shared.verification_id,
                                                    verificationCode: verifyCode)
        Auth.auth().signInAndRetrieveData(with: credential) { authData, error in
            if (error != nil) {
                // Handles error
               _ = self.navigationController?.popViewController(animated: true)
                return
            }
            AppData.shared.profile_verficationvalue = self.phone_number
            AppData.shared.profile_phoneNumber = self.phone_number
            AppData.shared.profile_accountType = 0
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
          //   self.present(verificationController, animated: true, completion: nil)
             self.navigationController?.pushViewController(verificationController, animated: true)
        }
        
    }
    
}
