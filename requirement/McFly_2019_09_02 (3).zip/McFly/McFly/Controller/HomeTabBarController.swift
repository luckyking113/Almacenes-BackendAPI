//
//  HomeTabBarController.swift
//  McFly
//
//  Created by LiuYan on 5/26/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class HomeTabBarController: UITabBarController,UITabBarControllerDelegate{

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        // Do any additional setup after loading the view
    }
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if (AppData.shared.profile_loginstatus == false){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "homeVC") as! HomeViewController
            if item == (self.tabBar.items as! [UITabBarItem])[1]{
                //Do something if index is 0
                print("click")
                let alert = SignUpDialog(title: "",viewcontroller: vc)
                alert.show(animated: true)
                
            }
            else if item == (self.tabBar.items as! [UITabBarItem])[2]{
                //Do something if index is 1
                print("click")
                let alert = SignUpDialog(title: "",viewcontroller: vc)
                alert.show(animated: true)
            }else {
              
            }
        }
       
    }
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        if (AppData.shared.profile_loginstatus == false){
            if (self.selectedIndex == 0){
                print("testfirst")
                return true
                
            }else{
                print("testtest")
                return false
            }
        }else {
            return true
        }
       
    }
    
}
