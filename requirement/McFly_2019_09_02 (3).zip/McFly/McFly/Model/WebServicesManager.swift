//
//  WebServicesManager.swift
//  McFly
//
//  Created by LiuYan on 5/30/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import Alamofire
public enum APIEndpoint {
    public enum userCase {
        case customersignup
        case userLogin
        case forgotpassword
        case carWashlist
        case sites
        case chemicals
        case chemicalpumpspeed
        case statistics
        case profile
        case lat
        case editprofile
        case near_job_detail
        case apply_for_work_force
        case apply_job
        case notifications
        case myjobs
        case rate
        var caseValue: String {
            switch self {
            case .customersignup:                    return "/customersignup"
            case .userLogin:                       return "/login"
            case .forgotpassword:                  return "/forgotpassword"
            case .carWashlist:                     return "/carwashes"
            case .sites:                           return "/sites"
            case .chemicals:                       return "/chemicals"
            case .chemicalpumpspeed:               return "/chemicalpumpspeed"
            case .statistics:                      return "/statistics"
            case .profile:                         return "/fetch_profile_data"
            case .lat:                             return "/near_job"
            case .editprofile:                     return "/edit_profile"
            case .near_job_detail:                 return"/near_job_detail"
            case .apply_for_work_force:            return "/apply_for_work_force"
            case .apply_job:                       return "/apply_job"
            case .notifications:                   return "/notifications"
            case .myjobs:                          return "/myjob"
            case .rate:                            return "/review_list"
            }
        }
    }
}
struct WebServiceError: Error {
    var message: String?
}
public struct WebServicesManager {
    static let sharedInstance = WebServicesManager()
    private init() {}
    
    static let baseURL: String = "https://mcflydelivery.com/mcflybackend/index.php/api"
    //"https://truckerwall.com/webservices"
    //http://18.191.149.160/webservices
    //https://18.191.149.160/webservices/
    //https://truckerwall.com/webservices/
    static var authorizationHeader: String?
    
    typealias SuccessClosure = (_ response: Any) -> Void
    //    public typealias FailureClosure = (_ error: Error?, _ statusCode: Int?) -> Void
    typealias FailureClosure = (_ error: WebServiceError?, _ statusCode: Int?) -> Void
    
    
    func makeRequest(_ urlString: String, method: HTTPMethod, parameters: Parameters?, success: @escaping SuccessClosure, failure: @escaping FailureClosure) {
        
        //        var headers: HTTPHeaders = ["Content-Type": "application/json"]
        //
        //        if let authorizationHeader = WebServicesManager.authorizationHeader
        //        {
        //            Mygrobal.header = authorizationHeader
        //            headers["Authorization"] = authorizationHeader
        //        }
        
        let url = WebServicesManager.baseURL + urlString
        var parameterEncoding: ParameterEncoding = JSONEncoding.default
        
        if method == .post {
            parameterEncoding = URLEncoding.default
        }
        
        let request = Alamofire.request(url, method: method, parameters: parameters, encoding: parameterEncoding, headers: nil)
        
        request.validate(statusCode: 200..<600)
            .validate(contentType: ["application/json"])
            .responseJSON{ (response) -> Void in
                guard response.result.isSuccess else {
                    print("error on request \(response.result.error!)")
                    //                    failure(response.result.error, response.response?.statusCode)
                    return
                }
                
                guard let value = response.result.value else {
                    print("error on request bad result format")
                    //                    failure(response.result.error, response.response?.statusCode)
                    return
                }
                
                success(value)
                debugPrint(response)
                print("Response JSON: \(value)")
            }
            .responseString { (response) in
                print("STRING RESPONSE")
                debugPrint(response)
        }
    }
    
    
    fileprivate func makeRequest1(_ urlString: String, method: HTTPMethod, parameters: Parameters?, success: @escaping SuccessClosure, failure: @escaping FailureClosure) {
        
        let headers =  ["SECRET" : "fbdb1d1b18aa6c08324b7d64b71fb76370690e1d","USERID":UserDefaults.standard.value(forKey: "userid") as! String,"Content-Type":"application/x-www-form-urlencoded"]
        
        // let url = WebServicesManager.baseURL + urlString
        let url = "https://truckerwall.com/webservices" + urlString
        var parameterEncoding: ParameterEncoding = JSONEncoding.default
        
        if method == .get || method == .delete {
            parameterEncoding = URLEncoding.default
        }
        
        //        print(Mygrobal.header)
        
        let request = Alamofire.request(url, method: method, parameters: parameters, encoding: parameterEncoding, headers: headers)
        
        request.validate(statusCode: 200..<600)
            .validate(contentType: ["application/json"])
            .responseJSON{ (response) -> Void in
                guard response.result.isSuccess else {
                    print("error on request \(response.result.error!)")
                    //                    failure(response.result.error, response.response?.statusCode)
                    return
                }
                
                guard let value = response.result.value else {
                    print("error on request bad result format")
                    //                    failure(response.result.error, response.response?.statusCode)
                    return
                }
                
                success(value)
                debugPrint(response)
                print("Response JSON: \(value)")
            }
            .responseString { (response) in
                print("STRING RESPONSE")
                debugPrint(response)
        }
    }
    
    func httpRequest(methodName : String,params : NSDictionary , completion: @escaping (_ response:Any?,_ error:String?)->()) {
        print("Http Request params \(params)")
        
        print(WebServicesManager.baseURL)
        
        Alamofire.request(WebServicesManager.baseURL+methodName, method:.post, parameters: params as? Parameters, encoding: URLEncoding.default, headers: nil).responseJSON { response in
            switch(response.result) {
                
            // api is hit successfully
            case .success(_):
                
                // if error in data parsed from api response
                // check status
                guard let data : NSDictionary = response.result.value as! NSDictionary? else {
                    
                    // if error in getting data from response
                    print("Api Hit Successfully, Parsing Data Error")
                    completion(nil,"Api Hit Successfully, Parsing Data Error")
                    return
                }
                // api hit successfully and parsing is good
                print("Api Hit Successfully, Response \(data)")
                
                
                // check if status is 0 or 1
                
                guard let status =  Int((data.value(forKey: "status") as! String)), status == 1
                    else
                {
                    
                    //                     if status is 0
                    //                      print("Status \(status)")
                    //                     print("Message \(data.value(forKey: "message"))")
                    
                    
                    completion(nil,data.value(forKey: "message") as! String?)
                    //
                    //                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                    //                        self.stopAnimating() }
                    
                    return
                }
                // if status is 1, pass the dictionary back to caller
                completion(data,nil)
                
                break
                
            //  api hit failure
            case .failure(_):
                print("Api Hit Failure\(response.result.error!.localizedDescription)")
                // error is passed as string , response is kept nil
                
                completion(nil,"Api hit failure, please try again")
                
                break
                
            }
        }
        
    }
    //MARK: Image Uploading
    
//    fileprivate  func httpRequestWithImage(methodName : String,image : UIImage,imageName : String? = nil,resolution : Float? = nil, params : NSDictionary, completion: @escaping (_ response:Any?,_ error:String?)->()) {
//
//
//        var imageToUploadName = "image"
//        if(imageName != nil) {
//            imageToUploadName = imageName!
//        }
//
//        var imageResolution : Float = 0.2
//        if(resolution != nil) {
//
//            imageResolution = resolution!
//
//        }
//
//        Alamofire.upload(multipartFormData: {
//
//            (multipartFormData) in
//
//            multipartFormData.append(UIImage.jpegData()(image, CGFloat(imageResolution))!, withName: imageToUploadName, fileName: "file.jpeg", mimeType: "image/jpeg")
//
//
//            for (key, value) in params {
//                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String)
//            }
//        },
//                         to:WebServicesManager.baseURL+methodName) {
//
//                            (result) in
//
//                            switch result {
//
//                            // api hit success
//                            case .success(let upload, _, _):
//
//                                upload.uploadProgress(closure: { (progress) in
//                                    //Print progress
//                                    print("Progress \(progress.description)")
//                                })
//
//                                upload.responseJSON { response in
//                                    //print response.result
//                                    guard let data : NSDictionary = response.result.value as! NSDictionary? else {
//
//                                        // if error in getting data from response
//                                        print("Api Hit Successfully, Parsing Data Error")
//                                        completion(nil,nil)
//                                        return
//                                    }
//                                    // api hit successfully and parsing is good
//                                    print("Api Hit Successfully, Response \(data)")
//
//                                    // check if status is 0 or 1
//
//                                    guard let status =  Int((data.value(forKey: "status") as! String)), status == 1 else {
//
//                                        // if status is 0
//                                        //  print("Status \(status)")
//                                        // print("Message \(data.value(forKey: "message"))")
//                                        completion(nil,data.value(forKey: "message") as! String?)
//                                        return
//                                    }
//                                    // if status is 1, pass the dictionary back to caller
//                                    completion(data.value(forKey: "result"),nil)
//                                }
//
//                            case .failure(_):
//
//                                completion(nil,"Api hit failure, please try again")
//                                break
//                                //print encodingError.description
//                            }
//        }
//    }
    
    
    //MARK: THIS IS USED FOR NSURL SESSION METHODS>>>>
    func webservicesPostRequestNEW(baseString: String, parameters: String?,header:[String:String],success:@escaping ( _ response: Any)-> Void, failure:@escaping ( _ error: Error) -> Void){
        
        let sessionConfiguration = URLSessionConfiguration.default
        
        let session = URLSession(configuration: sessionConfiguration, delegate: nil, delegateQueue: OperationQueue.main)
        let url = WebServicesManager.baseURL + baseString
        var request = URLRequest(url: URL(string: url)!)
        request.allHTTPHeaderFields = header
        request.httpMethod = "POST"
        request.httpBody = parameters?.data(using: .utf8)
        
        let dataTask = session.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            if error == nil{
                if let responseData = data{
                    do {
                        // let json = try JSONSerialization.jsonObject(with: responseData, options: []) as! [String: AnyObject]
                        let json = try JSONSerialization.jsonObject(with: responseData, options: [])
                        success(json)
                    }catch let err{
                        print(err)
                        
                    }
                }
            }else{
                failure(error!)
            }
        }
        dataTask.resume()
    }
    
    func webservicesPostRequestNEW1(baseString: String, parameters: [String:Any], header:[String:String],success:@escaping ( _ response: Any)-> Void, failure:@escaping ( _ error: Error) -> Void){
        
        let sessionConfiguration = URLSessionConfiguration.default
        
        let session = URLSession(configuration: sessionConfiguration, delegate: nil, delegateQueue: OperationQueue.main)
        let url = WebServicesManager.baseURL + baseString
        var request = URLRequest(url: URL(string: url)!)
        request.allHTTPHeaderFields = header
        request.httpMethod = "POST"
        //.// let a = parameters
        //  request.httpBody = parameters
        
        let dataTask = session.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            if error == nil{
                if let responseData = data{
                    do {
                        // let json = try JSONSerialization.jsonObject(with: responseData, options: []) as! [String: AnyObject]
                        let json = try JSONSerialization.jsonObject(with: responseData, options: [])
                        success(json)
                    }catch let err{
                        print(err)
                        
                    }
                }
            }else{
                failure(error!)
            }
        }
        dataTask.resume()
    }
    
    func webservicesPostRequest(baseString: String, parameters: [String:String],success:@escaping (_ response: NSDictionary)-> Void, failure:@escaping (_ error: Error) -> Void){
        
        let headers =
            [
                "content-type": "application/x-www-form-urlencoded",
                
                ]
        let sessionConfiguration = URLSessionConfiguration.default
        
        let session = URLSession(configuration: sessionConfiguration, delegate: nil, delegateQueue: OperationQueue.main)
        
        let jsonData = try? JSONSerialization.data(withJSONObject:parameters)
        
        let url = WebServicesManager.baseURL + baseString
        
        //let url = baseString
        
        print(url)
        print(parameters)
        
        var request = URLRequest(url: URL(string: url)!)
        request.allHTTPHeaderFields = headers
        request.httpMethod = "POST"
        request.httpBody = jsonData
        
        let dataTask = session.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            if error == nil{
                if let responseData = data{
                    do {
                        let json = try JSONSerialization.jsonObject(with: responseData, options: [])
                        success(json as! NSDictionary)
                    }catch let err{
                        print(err)
                        failure(err)
                        
                    }
                }
            }else{
                failure(error!)
            }
        }
        dataTask.resume()
    }
    
    func webServiceGetRequest(baseString: String, parameters: String?, success:@escaping (_ response: Any) ->Void, failure:@escaping (_ error: Error) -> Void){
        
        let sessionConfiguration = URLSessionConfiguration.default
        
        let session = URLSession(configuration: sessionConfiguration, delegate: nil, delegateQueue: OperationQueue.main)
        let url = URL(string: baseString)
        
        
        
        
        let dataTask = session.dataTask(with: url!, completionHandler: { (data: Data?, response: URLResponse?,error: Error?) in
            if error == nil{
                if let responseData = data{
                    do {
                        let json = try JSONSerialization.jsonObject(with: responseData, options: [])
                        success(json)
                    }catch let err{
                        
                        print(err)
                    }
                }
            }else{
                failure(error!)
            }
        })
        dataTask.resume()
    }
    
    
    //  MARK: - User Related api's methods
    static func userRegisterApi(parameters: [String:Any], success: @escaping SuccessClosure, failure: @escaping FailureClosure)
    {
        let wsm = WebServicesManager.sharedInstance
        wsm.makeRequest1(APIEndpoint.userCase.customersignup.caseValue, method: .post, parameters: parameters,
                         success: { (responseValue) in
                            success(responseValue)
        }, failure: { (error, statusCode) in
            failure(error, statusCode)
        })
    }
    
    
    //  MARK: - User Related api's methods
    static func latApi(parameters: [String:String], success: @escaping SuccessClosure, failure: @escaping FailureClosure)
    {
        let wsm = WebServicesManager.sharedInstance
        wsm.makeRequest1(APIEndpoint.userCase.lat.caseValue, method: .post, parameters: parameters,
                         success: { (responseValue) in
                            success(responseValue)
        }, failure: { (error, statusCode) in
            failure(error, statusCode)
        })
    }
    
    //  MARK: - User Related api's methods
    static func myjobs(parameters: [String:String], success: @escaping SuccessClosure, failure: @escaping FailureClosure)
    {
        let wsm = WebServicesManager.sharedInstance
        wsm.makeRequest1(APIEndpoint.userCase.myjobs.caseValue, method: .post, parameters: parameters,
                         success: { (responseValue) in
                            success(responseValue)
        }, failure: { (error, statusCode) in
            failure(error, statusCode)
        })
    }
    
    
    //  MARK: - User Related api's methods
    
    //MARK:- Update_Profile_Api
    //    static func edit_profile(vc:UIViewController,imagedata:UIImage? = nil,params:NSDictionary,completion: @escaping (_ isCompleted : NSDictionary)->(), failure: @escaping FailureClosure) {
    //
    //        if imagedata == nil {
    //            let wsm = WebServicesManager.sharedInstance
    //            wsm.httpRequest(methodName: APIEndpoint.userCase.edit_profile.caseValue, params:params as NSDictionary ) {
    //                response,error in
    //
    //                // if no error
    //                if(response != nil) {
    //                    let item = response as! NSDictionary
    //                    // todo with response
    //                    print("TODO with response \(item)")
    //
    //
    //                    completion (item)
    //                }
    //                    // error
    //                else {
    //                    print("Error in image")
    //                }
    //            }
    //        }
    //        else {
    //            WebServicesManager.sharedInstance.httpRequestWithImage(methodName :APIEndpoint.userCase.edit_profile.caseValue ,image : imagedata!,imageName : "image",resolution : 0.2, params : params) {
    //                response,error in
    //
    //                // if no error
    //                if(error == nil) {
    //                    let item = response as! NSDictionary
    //                    // todo with response
    //                    print("TODO with response \(item)")
    //
    //                    completion (item)
    //                }
    //                    // error
    //                else {
    //                    print("Error in image")
    //                }
    //            }
    //        }
    //    }
    
    
}
