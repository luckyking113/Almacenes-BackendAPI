//
//  CartDeleteDialog.swift
//  McFly
//
//  Created by LiuYan on 6/16/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
class CartDeleteDialog: UIView, ModalBottom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    var viewcontroller = UIViewController()
    var tableview : UITableView!
    var index : Int = 0
    var countfield: UITextField!
    
    convenience init(title:String,vc: UIViewController, tableview : UITableView,index : Int){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title,vc: vc, tableview: tableview,index: index)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String,vc: UIViewController, tableview : UITableView,index : Int){
        dialogView.clipsToBounds = true
        self.tableview = tableview
        self.viewcontroller = vc
        self.index = index
        backgroundView.frame = frame
        let height = backgroundView.frame.height
        
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width - 64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 15, width: dialogViewWidth-16, height: 20))
        titleLabel.text = title + " " + "se ha removido"
        titleLabel.textColor = UIColor.black
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.systemFont(ofSize: 13.0)
        dialogView.addSubview(titleLabel)
        
        
        //        let imageView = UIImageView(frame: CGRect(x: 20, y: 8, width: dialogViewWidth, height: 100))
        //        imageView.image = UIImage.gif(asset: "progressgif")
        //        dialogView.addSubview(imageView)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        let btn_width = (dialogViewWidth-16) / 2.5
        let notyet_btn = UIButton(frame: CGRect(x: 28, y: 50, width: btn_width, height:30))
        notyet_btn.layer.backgroundColor = blueColor.cgColor
        notyet_btn.layer.cornerRadius = 15
        notyet_btn.layer.masksToBounds = true
        notyet_btn.setTitleColor(UIColor.white, for: .normal)
        notyet_btn.setTitle("Ok", for: .normal)
        notyet_btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        notyet_btn.addTarget(self, action: #selector(closeDialog), for: .touchUpInside)
        dialogView.addSubview(notyet_btn)
        let x = dialogViewWidth - 28 - btn_width
        let signup_btn = UIButton(frame: CGRect(x: x, y: 50, width: btn_width, height: 30))
        signup_btn.layer.backgroundColor = blueColor.cgColor
        signup_btn.layer.cornerRadius = 15
        signup_btn.layer.masksToBounds = true
        signup_btn.setTitleColor(UIColor.white, for: .normal)
        signup_btn.setTitle("Undo 😱", for: .normal)
        signup_btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        signup_btn.addTarget(self, action: #selector(GotoSignUp), for: .touchUpInside)
        dialogView.addSubview(signup_btn)
        
        
        
        let dialogViewHeight =  CGFloat(100)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height )
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
        
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    @objc func closeDialog(sender : UIButton!){
        dismiss(animated: true)
        if (AppData.shared.delete_index != -1){
            let deletename = AppData.shared.delete_data["productname"] as! String
            let cartcount = UserDefaults.standard.integer(forKey: deletename) as! Int ?? 0
            UserDefaults.standard.set(0, forKey: deletename)
            AppData.shared.cartBadge_number = AppData.shared.cartBadge_number - cartcount
            let saveData :[String : Any] = ["cartproduct_array" : AppData.shared.cartProductData]
            
            UserDefaults.standard.set(saveData, forKey: "cart_dataarray")
            UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
            self.viewcontroller.viewWillAppear(true)
            self.tableview.reloadData()
            AppData.shared.delete_index = -1
        }else {
            let deleteData = AppData.shared.cartProductData[self.index] as! NSDictionary
            let deletename = deleteData["productname"] as! String
            let cartcount = UserDefaults.standard.integer(forKey: deletename) as! Int ?? 0
            AppData.shared.cartBadge_number = AppData.shared.cartBadge_number - cartcount
            UserDefaults.standard.set(0, forKey: deletename)
            AppData.shared.cartProductData.removeObject(at: self.index)
            let saveData :[String : Any] = ["cartproduct_array" : AppData.shared.cartProductData]
            
            UserDefaults.standard.set(saveData, forKey: "cart_dataarray")
            UserDefaults.standard.set(AppData.shared.cartBadge_number, forKey: "cartCount")
            self.viewcontroller.viewWillAppear(true)
            self.tableview.reloadData()
        }
       
    }
    @objc func GotoSignUp(sender : UIButton!){
        dismiss(animated: true)
        if (AppData.shared.delete_index != -1){
            AppData.shared.cartProductData.insert(AppData.shared.delete_data, at: AppData.shared.delete_index)
            self.viewcontroller.viewWillAppear(true)
            self.tableview.reloadData()
            AppData.shared.delete_index = -1
        }
       
    }
    
}
