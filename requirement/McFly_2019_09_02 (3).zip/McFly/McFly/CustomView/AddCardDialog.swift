//
//  AddCardDialog.swift
//  McFly
//
//  Created by LiuYan on 6/6/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import Stripe
import Alamofire
class AddCardDialog: UIView, ModalCustom,STPPaymentCardTextFieldDelegate {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    var viewcontroller = UIViewController()
    var  stpcardField = STPPaymentCardTextField()
    var saveCardBtn = UIButton()
    convenience init(title:String, viewcontroller : UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title, viewcontroller: viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
        titleLabel.text = "Registrar Tarjeta"
        titleLabel.textAlignment = .center
        titleLabel.textColor = UIColor.black
        
        dialogView.addSubview(titleLabel)
        stpcardField = STPPaymentCardTextField(frame: CGRect(x: 8, y: 53, width: dialogViewWidth - 16, height: 35))
        dialogView.addSubview(stpcardField)
       
        saveCardBtn = UIButton(frame: CGRect(x: 28, y: 123, width: dialogViewWidth-56, height: 30))
        saveCardBtn.titleLabel?.textColor = UIColor.white
        saveCardBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        saveCardBtn.backgroundColor = blueColor
        saveCardBtn.setTitle("Guardar Tarjeta", for: .normal)
        saveCardBtn.addTarget(self, action: #selector(SaveCard), for: .touchUpInside)
        // btn.tag = 1
        dialogView.addSubview(saveCardBtn)
       
        
        
        let dialogViewHeight =  CGFloat(180)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
        
    }
    @objc func SaveCard(sender: UIButton!) {
        self.getToken()
    }
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    func getToken(){
        let cardnumber = self.stpcardField.cardNumber as! String
        if (cardnumber.isEmpty){
            AppData.shared.displayToastMessage("Please enter card number")
            return
        }
//        let expmonth = self.stpcardField.expirationMonth as! String
//        if (expmonth.isEmpty){
//            AppData.shared.displayToastMessage("Please enter Expiration Month")
//            return
//        }
//        let expyear = self.stpcardField.expirationYear as! String
//        if (expyear.isEmpty){
//            AppData.shared.displayToastMessage("Please enter Expiration Year")
//            return
//        }
        let cvc = self.stpcardField.cvc as! String
        if (cvc.isEmpty){
            AppData.shared.displayToastMessage("Please enter CVC")
            return
        }
        
       
        let cardParams = STPCardParams()
        cardParams.number = self.stpcardField.cardNumber
        cardParams.expMonth = (self.stpcardField.expirationMonth)
        cardParams.expYear = (self.stpcardField.expirationYear)
        cardParams.cvc = self.stpcardField.cvc
        STPAPIClient.shared().createToken(withCard: cardParams) { (token: STPToken?, error: Error?) in
            guard let token = token, error == nil else {
                // Present error to user...
                AppData.shared.displayToastMessage("Tarjeta falsa")
                return
            }
            let tokenstr: String = token.stripeID as! String
            print(tokenstr)
            if let customercardnumber = AppData.shared.profile_customerDetailData["customer_cardnumber"] as? NSNull {
                self.createcustomer(token: tokenstr)
            }else {
                if let customercardnumber = AppData.shared.profile_customerDetailData["customer_cardnumber"] as? String {
                    self.AddCardtoCustomer(tokenstring: tokenstr)
                }
            }
        }
    }
    func createcustomer(token: String){
        let url = URL(string: AppConstants.baseUrl + "createCustomer")!
        let userEmail = AppData.shared.profile_customerDetailData["email"] as! String
        let jsondata:[String : Any] = ["user_email": userEmail, "stripe_token" : token]
        Alamofire.request(url, method: .post,parameters : jsondata, encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                
                if (message == "success"){
                    print("success")
                    AppData.shared.cardDetailData = NSMutableArray()
                    if (jsonString.contains("data")){
                        let cardjsondata = responseData["data"] as! NSDictionary
                        let allkeys = cardjsondata.allKeys as! [String]
                        if (allkeys.contains("customer")){
                            let customerdata = cardjsondata["customer"] as! NSDictionary
                            AppData.shared.default_cardsource = customerdata["default_source"] as! String
                            let sourcedata = customerdata["sources"] as! NSDictionary
                            AppData.shared.cardDetailData = sourcedata["data"] as! NSMutableArray
                        }else{
                            AppData.shared.default_cardsource = cardjsondata["id"] as! String
                            let sourcedata = cardjsondata["sources"] as! NSDictionary
                            AppData.shared.cardDetailData = sourcedata["data"] as! NSMutableArray
                        }
                        self.SignIn()
                        self.dismiss(animated: true)
                        self.viewcontroller.viewWillAppear(true)
                        
                    }
                }
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    func AddCardtoCustomer(tokenstring : String) {
        let url = URL(string: AppConstants.baseUrl + "addCardToCustomer")!
        let userEmail = AppData.shared.profile_customerDetailData["customer_cardnumber"] as! String
        let jsondata:[String : Any] = ["user_stripe_customer": userEmail, "stripe_token" : tokenstring]
        Alamofire.request(url, method: .post,parameters : jsondata, encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                
                if (message == "success"){
                    print("success")
                    AppData.shared.cardDetailData = NSMutableArray()
                    if (jsonString.contains("data")){
                        let cardjsondata = responseData["data"] as! NSDictionary
                        let customerdata = cardjsondata["customer"] as! NSDictionary
                        if let default_cardsource = customerdata["default_source"] as? NSNull {
                            
                        }else{
                            AppData.shared.default_cardsource = customerdata["default_source"] as! String
                        }
                     
                        let sourcedata = customerdata["sources"] as! NSDictionary
                        AppData.shared.cardDetailData = sourcedata["data"] as! NSMutableArray
                        self.dismiss(animated: true)
                        self.viewcontroller.viewWillAppear(true)
                    }
                }
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    func SignIn(){
        let url = URL(string: AppConstants.baseUrl + "customerlogin")!
        let jsondata: [String: Any] = ["verified_type": AppData.shared.profile_accountType,"verified_value" : AppData.shared.profile_verficationvalue ,"fcmToken" : AppData.shared.profile_fcmtoken]
        print(jsondata)
        Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                //AppData.shared.hideLoadingIndicator()
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                print(responseData)
                let message  = responseData["message"] as! String
                if (message == "success"){
                    
                    UserDefaults.standard.set(AppData.shared.profile_accountType, forKey: "verified_type")
                    UserDefaults.standard.set(AppData.shared.profile_verficationvalue, forKey: "verified_value")
                    AppData.shared.profile_loginstatus = true
                    let customer_detail = responseData["customerdetail"] as! NSMutableArray
                    
                    AppData.shared.profile_customerDetailData = customer_detail[0] as! NSDictionary
                    AppData.shared.profile_customerid = AppData.shared.profile_customerDetailData["id"] as! String
                    AppData.shared.profile_imageurl = AppData.shared.profile_customerDetailData["image"] as! String
                    let discountcodes = responseData["discountcodes"] as! NSMutableArray
                    AppData.shared.profile_discountArray = discountcodes
                    let shipppingaddress = responseData["shippingaddresses"] as! NSMutableArray
                    AppData.shared.profile_shippingAddress = shipppingaddress
                    if (AppData.shared.default_maindeliveraddress == ""){
                        if (AppData.shared.profile_shippingAddress.count > 0){
                         
                        }
                    }
                    if (jsonString.contains("carddetail")){
                        let carddetailData = responseData["carddetail"] as! NSDictionary
                        AppData.shared.profile_carddetailData = carddetailData
                        
                        let source = carddetailData["sources"] as! NSDictionary
                        let carddetail_datas = source["data"] as! NSMutableArray
                        if (carddetail_datas.count > 0){
                            let default_sourcecard = carddetailData["default_source"] as! String  ?? ""
                            AppData.shared.default_cardsource = default_sourcecard
                        }
                        AppData.shared.cardDetailData = carddetail_datas
                        
                    }
                }
                
                break
            case .failure(let error):
                
                print(error)
            }
        }
        
    }
}
