//
//  LoadingDialog.swift
//  McFly
//
//  Created by LiuYan on 6/1/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import SwiftGifOrigin
import Alamofire
class LoadingDialog: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    var viewcontroller = UIViewController()
    
    convenience init(title:String, viewcontroller : UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title, viewcontroller: viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-200
        
//        let titleLabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
//
//        dialogView.addSubview(titleLabel)
        let imageView = UIImageView(frame: CGRect(x: 20, y: 8, width: dialogViewWidth, height: 160))
        imageView.image = UIImage.gif(asset: "progressgif")
        dialogView.addSubview(imageView)
        
        let dialogViewHeight =  CGFloat(160)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-150, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.clear
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
        if (AppData.shared.profile_loginstatus) {
            if (AppData.shared.set_flag == 1){
                if (AppData.shared.default_maindeliverid != ""){
                    print(AppData.shared.customer_zipcode)
                     print(AppData.shared.profile_customerid)
                     self.confimrZipCode(zipcode: AppData.shared.customer_zipcode)
                }else{
                    //AppData.shared.wrong_warehouse = 1
                    //AppData.shared.profile_customerid = "1"
//                    AppData.shared.warehouse_zipcode = "12345"
                    self.confimrZipCode(zipcode: AppData.shared.customer_zipcode)
                    print(AppData.shared.customer_zipcode)
                    print(AppData.shared.profile_customerid)
                }
               
            }else {
                AppData.shared.wrong_warehouse = 0
               // AppData.shared.profile_customerid = "1"
                AppData.shared.warehouse_zipcode = "12345"
                self.getAllProduct(warehouse_id: "2")
            }
        }else {
            if (AppData.shared.wrong_warehouse == 0) {
                AppData.shared.wrong_warehouse = 0
                AppData.shared.profile_customerid = "1"
                AppData.shared.warehouse_zipcode = "12345"
                self.getAllProduct(warehouse_id: "2")
            }else {
                AppData.shared.wrong_warehouse = 1
                AppData.shared.profile_customerid = "1"
                //AppData.shared.warehouse_zipcode = "12345"
                self.getAllProduct(warehouse_id: "2")
            }
            
        }
       
        
    }
    
    @objc func didTappedOnBackgroundView(){
       // dismiss(animated: true)
    }
    func confimrZipCode(zipcode : String){
        if (AppData.shared.profile_loginstatus){
            
        }else {
            AppData.shared.profile_customerid = "1"
        }
        let url = URL(string: AppConstants.baseUrl + "confirmzipcode")!
        let jsondata: [String: Any] = ["zipecode": AppData.shared.customer_zipcode,"customerid" : AppData.shared.profile_customerid ]
        //print(jsondata)
        Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                //print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                print("warehousedata")
                print(responseData)
                let message = responseData["message"] as! String
                if (message == "success"){
                    if (jsonString.contains("wrong warehouse")){
                        AppData.shared.zipdialog_flag = 1
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                        self.viewcontroller.present(verificationController, animated: true, completion: nil)
                        AppData.shared.displayToastMessage("Wrong warehouse")
                        AppData.shared.wrong_warehouse = 0
                        AppData.shared.profile_customerid = "1"
                        AppData.shared.warehouse_zipcode = "12345"
                        self.confimrZipCode(zipcode: "12345")
                    }
                    else
                    {
                        AppData.shared.wrong_warehouse =  1
                        let warehouseStatus = responseData["warehouseworkingtimestatus"] as! Int
                        AppData.shared.warehouseworkingstatus = Int(warehouseStatus) as! Int
                        let warehouseArray = responseData["warehouse"] as! NSMutableArray
                        AppData.shared.ware_houseData = warehouseArray[0] as! NSDictionary
                        let customerid  = AppData.shared.profile_customerDetailData["id"] as! String
                        if (customerid == AppData.shared.profile_customerid) {
                           let  orderdata = responseData["orders"] as! NSMutableArray
                            AppData.shared.orderHistory_Data = responseData["orders"] as! NSMutableArray
                            if (orderdata.count > 0){
                                for index in 0..<orderdata.count {
                                    let eachorder = orderdata[index] as! NSDictionary
                                    let status = eachorder["status"] as! String
                                    if (status == "7"){
                                       
                                    }else {
                                        AppData.shared.order_Data.add(eachorder)
                                    }
                                    
                                    
                                }
                            }
                            
                            AppData.shared.wrong_warehouse =  1
                        }else {
                            AppData.shared.order_Data = NSMutableArray()
                            AppData.shared.wrong_warehouse =  0
                        }
                      //  print(AppData.shared.order_Data)
                        let ware_houseid = AppData.shared.ware_houseData["id"] as! String
                        print("ware_houseid")
                        print(ware_houseid)
                        self.getAllProduct(warehouse_id: ware_houseid)
                    }

                }
                break
            case .failure(let error):

                print(error)
            }
        }
    }
    func getAllProduct(warehouse_id : String){
        let url = URL(string: AppConstants.baseUrl + "getallproducts/" + warehouse_id + "/" + AppData.shared.profile_customerid + "/0")!
        
        Alamofire.request(url, method: .get ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                //print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
              //  print(responseData)
                let message = responseData["message"] as! String
                if (message == "success"){
                    AppData.shared.product_Data = responseData["products"] as! NSMutableArray
                  //  print(AppData.shared.product_Data)//
                    
                    self.sortProductData()
                }
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    func sortProductData(){
        AppData.shared.categroy_Data = NSMutableArray()
        let count  = AppData.shared.product_Data.count as! Int
        if (count > 0 ){
            let product_data = AppData.shared.product_Data[0] as! NSDictionary
            var category_name : String = product_data["cat_name"] as! String
            var category_image : String = product_data["cat_image"] as! String
            var category_imageheight: String = product_data["cat_imageheight"] as! String
            var subcat_name: String = product_data["subcat_name"] as! String
            
            var subcat_arraycontainer = NSMutableArray()
            var subcat_namecontainer  = NSMutableArray()
            var product_container = NSMutableArray()
            // var subproduct_data :[String: Any] = ["products" : product_container]
            subcat_namecontainer.add(subcat_name)
            for index in 0..<count {
                
                let product_one = AppData.shared.product_Data[index] as! NSDictionary
                let productcountstr = product_one["quantity"] as! String
                let productcount = Int(productcountstr) as! Int
               
                    let pone_catname = product_one["cat_name"] as! String
                    let pone_catimage = product_one["cat_image"] as! String
                    let pone_catheight = product_one["cat_imageheight"] as! String
                    let pone_subcatname = product_one["subcat_name"] as! String
                    
                    
                    if ( pone_catname == category_name) {
                        if ( pone_subcatname == subcat_name ){
                            if (index < count - 1) {
                                if (productcount > 0){
                                    product_container.add(product_one)
                                }
                                
                                //  subproduct_data["products"] = product_container
                            }else {
                                let  sub_name = subcat_namecontainer[subcat_namecontainer.count - 1] as! String
                                let  sub_data : [String : Any] = [ "name" : sub_name,"products" : product_container]
                                
                                subcat_arraycontainer.add(sub_data)
                                
                                
                                let cat_data : [String : Any] = ["cat_name" : category_name, "cat_image" : category_image ,"cat_imageheight" : category_imageheight, "subcategory" : subcat_arraycontainer ]
                                AppData.shared.categroy_Data.add(cat_data)
                                print("height")
                                //print(category_imageheight)
                            }
                        }else{
                            if (index < count - 1){
                                let  sub_name = subcat_namecontainer[subcat_namecontainer.count - 1] as! String
                                let  sub_data : [String : Any] = [ "name" : sub_name,"products" : product_container]
                                
                                subcat_arraycontainer.add(sub_data)
                                
                                product_container = NSMutableArray()
                                
                                subcat_namecontainer.add(pone_subcatname)
                                
                                subcat_name = pone_subcatname
                                if (productcount > 0){
                                    product_container.add(product_one)
                                }
                                
                            }else {
                                let  sub_name = subcat_namecontainer[subcat_namecontainer.count - 1] as! String
                                let  sub_data : [String : Any] = [ "name" : sub_name,"products" : product_container]
                                
                                subcat_arraycontainer.add(sub_data)
                                
                                
                                let cat_data : [String : Any] = ["cat_name" : category_name, "cat_image" : category_image ,"cat_imageheight" : category_imageheight, "subcategory" : subcat_arraycontainer ]
                                AppData.shared.categroy_Data.add(cat_data)
                            }
                        }
                        
                    }else {
                        let  sub_name = subcat_namecontainer[subcat_namecontainer.count - 1] as! String
                        let  sub_data : [String : Any] = [ "name" : sub_name,"products" : product_container]
                        
                        subcat_arraycontainer.add(sub_data)
                        
                        
                        let cat_data : [String : Any] = ["cat_name" : category_name, "cat_image" : category_image ,"cat_imageheight" : category_imageheight, "subcategory" : subcat_arraycontainer ]
                        AppData.shared.categroy_Data.add(cat_data)
                        
                        product_container = NSMutableArray()
                        subcat_arraycontainer = NSMutableArray()
                        subcat_namecontainer = NSMutableArray()
                        
                        subcat_name = pone_subcatname
                        category_name = pone_catname
                        category_image = pone_catimage
                        category_imageheight = pone_catheight
                        if (productcount > 0){
                             product_container.add(product_one)
                        }
                        subcat_namecontainer.add(pone_subcatname)
                    }
                    if (index == count - 1){
                        //print(AppData.shared.categroy_Data)
                    }
                
                
            }
            print(AppData.shared.categroy_Data)
           // dismiss(animated: true)
            AppData.shared.zipdialog_flag = 1
           // viewcontroller.viewWillAppear(true)
            //let dialog = LoadingDataDialog(title: "", viewcontroller: self.viewcontroller)
           // dialog.show(animated: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                //verificationController.selectedIndex = 0
                self.viewcontroller.present(verificationController, animated: true, completion: nil)
            }
            
            //dialog.dismiss(animated: true)
            //
        }else {
            // dismiss(animated: true)
            AppData.shared.zipdialog_flag = 1
           // let dialog = LoadingDataDialog(title: "", viewcontroller: self.viewcontroller)
           // dialog.show(animated: true)
             //viewcontroller.viewWillAppear(true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                //verificationController.selectedIndex = 0
                self.viewcontroller.present(verificationController, animated: true, completion: nil)
            }
            //dialog.dismiss(animated: true)
            
            
            //
        }
    }
}
