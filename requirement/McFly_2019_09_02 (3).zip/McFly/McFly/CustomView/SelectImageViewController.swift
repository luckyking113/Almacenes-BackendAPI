//
//  SelectImageViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit

class SelectImageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
  
   
}
