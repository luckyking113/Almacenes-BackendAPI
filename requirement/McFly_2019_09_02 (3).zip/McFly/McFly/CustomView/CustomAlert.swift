//
//  CustomAlert.swift
//  McFly
//
//  Created by LiuYan on 6/1/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
class CustomAlert: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    
    convenience init(title:String){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String){
        dialogView.clipsToBounds = true
        
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.clear
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-150
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
        titleLabel.text = title
        titleLabel.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel.textColor = UIColor.white
        titleLabel.textAlignment = .center
        dialogView.addSubview(titleLabel)
        
        let titleLabel1 = UILabel(frame: CGRect(x: 8, y: 35, width: dialogViewWidth-16, height: 25))
        titleLabel1.text = "Aún no hay nadie en almacén"
        titleLabel1.textColor = UIColor.white
        titleLabel1.font = UIFont.boldSystemFont(ofSize: 13.0)
        titleLabel1.textAlignment = .center
        dialogView.addSubview(titleLabel1)
        
        
        let titleLabel3 = UILabel(frame: CGRect(x: 8, y: 65, width: dialogViewWidth-16, height: 25))
        titleLabel3.text = "Nuestro horario es de:"
        titleLabel3.font = UIFont.boldSystemFont(ofSize: 13.0)
        titleLabel3.textColor = UIColor.white
        titleLabel3.textAlignment = .center
        dialogView.addSubview(titleLabel3)
       //Working times
        let monday_starttime = AppData.shared.ware_houseData["mon_working_starttime"] as! String ?? nil
        let monday_endtime = AppData.shared.ware_houseData["mon_working_endtime"] as! String ?? nil
        if (monday_starttime != nil && monday_starttime?.isEmpty != true && monday_starttime != "Non" && monday_endtime != nil && monday_endtime?.isEmpty != true && monday_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel4 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel4.text = "Lunes - " + monday_starttime! + " to " + monday_endtime!
            titleLabel4.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel4.textColor = UIColor.white
            titleLabel4.textAlignment = .center
            dialogView.addSubview(titleLabel4)
            k = k + 1
            print(k)
        }else {
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel12 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel12.text = "Lunes - Cerrado"
            titleLabel12.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel12.textColor = UIColor.white
            titleLabel12.textAlignment = .center
            dialogView.addSubview(titleLabel12)
            k = k + 1
            print(k)
        }
        
        let tue_starttime = AppData.shared.ware_houseData["tue_working_starttime"] as! String ?? nil
        let tue_endtime = AppData.shared.ware_houseData["tue_working_endtime"] as! String ?? nil
        if (tue_starttime != nil && tue_starttime?.isEmpty != true && tue_starttime != "Non" && tue_endtime != nil && tue_endtime?.isEmpty != true && tue_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel5 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel5.text = "Martes - " + tue_starttime! + " to " + tue_endtime!
            titleLabel5.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel5.textColor = UIColor.white
            titleLabel5.textAlignment = .center
            dialogView.addSubview(titleLabel5)
            k = k + 1
            print(k)
        }else {
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel15 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel15.text = "Martes - Cerrado"
            titleLabel15.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel15.textColor = UIColor.white
            titleLabel15.textAlignment = .center
            dialogView.addSubview(titleLabel15)
            k = k + 1
            print(k)
        }
        
        let wed_starttime = AppData.shared.ware_houseData["wed_working_starttime"] as! String ?? nil
        let wed_endtime = AppData.shared.ware_houseData["wed_working_endtime"] as! String ?? nil
        if (wed_starttime != nil && wed_starttime?.isEmpty != true && wed_starttime != "Non" && wed_endtime != nil && wed_endtime?.isEmpty != true && wed_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel6 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel6.text = "Miercoles - " + wed_starttime!  + " to " + wed_endtime!
            titleLabel6.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel6.textColor = UIColor.white
            titleLabel6.textAlignment = .center
            dialogView.addSubview(titleLabel6)
            k = k + 1
            print(k)
        }else{
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel16 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel16.text = "Miercoles - Cerrado"
            titleLabel16.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel16.textColor = UIColor.white
            titleLabel16.textAlignment = .center
            dialogView.addSubview(titleLabel16)
            k = k + 1
            print(k)
        }
        
        let thu_starttime = AppData.shared.ware_houseData["thu_working_starttime"] as! String ?? nil
        let thu_endtime = AppData.shared.ware_houseData["thu_working_endtime"] as! String ?? nil
        if (thu_starttime != nil && thu_starttime?.isEmpty != true && thu_starttime != "Non" && thu_endtime != nil && thu_endtime?.isEmpty != true && thu_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel7 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel7.text = "Jueves - " + thu_starttime! + " to " + thu_endtime!
            titleLabel7.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel7.textColor = UIColor.white
            titleLabel7.textAlignment = .center
            dialogView.addSubview(titleLabel7)
            k = k + 1
            print(k)
        }else{
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel7 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel7.text = "Jueves - Cerrado"
            titleLabel7.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel7.textColor = UIColor.white
            titleLabel7.textAlignment = .center
            dialogView.addSubview(titleLabel7)
            k = k + 1
            print(k)
        }
        
        let fri_starttime = AppData.shared.ware_houseData["fri_working_starttime"] as! String ?? nil
        let fri_endtime = AppData.shared.ware_houseData["fri_working_endtime"] as! String ?? nil
        if (fri_starttime != nil && fri_starttime?.isEmpty != true && fri_starttime != "Non" && fri_endtime != nil && fri_endtime?.isEmpty != true && fri_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel8 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel8.text = "Viernes - " + fri_starttime! + " to " + fri_endtime!
            titleLabel8.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel8.textColor = UIColor.white
            titleLabel8.textAlignment = .center
            dialogView.addSubview(titleLabel8)
            k = k + 1
        }else{
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel18 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel18.text = "Viernes  - Cerrado"
            titleLabel18.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel18.textColor = UIColor.white
            titleLabel18.textAlignment = .center
            dialogView.addSubview(titleLabel18)
            k = k + 1
        }
        
        let sat_starttime = AppData.shared.ware_houseData["sat_working_starttime"] as! String ?? nil
        let sat_endtime = AppData.shared.ware_houseData["sat_working_endtime"] as! String ?? nil
        if (sat_starttime != nil && sat_starttime?.isEmpty != true && sat_starttime != "Non" && sat_endtime != nil && sat_endtime?.isEmpty != true && sat_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel9 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel9.text = "Sabado - " + sat_starttime! + " to " + sat_endtime!
            titleLabel9.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel9.textColor = UIColor.white
            titleLabel9.textAlignment = .center
            dialogView.addSubview(titleLabel9)
            k = k + 1
        }else {
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel9 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel9.text = "Sabado - Cerrado"
            titleLabel9.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel9.textColor = UIColor.white
            titleLabel9.textAlignment = .center
            dialogView.addSubview(titleLabel9)
            k = k + 1
        }
        
        let sun_starttime = AppData.shared.ware_houseData["sun_working_starttime"] as! String ?? nil
        let sun_endtime = AppData.shared.ware_houseData["sun_working_endtime"] as! String ?? nil
        if (sun_starttime != nil && sun_starttime?.isEmpty != true && sun_starttime != "Non" && sun_endtime != nil && sun_endtime?.isEmpty != true && sun_endtime != "Non"  ){
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel10 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel10.text = "Domingo - " + sun_starttime! + " to " + sun_endtime!
            titleLabel10.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel10.textColor = UIColor.white
            titleLabel10.textAlignment = .center
            dialogView.addSubview(titleLabel10)
            k = k + 1
        }else {
            let y_height = CGFloat(95 + k * 15)
            let x = CGFloat(8)
            let height = CGFloat(15)
            let titleLabel10 = UILabel(frame: CGRect(x: x, y: y_height, width: dialogViewWidth - 16, height: height))
            titleLabel10.text = "Domingo - Cerrado"
            titleLabel10.font = UIFont.systemFont(ofSize: 12.0)
            titleLabel10.textColor = UIColor.white
            titleLabel10.textAlignment = .center
            dialogView.addSubview(titleLabel10)
            k = k + 1
        }
        
        
        
        let dialogViewHeight =  CGFloat(95 + k * 15 + 8 )
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-150, height: dialogViewHeight)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        dialogView.backgroundColor = blueColor
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    
}

