//
//  AddNewShippingAddressViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
import moa
import Alamofire
import CoreLocation
class AddNewShippingAddressViewController: UIViewController {

    
    @IBOutlet weak var ship_image: UIImageView!
    @IBOutlet weak var ship_name: UITextField!
    @IBOutlet weak var ship_address: UIButton!
    @IBOutlet weak var ship_zipcode: UITextField!
    
    @IBOutlet weak var save_btn: UIButton!
    var flag_str : String = ""
    var address : String = ""
    var address_Data = NSDictionary()
    var ship_index : Int = 0
    var gotoFlag : String = ""
    
    @IBOutlet weak var house_btn: UIButton!
    
    @IBOutlet weak var work_btn: UIButton!
    
    @IBOutlet weak var lover_btn: UIButton!
    
    @IBOutlet weak var friend_btn: UIButton!
    
    @IBOutlet weak var other_btn: UIButton!
    let house_image = UIImage(named: "house")
    let work_image = UIImage(named: "work")
    let lover_image = UIImage(named: "lover")
    let friend_image = UIImage(named: "friend")
    let other_image = UIImage(named: "other")
    
    let house_imagesel = UIImage(named: "house_sel")
    let work_imagesel = UIImage(named: "work_sel")
    let lover_imagesel = UIImage(named: "lover_sel")
    let friend_imagesel = UIImage(named: "friend_sel")
    let other_imagesel = UIImage(named: "other_sel")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initUI()
        // Do any additional setup after loading the view.
        
    }
    func initUI(){
//        ship_image.layer.cornerRadius = 15
//        ship_image.layer.masksToBounds = true
        save_btn.layer.cornerRadius = 15
        save_btn.layer.masksToBounds = true
        
        
        
        // Do any additional setup after loading the view.
        let btnLeftMenu: UIButton = UIButton()
        btnLeftMenu.setImage(UIImage(named: "back.png"), for: UIControl.State())
        btnLeftMenu.addTarget(self, action: #selector(SubCategoryFirstViewController.onClcikBack), for: UIControl.Event.touchUpInside)
        btnLeftMenu.frame = CGRect(x: 0, y: 0, width: 10/2, height: 5/2)
        let barButton = UIBarButtonItem(customView: btnLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }
    
    @objc func onClcikBack()
    {
        if (self.gotoFlag == "cart"){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "cartVC") as! CartViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else if (self.gotoFlag == "editprofile"){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "editprofileVC") as! EditProfileViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }else if (self.gotoFlag == "signup") {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
            //   self.present(verificationController, animated: true, completion: nil)
            self.navigationController?.pushViewController(verificationController, animated: true)
        }else if (self.gotoFlag == "maindeliver") {
            AppData.shared.select_shipname = ""
            AppData.shared.select_shipzipcode = ""
            AppData.shared.select_shipping_address = ""
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
            vc.goback = AppData.shared.gotopage
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            _ = self.navigationController?.popViewController(animated: true)
        }
       
    }
    override func viewWillAppear(_ animated: Bool) {
        if (flag_str == "edit") {
            address_Data = AppData.shared.profile_shippingAddress[self.ship_index] as! NSDictionary
            let ship_namestr = address_Data["address_name"] as! String
            let ship_addresslocatioin = address_Data["address_location"] as! String
            let ship_imageurl = address_Data["address_imageurl"] as! String
            let ship_zipcode = address_Data["address_zipcode"] as! String
            let lat = self.address_Data["address_lat"] as! String
            let lng = self.address_Data["address_lng"] as! String
            let lat_db = Double(lat) as! Double
            let lng_db = Double(lng) as! Double
            print(lat)
            print(lng)
            if (AppData.shared.select_shipname == ""){
                self.ship_name.text = ship_namestr
            }else {
                self.ship_name.text = AppData.shared.select_shipname
            }
            
            if (AppData.shared.select_shipzipcode == ""){
                self.ship_zipcode.text = ship_zipcode
            }else {
                self.ship_zipcode.text = AppData.shared.select_shipzipcode
            }
            if (AppData.shared.selectship_image != ""){
//                ship_image.image = AppData.shared.ship_image
                self.Selectbutton(imageurl: AppData.shared.selectship_image)
            }else {
//                self.ship_image.moa.url = ship_imageurl
                self.Selectbutton(imageurl: ship_imageurl)
            }
            if (AppData.shared.select_shipping_address_lat == 0.0){
                AppData.shared.select_shipping_address_lat = lat_db
                AppData.shared.select_shippin_address_lon = lng_db
            }
            
            if (AppData.shared.select_shipping_address != ""){
                self.ship_address.setTitle(AppData.shared.select_shipping_address, for: .normal)
            }else {
                self.ship_address.setTitle(ship_addresslocatioin, for: .normal)
                AppData.shared.select_shipping_address = ship_addresslocatioin
            }
            
        }else if (flag_str == "add"){
            house_btn.layer.borderWidth = 0
            work_btn.layer.borderWidth = 0
            lover_btn.layer.borderWidth = 0
            friend_btn.layer.borderWidth = 0
            other_btn.layer.borderWidth = 0
            if (AppData.shared.selectship_image != ""){
                //                ship_image.image = AppData.shared.ship_image
                self.Selectbutton(imageurl: AppData.shared.selectship_image)
            }
            self.ship_name.text = AppData.shared.select_shipname
            self.ship_zipcode.text = AppData.shared.select_shipzipcode
            if (AppData.shared.select_shipping_address != "") {
                self.ship_address.setTitle(AppData.shared.select_shipping_address, for: .normal)
            }
            
        }
       
    }
    
    @IBAction func house_ImageSelect(_ sender: Any) {
     
//        AppData.shared.ship_image = UIImage(named: "house.png")
        AppData.shared.selectship_image = "https://mcflydelivery.com/mcflybackend/uploadfiles/images/house.png"
        self.Selectbutton(imageurl: AppData.shared.selectship_image)
    }
    @IBAction func work_ImageSelect(_ sender: Any) {
       
//        AppData.shared.ship_image = UIImage(named: "work.png")
        AppData.shared.selectship_image = "https://mcflydelivery.com/mcflybackend/uploadfiles/images/work.png"
        self.Selectbutton(imageurl: AppData.shared.selectship_image)
    }
    @IBAction func lover_ImageSelect(_ sender: Any) {
    
//        AppData.shared.ship_image = UIImage(named: "lover.png")
        AppData.shared.selectship_image = "https://mcflydelivery.com/mcflybackend/uploadfiles/images/lover.png"
        self.Selectbutton(imageurl: AppData.shared.selectship_image)
    }
    @IBAction func friend_ImageSelect(_ sender: Any) {
       
//        AppData.shared.ship_image = UIImage(named: "friend.png")
        AppData.shared.selectship_image = "https://mcflydelivery.com/mcflybackend/uploadfiles/images/friend.png"
        self.Selectbutton(imageurl: AppData.shared.selectship_image)
    }
    @IBAction func other_ImageSelect(_ sender: Any) {
    
//        AppData.shared.ship_image = UIImage(named: "other.png")
        AppData.shared.selectship_image = "https://mcflydelivery.com/mcflybackend/uploadfiles/images/other.png"
        self.Selectbutton(imageurl: AppData.shared.selectship_image)
    }
    
    @IBAction func save_ShipNew(_ sender: Any) {
        //self.save_btn.pulstate()
        AppData.shared.addgif(sender: save_btn)
        let shp_name = self.ship_name.text as! String
        let shp_zipcode = self.ship_zipcode.text as! String
        let lat_string = String(AppData.shared.select_shipping_address_lat)
        let lng_string = String(AppData.shared.select_shippin_address_lon)
        if (shp_name.isEmpty){
            AppData.shared.displayToastMessage("Ponle nombre a tu dirección de entrega")
            return
        }
        var ship_address : String = ""
       
        if (AppData.shared.select_shipping_address != ""){
            ship_address = AppData.shared.select_shipping_address
        }else {
            
            if (self.flag_str == "edit"){
                 ship_address = address_Data["address_location"] as! String
            }
           
        }
        if (ship_address == ""){
            AppData.shared.displayToastMessage("Por favor escribe la dirección")
            return
        }
       
        if (shp_zipcode.isEmpty){
            AppData.shared.displayToastMessage("Por favor escribe el código postal")
            return
        }
        var image_url : String = ""
        if (self.flag_str == "add"){
            if (AppData.shared.selectship_image == ""){
                AppData.shared.displayToastMessage("Please select a icon")
                return
            }else {
                image_url = AppData.shared.selectship_image
            }
        }else {
            if (AppData.shared.selectship_image == ""){
                image_url = address_Data["address_imageurl"] as! String
            }else {
                image_url = AppData.shared.selectship_image
            }
        }
       
        self.save_ShipAddress(ship_name: shp_name, ship_address: ship_address, zipcode: shp_zipcode, lat: lat_string, lng: lng_string, image_url: image_url)
        
    }
   
    @IBAction func select_Address(_ sender: Any) {
        AppData.shared.select_shipname = self.ship_name.text as! String
        AppData.shared.select_shipzipcode = self.ship_zipcode.text as! String
        
        if (flag_str == "add"){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "mapVC") as! MapViewController
            vc.gotoFlag = self.gotoFlag
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "mapVC") as! MapViewController
           
            vc.gotoFlag = self.gotoFlag
//            if (AppData.shared.select_shipping_address == ""){
                let address =  self.address_Data["address_location"] as! String
                let lat = self.address_Data["address_lat"] as! String
                let lng = self.address_Data["address_lng"] as! String
                let lat_db = Double(lat) as! Double
                let lng_db = Double(lng) as! Double
                print(lat)
                print(lng)
                vc.address = address
                vc.address_location = CLLocationCoordinate2D(latitude: lat_db, longitude: lng_db)
//            }else{
//                 vc.address = AppData.shared.select_shipping_address
//                 vc.address_location = CLLocationCoordinate2D(latitude: AppData.shared.select_shipping_address_lat, longitude: AppData.shared.select_shippin_address_lon)
//            }
           
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    func save_ShipAddress(ship_name : String,ship_address: String ,zipcode: String,lat: String, lng : String, image_url : String){
        var url : URL!
        var jsondata : [String : Any]!
        if (flag_str == "edit"){
        
            url = URL(string: AppConstants.baseUrl + "updateshippingaddress")!
            let address_id = address_Data["address_id"] as! String
            jsondata = ["address_id" : address_id,"name" : ship_name,"address" : ship_address ,"zipcode" : zipcode,"lat": lat, "lng": lng , "imageurl" : image_url]
        }else {
            url = URL(string: AppConstants.baseUrl + "addnewshippingaddress")!
            let customer_id = AppData.shared.profile_customerid
            jsondata = ["customer_id" : customer_id,"name" : ship_name,"address" : ship_address ,"zipcode" : zipcode,"lat": lat, "lng": lng,"imageurl" : image_url]
        }
        
        // here `content` is the JSON dictionary containing the
        
        Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                let message  = responseData["message"] as! String
                
                if (message == "success"){
                    print("success")
                    if ( self.flag_str == "add"){
                        let address_id : Int = responseData["addressid"] as! Int
                        let string_addressid = String(address_id) as! String
                        let shp_data : [String : Any] = ["address_id": string_addressid,"address_name" : ship_name, "address_location" : ship_address ,"address_lat" : lat, "address_lng":lng, "address_zipcode" : zipcode, "address_imageurl" : image_url]
                        let pos :Int = AppData.shared.profile_shippingAddress.count
                        AppData.shared.profile_shippingAddress.insert(shp_data, at: pos)
                        if (self.gotoFlag == "cart"){
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "cartVC") as! CartViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if (self.gotoFlag == "editprofile"){
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "editprofileVC") as! EditProfileViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if (self.gotoFlag == "signup") {
                            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
                            //   self.present(verificationController, animated: true, completion: nil)
                            self.navigationController?.pushViewController(verificationController, animated: true)
                        }else if (self.gotoFlag == "maindeliver") {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
                            vc.goback = AppData.shared.gotopage
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else {
                            _ = self.navigationController?.popViewController(animated: true)
                        }
                    }else {
                        let address_id = self.address_Data["address_id"] as! String
                        let shp_data : [String : Any] = ["address_id": address_id,"address_name" : ship_name, "address_location" : ship_address ,"address_lat" : lat, "address_lng":lng, "address_zipcode" : zipcode, "address_imageurl" : image_url]
                        print(self.ship_index)
                        AppData.shared.profile_shippingAddress.removeObject(at: self.ship_index)
                        AppData.shared.profile_shippingAddress.insert(shp_data, at: self.ship_index)
                        if (self.gotoFlag == "cart"){
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "cartVC") as! CartViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if (self.gotoFlag == "editprofile"){
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "editprofileVC") as! EditProfileViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else if (self.gotoFlag == "signup") {
                            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
                            //   self.present(verificationController, animated: true, completion: nil)
                            self.navigationController?.pushViewController(verificationController, animated: true)
                        }
                        else if (self.gotoFlag == "maindeliver") {
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "delivermainVC") as! SelectMainDeliverAddressViewController
                            vc.goback = AppData.shared.gotopage
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                    }
                    
                    
                    
                }
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    func Selectbutton(imageurl : String){
        if (imageurl.contains("house.png")){
            house_btn.setImage(house_imagesel, for: .normal)
            work_btn.setImage(work_image, for: .normal)
            lover_btn.setImage(lover_image, for: .normal)
            friend_btn.setImage(friend_image, for: .normal)
            other_btn.setImage(other_image, for: .normal)
        }else if (imageurl.contains("work.png")){
            house_btn.setImage(house_image, for: .normal)
            work_btn.setImage(work_imagesel, for: .normal)
            lover_btn.setImage(lover_image, for: .normal)
            friend_btn.setImage(friend_image, for: .normal)
            other_btn.setImage(other_image, for: .normal)
        }else if (imageurl.contains("lover.png")){
            house_btn.setImage(house_image, for: .normal)
            work_btn.setImage(work_image, for: .normal)
            lover_btn.setImage(lover_imagesel, for: .normal)
            friend_btn.setImage(friend_image, for: .normal)
            other_btn.setImage(other_image, for: .normal)
        } else if (imageurl.contains("friend.png")){
            house_btn.setImage(house_image, for: .normal)
            work_btn.setImage(work_image, for: .normal)
            lover_btn.setImage(lover_image, for: .normal)
            friend_btn.setImage(friend_imagesel, for: .normal)
            other_btn.setImage(other_image, for: .normal)
        } else if (imageurl.contains("other.png")){
            house_btn.setImage(house_image, for: .normal)
            work_btn.setImage(work_image, for: .normal)
            lover_btn.setImage(lover_image, for: .normal)
            friend_btn.setImage(friend_image, for: .normal)
            other_btn.setImage(other_imagesel, for: .normal)
        }
    }
    
}
