//
//  SelectShippingDialogViewController.swift
//  McFly
//
//  Created by LiuYan on 5/28/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import UIKit
class SelectShippingDialogViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    @IBOutlet weak var shippingaddress_tbl: UITableView!
    var containviewController : UIViewController!
    override func viewDidLoad() {
        super.viewDidLoad()
        shippingaddress_tbl.dataSource = self
        shippingaddress_tbl.delegate = self
        // Do any additional setup after loading the view.
        
        
    }
    
    @IBAction func Add_shippingAddress(_ sender: Any) {
//        self.removeFromParent()
//        self.view.removeFromSuperview()
        dismiss(animated: true, completion: nil)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "newshipVC") as! AddNewShippingAddressViewController
        vc.flag_str = "add"
        vc.gotoFlag = "cart"
        containviewController.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (AppData.shared.profile_shippingAddress.count > 0){
            return AppData.shared.profile_shippingAddress.count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "shippingaddressCell", for: indexPath) as! ShippingAddressCell
        let cell_shipData = AppData.shared.profile_shippingAddress[indexPath.row] as! NSDictionary
        let image_url = cell_shipData["address_imageurl"] as! String
        cell.shipping_image.moa.url = image_url
        let ship_name = cell_shipData["address_name"] as! String
        cell.ship_name.text = ship_name
        let ship_address = cell_shipData["address_location"] as! String
        cell.shipping_address.text = ship_address
        cell.cellShipData = cell_shipData
        cell.cellnumber = indexPath.row
        cell.viewController = containviewController
        cell.secondController = self
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (AppData.shared.select_discountcode == ""){
            dismiss(animated: true, completion: nil)
            AppData.shared.select_indexship = indexPath.row
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "checkoutVC") as! CheckOutViewController
            self.containviewController.navigationController?.pushViewController(vc, animated: true)
           
        }else {
             AppData.shared.select_indexship = indexPath.row
        }
       
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    
}
