//
//  ShipDeleteDialog.swift
//  McFly
//
//  Created by LiuYan on 6/19/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
class ShipDeleteDialog: UIView, ModalBottom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    var viewcontroller = UIViewController()
    var tableview : UITableView!
    var index : Int = 0
    var countfield: UITextField!
    
    convenience init(title:String,vc: UIViewController, tableview : UITableView,index : Int){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title,vc: vc, tableview: tableview,index: index)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String,vc: UIViewController, tableview : UITableView,index : Int){
        dialogView.clipsToBounds = true
        self.tableview = tableview
        self.viewcontroller = vc
        self.index = index
        backgroundView.frame = frame
        let height = backgroundView.frame.height
        
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width - 64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 15, width: dialogViewWidth-16, height: 20))
        titleLabel.text = " ¿Segurx de que quieres borrar esta dirección? "
        titleLabel.textColor = UIColor.black
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.systemFont(ofSize: 13.0)
        dialogView.addSubview(titleLabel)
        
        
        //        let imageView = UIImageView(frame: CGRect(x: 20, y: 8, width: dialogViewWidth, height: 100))
        //        imageView.image = UIImage.gif(asset: "progressgif")
        //        dialogView.addSubview(imageView)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        let btn_width = (dialogViewWidth-16) / 2.5
        let notyet_btn = UIButton(frame: CGRect(x: 28, y: 50, width: btn_width, height:30))
        notyet_btn.layer.backgroundColor = blueColor.cgColor
        notyet_btn.layer.cornerRadius = 15
        notyet_btn.layer.masksToBounds = true
        notyet_btn.setTitleColor(UIColor.white, for: .normal)
        notyet_btn.setTitle("Si", for: .normal)
        notyet_btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        notyet_btn.addTarget(self, action: #selector(closeDialog), for: .touchUpInside)
        dialogView.addSubview(notyet_btn)
        let x = dialogViewWidth - 28 - btn_width
        let signup_btn = UIButton(frame: CGRect(x: x, y: 50, width: btn_width, height: 30))
        signup_btn.layer.backgroundColor = blueColor.cgColor
        signup_btn.layer.cornerRadius = 15
        signup_btn.layer.masksToBounds = true
        signup_btn.setTitleColor(UIColor.white, for: .normal)
        signup_btn.setTitle("Undo 😱", for: .normal)
        signup_btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        signup_btn.addTarget(self, action: #selector(GotoSignUp), for: .touchUpInside)
        dialogView.addSubview(signup_btn)
        
        
        
        let dialogViewHeight =  CGFloat(100)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height )
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
        
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    @objc func closeDialog(sender : UIButton!){
        dismiss(animated: true)
        AppData.shared.profile_shippingAddress.removeObject(at: self.index)
        self.saveProfile()
        
    }
    @objc func GotoSignUp(sender : UIButton!){
        dismiss(animated: true)
        
    }
    func saveProfile(){
        
        let email = AppData.shared.profile_customerDetailData["email"] as! String
        let firstname = AppData.shared.profile_customerDetailData["first_name"] as! String
        let lastname = AppData.shared.profile_customerDetailData["last_name"] as! String
        let phonenumber = AppData.shared.profile_customerDetailData["phone"] as! String
        let birthday = AppData.shared.profile_customerDetailData["birthday"] as! String
        let customerid = AppData.shared.profile_customerid
        let verified_type = AppData.shared.profile_customerDetailData["verifiedtype"] as! String
        let verified_value = AppData.shared.profile_customerDetailData["verfified_value"] as! String
        let fcmtoken = AppData.shared.profile_customerDetailData["token"] as! String
        AppData.shared.profile_customerDetailData.setValue(email, forKey: "email")
        AppData.shared.profile_customerDetailData.setValue(firstname, forKey: "first_name")
        AppData.shared.profile_customerDetailData.setValue(lastname, forKey: "last_name")
        AppData.shared.profile_customerDetailData.setValue(phonenumber, forKey: "phone")
        AppData.shared.profile_customerDetailData.setValue(AppData.shared.profile_imageurl, forKey: "image")
        var InputShippnigData = NSMutableArray()
        for index in 0..<AppData.shared.profile_shippingAddress.count {
            let shippingData = AppData.shared.profile_shippingAddress[index] as! NSDictionary
            let address_name = shippingData["address_name"] as! String
            let address_lat = shippingData["address_lat"] as! String
            let address_lng = shippingData["address_lng"] as! String
            let address_zip = shippingData["address_zipcode"] as! String
            let address_location = shippingData["address_location"] as! String
            let address_imageurl = shippingData["address_imageurl"] as! String
            let inputshipping :[String :Any] = ["address_name" : address_name,"address_location" : address_location,"address_lat" : address_lat, "address_lng" : address_lng, "address_zip": address_zip , "address_imageurl" : address_imageurl]
            InputShippnigData.add(inputshipping)
        }
        
        
        
        let url = URL(string: AppConstants.baseUrl + "updateprofile")!
        let jsondata: [String: Any] = [ "customerid" : AppData.shared.profile_customerid,"email" : email,"firstname" : firstname, "lastname" : lastname, "verifiedtype": verified_type,"verified_value" : verified_value ,"fcmtoken" : fcmtoken,"photourl" : AppData.shared.profile_imageurl,"password": "","birthday": birthday, "phone" : phonenumber, "shippingaddress" : InputShippnigData]
        print(jsondata)
        if let json = try? JSONSerialization.data(withJSONObject: jsondata, options: []) {
            if let content = String(data: json, encoding: String.Encoding.utf8) {
                // here `content` is the JSON dictionary containing the String
                let data : [String: Any] = ["json" : content]
                
                Alamofire.request(url, method: .post, parameters : data ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            
                            AppData.shared.profile_discountArray = responseData["discountcodes"] as! NSMutableArray
                            AppData.shared.profile_customerid = responseData["customer_id"] as! String
                            AppData.shared.profile_customerDetailData.setValue(firstname, forKey: "first_name")
                            AppData.shared.profile_customerDetailData.setValue(lastname, forKey: "last_name")
                            AppData.shared.profile_customerDetailData.setValue(phonenumber, forKey: "phone")
                            AppData.shared.profile_customerDetailData.setValue(AppData.shared.profile_imageurl, forKey: "image")
                            self.viewcontroller.viewWillAppear(true)
                            self.tableview.reloadData()
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                    }
                }
            }
        }
    }
}
