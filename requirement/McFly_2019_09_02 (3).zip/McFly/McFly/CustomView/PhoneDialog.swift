//
//  PhoneDialog.swift
//  McFly
//
//  Created by LiuYan on 6/5/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
class PhoneDialog: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var submitbtn = UIButton()
    var phoneNumber = UITextField()
    var k:Float = 0
    var viewcontroller  = UIViewController()
    
    convenience init(title:String, viewcontroller: UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title,viewcontroller : viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
        titleLabel.text = "Please enter zip code"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17.0)
        titleLabel.textColor = UIColor.darkGray
        titleLabel.textAlignment = .center
        dialogView.addSubview(titleLabel)
        
        phoneNumber = UITextField(frame: CGRect(x: 28, y: 53, width: dialogViewWidth-56, height: 30))
        phoneNumber.placeholder = "Enter Zip Code"
        phoneNumber.textAlignment = .center
        phoneNumber.textColor = UIColor.black
        phoneNumber.borderStyle = .none
        phoneNumber.layer.borderWidth = 1
        phoneNumber.layer.borderColor = UIColor.lightGray.cgColor
        phoneNumber.layer.cornerRadius = 12.5
        phoneNumber.layer.masksToBounds = true
        dialogView.addSubview(phoneNumber)
        
        submitbtn = UIButton(frame: CGRect(x: 28, y: 103, width: dialogViewWidth-56, height: 30))
        submitbtn.titleLabel?.textColor = UIColor.white
        submitbtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        submitbtn.backgroundColor = blueColor
        submitbtn.setTitle("Seguir comprando", for: .normal)
        submitbtn.addTarget(self, action: #selector(SubmitZipcode), for: .touchUpInside)
        // btn.tag = 1
        dialogView.addSubview(submitbtn)
        
        
        let dialogViewHeight =  CGFloat(153)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    
    @objc func SubmitZipcode(sender: UIButton!) {
        let phone_Number = phoneNumber.text as! String
        AppData.shared.profile_phoneNumber = phone_Number
        AppData.shared.profile_imageurl = ""
        
        saveProfile()
       
    }
    func saveProfile(){
        AppData.shared.showLoadingIndicator(view: self.viewcontroller.view)
        let url = URL(string: AppConstants.baseUrl + "customersignup")!
        let jsondata: [String: Any] = ["email" : AppData.shared.profile_useremail,"firstname" : AppData.shared.profile_firstname, "lastname" : AppData.shared.profile_lastname, "verifiedtype": AppData.shared.profile_accountType,"verified_value" : AppData.shared.profile_verficationvalue ,"fcmtoken" : AppData.shared.profile_fcmtoken,"photourl" : AppData.shared.profile_imageurl,"password": "", "phone" : AppData.shared.profile_phoneNumber, "shippingaddress" : AppData.shared.profile_shippingAddress]
        print(jsondata)
        if let json = try? JSONSerialization.data(withJSONObject: jsondata, options: []) {
            if let content = String(data: json, encoding: String.Encoding.utf8) {
                // here `content` is the JSON dictionary containing the String
                let data : [String: Any] = ["json" : content]
                
                Alamofire.request(url, method: .post, parameters : data ,encoding: URLEncoding.default, headers: nil).responseString {
                    response in
                    switch response.result {
                    case .success:
                        print(response)
                        let jsonString = response.result.value as! String
                        let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                        let message  = responseData["message"] as! String
                        if (message == "success"){
                            print("success")
                            AppData.shared.profile_discountArray = responseData["discountcodes"] as! NSMutableArray
                            AppData.shared.profile_customerid = responseData["customer_id"] as! String
                            self.Profile_data()
                        }
                        break
                    case .failure(let error):
                        
                        print(error)
                    }
                }
            }
        }
    }
    func Profile_data(){
        let url = URL(string: AppConstants.baseUrl + "customerlogin")!
        let jsondata: [String: Any] = ["verified_type": AppData.shared.profile_accountType,"verified_value" : AppData.shared.profile_verficationvalue ,"fcmToken" : AppData.shared.profile_fcmtoken]
        print(jsondata)
        Alamofire.request(url, method: .post, parameters : jsondata ,encoding: URLEncoding.default, headers: nil).responseString {
            response in
            switch response.result {
            case .success:
                print(response)
                let jsonString = response.result.value as! String
                let responseData = AppData.shared.convertStringToDictionary(text: jsonString)! as NSDictionary
                print(responseData)
                let message  = responseData["message"] as! String
                if (message == "success"){
                    AppData.shared.profile_loginstatus = true
                    let customer_detail = responseData["customerdetail"] as! NSMutableArray
                    AppData.shared.profile_customerDetailData = customer_detail[0] as! NSDictionary
                    AppData.shared.profile_customerid = AppData.shared.profile_customerDetailData["id"] as! String
                    let discountcodes = responseData["discountcodes"] as! NSMutableArray
                    AppData.shared.profile_discountArray = discountcodes
                    let shipppingaddress = responseData["shippingaddresses"] as! NSMutableArray
                    AppData.shared.profile_shippingAddress = shipppingaddress
                    if (jsonString.contains("carddetail")){
                        let carddetailData = responseData["carddetail"] as! NSDictionary
                        AppData.shared.profile_carddetailData = carddetailData
                        let default_sourcecard = carddetailData["default_source"] as! String
                        AppData.shared.default_cardsource = default_sourcecard
                        let source = carddetailData["sources"] as! NSDictionary
                        let carddetail_datas = source["data"] as! NSMutableArray
                        AppData.shared.cardDetailData = carddetail_datas
                        
                    }
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
                    self.viewcontroller.present(verificationController, animated: true, completion: nil)
                    
                }else if(message == "There is no registered account" && AppData.shared.profile_accountType != 0)  {
                    //                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    //                    let verificationController = storyBoard.instantiateViewController(withIdentifier: "signup2VC") as! SignUp2ViewController
                    //                    //   self.present(verificationController, animated: true, completion: nil)
                    //                    self.navigationController?.pushViewController(verificationController, animated: true)
                }
                
                break
            case .failure(let error):
                
                print(error)
            }
        }
    }
    
}
