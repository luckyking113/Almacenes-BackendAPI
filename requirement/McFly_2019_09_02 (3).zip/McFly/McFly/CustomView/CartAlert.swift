//
//  CartAlert.swift
//  McFly
//
//  Created by LiuYan on 6/1/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
class CartAlert: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    
    convenience init(title:String){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String){
        dialogView.clipsToBounds = true
        
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 20, width: dialogViewWidth-16, height: 25))
        titleLabel.text = title
        titleLabel.font = UIFont.boldSystemFont(ofSize: 20.0)
        titleLabel.textColor = UIColor.darkGray
        titleLabel.textAlignment = .center
        dialogView.addSubview(titleLabel)
        
        let titleLabel1 = UILabel(frame: CGRect(x: 8, y: 55, width: dialogViewWidth-16, height: 15))
        titleLabel1.text = "Solo necesitas consumir $50 o "
        titleLabel1.textColor = UIColor.darkGray
        titleLabel1.font = UIFont.boldSystemFont(ofSize: 15)
        titleLabel1.textAlignment = .center
        dialogView.addSubview(titleLabel1)
        
        
        let titleLabel3 = UILabel(frame: CGRect(x: 8, y: 80, width: dialogViewWidth-16, height: 15))
        titleLabel3.text = "mas para realizar tu compra. ¡Un"
        titleLabel3.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel3.textColor = UIColor.darkGray
        titleLabel3.textAlignment = .center
        dialogView.addSubview(titleLabel3)
        
        let titleLabel4 = UILabel(frame: CGRect(x: 8, y: 105, width: dialogViewWidth-16, height: 15))
        titleLabel4.text = "chirris mas y te lo llevamos!"
        titleLabel4.font = UIFont.boldSystemFont(ofSize: 15.0)
        titleLabel4.textColor = UIColor.darkGray
        titleLabel4.textAlignment = .center
        dialogView.addSubview(titleLabel4)
        //Working times
        
       
        
        let keep_btn: UIButton = UIButton(frame: CGRect(x: 28, y: 140, width: dialogViewWidth-56, height: 30))
        keep_btn.layer.cornerRadius = 15
        keep_btn.layer.masksToBounds = true
        keep_btn.titleLabel?.textColor = UIColor.white
        keep_btn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        keep_btn.backgroundColor = blueColor
        keep_btn.setTitle("Seguir comprando", for: .normal)
        keep_btn.addTarget(self, action: #selector(keep_Action), for: .touchUpInside)
       // btn.tag = 1
        dialogView.addSubview(keep_btn)
        
        
        let dialogViewHeight =  CGFloat(190)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
       
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    
    @objc func keep_Action(sender: UIButton!) {
        dismiss(animated: true)
    }
}
