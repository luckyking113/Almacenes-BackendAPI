//
//  SubmitZipCode.swift
//  McFly
//
//  Created by LiuYan on 6/1/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import  IQKeyboardManagerSwift
class SubmitZipCode: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var submitbtn = UIButton()
    var zicode = UITextField()
    var k:Float = 0
    var viewcontroller  = UIViewController()
    
    convenience init(title:String, viewcontroller: UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title,viewcontroller : viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
        titleLabel.text = "¿Cual es tu código postal?"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17.0)
        titleLabel.textColor = UIColor.darkGray
        titleLabel.textAlignment = .center
        dialogView.addSubview(titleLabel)
        
        zicode = UITextField(frame: CGRect(x: 28, y: 53, width: dialogViewWidth-56, height: 30))
        zicode.placeholder = "Escribe tu código postal"
        zicode.textAlignment = .center
        zicode.keyboardType = .numberPad
        zicode.textColor = UIColor.black
        zicode.borderStyle = .none
        zicode.layer.borderWidth = 1
        zicode.layer.borderColor = UIColor.lightGray.cgColor
        zicode.layer.cornerRadius = 12.5
        zicode.layer.masksToBounds = true
        dialogView.addSubview(zicode)
        
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        
        let zipcodebtn = UIButton(frame: CGRect(x: 28, y: 103, width: dialogViewWidth-56, height: 30))
        zipcodebtn.setTitle(" ¿No sabes cual es?", for: .normal)
        zipcodebtn.setTitleColor(blueColor, for: .normal)
        zipcodebtn.addTarget(self, action: #selector(Knowzipcode), for: .touchUpInside)
        dialogView.addSubview(zipcodebtn)
        
        submitbtn = UIButton(frame: CGRect(x: 28, y: 153, width: dialogViewWidth-56, height: 30))
        submitbtn.titleLabel?.textColor = UIColor.white
        submitbtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
      
        submitbtn.backgroundColor = blueColor
        submitbtn.setTitle("Continuar", for: .normal)
        submitbtn.addTarget(self, action: #selector(SubmitZipcode), for: .touchUpInside)
        // btn.tag = 1
        dialogView.addSubview(submitbtn)
        
        
        let dialogViewHeight =  CGFloat(203)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
    }
    
    @objc func didTappedOnBackgroundView(){
        AppData.shared.zipdialog_flag = 0
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "homeview") as! HomeTabBarController
        self.viewcontroller.present(verificationController, animated: true, completion: nil)
        dismiss(animated: true)
    }
    
    @objc func SubmitZipcode(sender: UIButton!) {
        sender.pulstate()
        dismiss(animated: true)
        let zipcodestring = self.zicode.text as! String
        if (zipcodestring.isEmpty) {
            AppData.shared.displayToastMessage("Please enter zipcode!")
            return
        }
        if (AppData.shared.profile_loginstatus) {
                let zipcodearray = AppConstants.warehouse_zipcode.components(separatedBy: ",")
                let count = zipcodearray.count
                var flag : Int = 0
                for index in 0..<count {
                    if (zipcodestring.elementsEqual(zipcodearray[index])) {
                        flag = 1
                        AppData.shared.set_flag = 1
                        AppData.shared.customer_zipcode = zipcodestring
                        print(AppData.shared.warehouse_zipcode)
                        let alert = LoadingDialog(title: "", viewcontroller: self.viewcontroller)
                        alert.show(animated: true)
                    }
                }
                if (flag == 0){
                    AppData.shared.set_flag = 0
                    let alert = LoadingDialog(title: "", viewcontroller: self.viewcontroller)
                    alert.show(animated: true)
                }
            
        }else{
            
            let zipcodearray = AppConstants.warehouse_zipcode.components(separatedBy: ",")
            let count = zipcodearray.count
            var flag : Int = 0
            for index in 0..<count {
                if (zipcodestring.elementsEqual(zipcodearray[index])) {
                    flag = 1
                    AppData.shared.wrong_warehouse = 1
                    AppData.shared.customer_zipcode = zipcodestring
                    let alert = LoadingDialog(title: "", viewcontroller: self.viewcontroller)
                    alert.show(animated: true)
                }
            }
            if (flag == 0){
                AppData.shared.wrong_warehouse = 0
                let alert = LoadingDialog(title: "", viewcontroller: self.viewcontroller)
                alert.show(animated: true)
            }
            
        }
            
        
    }
    @objc func Knowzipcode(sender: UIButton!) {
        sender.pulstate()
        dismiss(animated: true)
        let vc = self.viewcontroller.storyboard?.instantiateViewController(withIdentifier: "showzipcodeVC") as! ShowZipcodeViewController
        self.viewcontroller.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}


