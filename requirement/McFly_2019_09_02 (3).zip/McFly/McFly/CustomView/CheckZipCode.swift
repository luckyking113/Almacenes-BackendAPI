//
//  CheckZipCode.swift
//  McFly
//
//  Created by LiuYan on 6/19/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import  IQKeyboardManagerSwift
import SwiftGifOrigin
class CheckZipCode: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var submitbtn = UIButton()
    var viewcontroller  = UIViewController()
    
    convenience init(title:String, viewcontroller: UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title,viewcontroller : viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-64
        let  center_x = dialogViewWidth / 2 - 75
        let  imagecenter_x = dialogViewWidth / 2 - 60
        
        let imageViewContainer = UIView(frame: CGRect(x: center_x, y: 0, width: 150, height: 150))
//        imageView.image = UIImage.gif(asset: "progressgif")
        imageViewContainer.backgroundColor = UIColor.white
        imageViewContainer.layer.cornerRadius = 75
        imageViewContainer.layer.masksToBounds = true
        dialogView.addSubview(imageViewContainer)
        
        let uiview = UIView(frame: CGRect(x: 0, y: 75, width: dialogViewWidth, height: 160))
        uiview.layer.cornerRadius = 10
        //uiview.layer.masksToBounds = true
        uiview.backgroundColor = UIColor.white
        
        let image = UIImageView(frame: CGRect(x: imagecenter_x, y: -85, width: 120, height: 120))
        image.image = UIImage.gif(asset: "progressgif")
        uiview.addSubview(image)
       
        
        let titleLabel = UILabel(frame: CGRect(x: 0, y: 30, width: dialogViewWidth-16, height: 17))
        titleLabel.text = "aun no llegamos a "
        titleLabel.font = UIFont.boldSystemFont(ofSize: 17.0)
        titleLabel.textColor = UIColor.black
        titleLabel.textAlignment = .center
        uiview.addSubview(titleLabel)
        
        let titleLabel1 = UILabel(frame: CGRect(x: 8, y: 50, width: dialogViewWidth-16, height: 17))
        titleLabel1.text = "tu area😧"
        titleLabel1.font = UIFont.boldSystemFont(ofSize: 17.0)
        titleLabel1.textColor = UIColor.black
        titleLabel1.textAlignment = .center
        uiview.addSubview(titleLabel1)
        
       
        
        
        
        
        
        
        
//
//        let sublabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
//        sublabel.text = "We are not in your area yet"
//        sublabel.font = UIFont.systemFont(ofSize: 17.0)
//        sublabel.textColor = UIColor.darkGray
//        sublabel.textAlignment = .center
//        uiview.addSubview(sublabel)
        
      
        
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        
       
        
        submitbtn = UIButton(frame: CGRect(x: 28, y: 94, width: dialogViewWidth-56, height: 30))
        submitbtn.titleLabel?.textColor = UIColor.white
        submitbtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        submitbtn.backgroundColor = blueColor
        submitbtn.layer.cornerRadius = 3
        submitbtn.layer.masksToBounds = true
        submitbtn.setTitle("OK", for: .normal)
        submitbtn.addTarget(self, action: #selector(SubmitZipcode), for: .touchUpInside)
        // btn.tag = 1
        uiview.addSubview(submitbtn)
        dialogView.addSubview(uiview)
        
        let dialogViewHeight =  CGFloat(240)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.clear
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    
    @objc func SubmitZipcode(sender: UIButton!) {
        sender.pulstate()
        dismiss(animated: true)
    }
  
    
}
