//
//  LoadingDataDialog.swift
//  McFly
//
//  Created by LiuYan on 6/6/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
class LoadingDataDialog: UIView, ModalCustom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    var viewcontroller = UIViewController()
    
    convenience init(title:String, viewcontroller : UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title, viewcontroller: viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width-200
        
        //        let titleLabel = UILabel(frame: CGRect(x: 8, y: 8, width: dialogViewWidth-16, height: 25))
        //
        //        dialogView.addSubview(titleLabel)
        let imageView = UIImageView(frame: CGRect(x: 20, y: 8, width: dialogViewWidth, height: 160))
        imageView.image = UIImage.gif(asset: "progressgif")
        dialogView.addSubview(imageView)
        
        let dialogViewHeight =  CGFloat(140)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-150, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.clear
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
        
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    
}
