//
//  SignUpDialog.swift
//  McFly
//
//  Created by LiuYan on 6/15/19.
//  Copyright © 2019 Xiao. All rights reserved.
//

import Foundation
import UIKit
class SignUpDialog: UIView, ModalBottom {
    var backgroundView = UIView()
    var dialogView = UIView()
    var k:Float = 0
    var viewcontroller = UIViewController()
    
    convenience init(title:String, viewcontroller : UIViewController){
        self.init(frame: UIScreen.main.bounds)
        initialize(title: title, viewcontroller: viewcontroller)
        
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func initialize(title:String, viewcontroller : UIViewController){
        dialogView.clipsToBounds = true
        self.viewcontroller = viewcontroller
        backgroundView.frame = frame
        backgroundView.backgroundColor = UIColor.black
        backgroundView.alpha = 0.6
        backgroundView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTappedOnBackgroundView)))
        addSubview(backgroundView)
        
        let dialogViewWidth = frame.width - 64
        
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 15, width: dialogViewWidth-16, height: 20))
        titleLabel.text = "¿listx para ordenar?"
        titleLabel.textColor = UIColor.black
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.boldSystemFont(ofSize: 13.0)
        dialogView.addSubview(titleLabel)
        
        
        let subtitleLabel = UILabel(frame: CGRect(x: 8, y: 45, width: dialogViewWidth-16, height: 20))
        subtitleLabel.text = "¡Crea tu cuenta con McFly!"
        subtitleLabel.textColor = UIColor.black
        subtitleLabel.textAlignment = .center
        subtitleLabel.font = UIFont.systemFont(ofSize: 13.0)
        dialogView.addSubview(subtitleLabel)
        
//        let imageView = UIImageView(frame: CGRect(x: 20, y: 8, width: dialogViewWidth, height: 100))
//        imageView.image = UIImage.gif(asset: "progressgif")
//        dialogView.addSubview(imageView)
        let blueColor = UIColor(red: 44/255.0, green: 173/255.0, blue: 227/255.0, alpha: 1.0)
        let btn_width = (dialogViewWidth-16) / 2.5
        let notyet_btn = UIButton(frame: CGRect(x: 28, y: 80, width: btn_width, height:30))
        notyet_btn.layer.backgroundColor = blueColor.cgColor
        notyet_btn.layer.cornerRadius = 15
        notyet_btn.layer.masksToBounds = true
        notyet_btn.setTitleColor(UIColor.white, for: .normal)
        notyet_btn.setTitle("aun no", for: .normal)
        notyet_btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        notyet_btn.addTarget(self, action: #selector(closeDialog), for: .touchUpInside)
        dialogView.addSubview(notyet_btn)
        let x = dialogViewWidth - 28 - btn_width
        let signup_btn = UIButton(frame: CGRect(x: x, y: 80, width: btn_width, height: 30))
        signup_btn.layer.backgroundColor = blueColor.cgColor
        signup_btn.layer.cornerRadius = 15
        signup_btn.layer.masksToBounds = true
        signup_btn.setTitleColor(UIColor.white, for: .normal)
        signup_btn.setTitle("siiiii😍", for: .normal)
        signup_btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        signup_btn.addTarget(self, action: #selector(GotoSignUp), for: .touchUpInside)
        dialogView.addSubview(signup_btn)
        
        
        
        let dialogViewHeight =  CGFloat(140)
        
        dialogView.frame.origin = CGPoint(x: 32, y: frame.height)
        dialogView.frame.size = CGSize(width: frame.width-64, height: dialogViewHeight)
        dialogView.backgroundColor = UIColor.white
        dialogView.layer.cornerRadius = 6
        addSubview(dialogView)
        
    }
    
    @objc func didTappedOnBackgroundView(){
        dismiss(animated: true)
    }
    @objc func closeDialog(sender : UIButton!){
        if (AppData.shared.profile_loginstatus){
            dismiss(animated: true)
        }else {
           
            if (AppData.shared.product_Data.count > 0){
                 dismiss(animated: true)
            }else {
                AppData.shared.wrong_warehouse = 0
                let alert = LoadingDialog(title: "" , viewcontroller: self.viewcontroller)
                alert.show(animated: true)
            }
           
        }
        
        
    }
    @objc func GotoSignUp(sender : UIButton!){
//        dismiss(animated: true)
        AppData.shared.initAppData()
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let verificationController = storyBoard.instantiateViewController(withIdentifier: "signinVC") as! SiginInViewController
        self.parentContainerViewController()?.present(verificationController, animated: true, completion: nil)
        //self.viewcontroller.present(verificationController, animated: true)
        
    }
    
}
